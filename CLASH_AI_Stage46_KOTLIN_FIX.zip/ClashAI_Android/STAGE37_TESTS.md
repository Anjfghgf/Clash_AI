# Stage 37 verification

## Passed in this environment

- `Stage37EnemyIntelligenceSmokeTest.kt`: exact-card gating, broad-class rejection, friendly/unknown-side rejection, unstable-label rejection, per-track duplicate suppression, eight-card deck cap, and explicit elixir-configuration behavior.
- `Stage36BattlefieldUnderstandingSmokeTest.kt`: prior battlefield tracking and uncertainty checks.
- `python -m py_compile training_pipeline/scripts/*.py`.
- Static integration checks: separate enemy detector runtime, shared full-frame capture, battlefield-to-enemy-intelligence feed, enemy deck in tactical context, unknown elixir handling, coach summary, and version bump.

## Not verified

- Full Android/Gradle build and APK installation: Gradle/Android build environment was not available.
- Real-device screen capture, model inference speed, battery use, and live match accuracy.
- Exact enemy-card recognition: no trained `enemy_card_detector.tflite` or matching labels file is included. The runtime is integrated but reports unavailable until the model is trained and installed.

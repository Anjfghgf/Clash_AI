package com.clashai.coach

private fun enemyObject(
    id: Int, label: String, side: BattlefieldStateModel.Side = BattlefieldStateModel.Side.ENEMY,
    confidence: Float = .96f, stable: Boolean = true
) = BattlefieldUnderstandingEngine.TrackedObject(
    id, label, BattlefieldUnderstandingEngine.ObjectKind.TROOP,
    BattlefieldUnderstandingEngine.TroopDomain.UNKNOWN, side, "LEFT", "UNKNOWN",
    confidence, stable, .25f, .25f, "MID_ARENA"
)

private fun snapshot(vararg objects: BattlefieldUnderstandingEngine.TrackedObject, ready: Boolean = true) =
    BattlefieldUnderstandingEngine.Snapshot(objects.toList(), Unit, "test", ready)

fun main() {
    val pipeline = EnemyIntelligencePipeline()

    // Generic troop categories must never be promoted into a card identity.
    var update = pipeline.update(snapshot(enemyObject(1, "air_troop")), 1_000L)
    check(update.deck.isEmpty())

    // Friendly, uncertain, and unstable exact labels must not enter the enemy deck.
    pipeline.update(snapshot(enemyObject(2, "Hog Rider", BattlefieldStateModel.Side.FRIENDLY)), 2_000L)
    pipeline.update(snapshot(enemyObject(3, "Hog Rider", BattlefieldStateModel.Side.UNKNOWN)), 3_000L)
    pipeline.update(snapshot(enemyObject(4, "Hog Rider", stable = false)), 4_000L)
    check(pipeline.deck().isEmpty())

    // A stable exact card-name detection on the enemy side is accepted once per track.
    update = pipeline.update(snapshot(enemyObject(5, "Hog Rider")), 5_000L)
    check(update.acceptedPlays == listOf("Hog Rider"))
    check(update.deck == listOf("Hog Rider"))
    check(pipeline.update(snapshot(enemyObject(5, "Hog Rider")), 6_000L).acceptedPlays.isEmpty())

    // Every mode is capped at eight unique enemy cards.
    val cards = listOf("Baby Dragon", "P.E.K.K.A", "Musketeer", "Fireball", "Cannon", "Skeletons", "Balloon", "Knight", "Zap")
    cards.forEachIndexed { index, card -> pipeline.update(snapshot(enemyObject(10 + index, card)), 10_000L + index * 3_000L) }
    check(pipeline.deck().size == 8)
    check(pipeline.deck().first() == "Hog Rider")
    check(update.elixir.known.not())

    // No starting value/regeneration means elixir remains unknown; valid explicit configuration enables estimates.
    val configured = EnemyIntelligencePipeline()
    check(configured.configureElixir(5.0, 5.0, 1.0 / 2.8, 1_000L))
    configured.update(snapshot(enemyObject(50, "Hog Rider")), 4_000L)
    val estimated = configured.update(snapshot(ready = true), 5_000L).elixir
    check(estimated.known)
    check(estimated.low <= estimated.high)

    println("Stage 37 enemy intelligence smoke checks passed")
}

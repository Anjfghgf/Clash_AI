package com.clashai.coach
class MatchPredictionEngine { enum class Threat { UNKNOWN, LOW, MEDIUM, HIGH }; data class Prediction(val status: String, val lanePressure: String, val threat: Threat) }
class SituationalAwarenessEngine { enum class Pressure { UNKNOWN, LOW, MEDIUM, HIGH }; data class Group(val side: BattlefieldStateModel.Side, val troopCount: Int, val movingTowardBottom: Int); data class Assessment(val groups: List<Group>, val pressure: Pressure) }
class GameModeIntelligence { enum class Mode { NORMAL, CHAOS, TWO_V_TWO } }

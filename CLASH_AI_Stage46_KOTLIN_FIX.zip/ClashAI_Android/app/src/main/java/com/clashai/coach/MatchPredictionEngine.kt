package com.clashai.coach

/** Stage 41: evidence-gated, coarse match prediction. It recommends only; it never controls the game. */
class MatchPredictionEngine(private val requiredSamples: Int = 3) {
    enum class Threat { UNKNOWN, LOW, MEDIUM, HIGH }
    enum class Move { DEFEND, WAIT, COUNTERATTACK }

    data class Prediction(
        val status: String,
        val lanePressure: String,
        val threat: Threat,
        val alternatives: List<String>,
        val preferredMove: Move,
        val explanation: String,
        val confidence: String
    ) {
        fun render(): String = buildString {
            append("MATCH PREDICTION: $status\nLANE PRESSURE: $lanePressure\nTHREAT: $threat\n")
            append("COMPARE: ${alternatives.joinToString(" | ")}\nNEXT MOVE TO CONSIDER: $preferredMove\n")
            append("WHY: $explanation\nCONFIDENCE: $confidence\nPrediction is a possibility, not a confirmed event.")
        }
    }

    private data class Sample(val y: Float, val lane: BattlefieldStateModel.Lane, val time: Long)
    private val history = mutableMapOf<Int, MutableList<Sample>>() 

    @Synchronized fun evaluate(
        battlefield: List<BattlefieldUnderstandingEngine.TrackedObject>,
        hand: List<String>,
        ownElixir: Int?,
        combo: TacticalCombinationEngine.Combo?,
        tacticalPlan: TacticalDecisionPlanner.Plan,
        nowMs: Long
    ): Prediction {
        val currentIds = battlefield.map { it.trackId }.toSet()
        history.keys.retainAll(currentIds)
        battlefield.filter {
            it.side == BattlefieldStateModel.Side.ENEMY &&
                it.kind == BattlefieldUnderstandingEngine.ObjectKind.TROOP && it.confidence >= 0.70f
        }.forEach { obj ->
            val samples = history.getOrPut(obj.trackId) { ArrayDeque() }
            if (samples.lastOrNull()?.time != nowMs) samples.add(Sample(obj.centerY, obj.lane, nowMs))
            while (samples.size > 5) samples.removeAt(0)
        }

        val eligible = battlefield.filter {
            it.side == BattlefieldStateModel.Side.ENEMY &&
                it.kind == BattlefieldUnderstandingEngine.ObjectKind.TROOP && it.confidence >= 0.70f
        }
        val advancing = eligible.filter { obj ->
            val samples = history[obj.trackId].orEmpty().toList()
            samples.size >= requiredSamples && samples.zipWithNext().count { (a, b) -> b.y - a.y >= 0.004f } >= 2
        }
        val laneCounts = advancing.filter { it.lane != BattlefieldStateModel.Lane.UNKNOWN }
            .groupingBy { it.lane }.eachCount()
        val leadingLane = laneCounts.maxByOrNull { it.value }
        val laneText = when {
            advancing.isEmpty() -> "No repeated advancing enemy-troop pattern confirmed; both lanes remain uncertain."
            leadingLane == null -> "Enemy movement pattern observed, but lane is unknown."
            else -> "${leadingLane.key.name.lowercase()} lane pressure is increasing (${leadingLane.value} tracked object(s)); verify visually."
        }
        val threat = when {
            advancing.isEmpty() && eligible.isEmpty() -> Threat.UNKNOWN
            advancing.isEmpty() -> Threat.LOW
            advancing.size >= 2 || advancing.any { it.towerProximity == "NEAR_TOWER_ZONE" } -> Threat.HIGH
            else -> Threat.MEDIUM
        }
        val affordable = hand.distinct().filter { card ->
            val cost = CardCatalog.costs[card]
            ownElixir != null && cost != null && cost <= ownElixir
        }
        val alternatives = mutableListOf<String>()
        alternatives += if (advancing.isNotEmpty()) "Defend: ${tacticalPlan.recommendation}" else "Defend: keep a response ready; no advancing threat is confirmed"
        alternatives += "Wait: preserve elixir and gather another observation"
        alternatives += if (combo != null && advancing.isEmpty() && ownElixir != null && combo.totalCost <= ownElixir &&
            combo.lead in hand && combo.support in hand) "Counterattack: ${combo.lead} + ${combo.support} is affordable" else
            "Counterattack: not selected (no verified safe opening and affordable recognised combo)"

        val preferred = when {
            advancing.isNotEmpty() -> Move.DEFEND
            combo != null && ownElixir != null && combo.totalCost <= ownElixir && combo.lead in hand && combo.support in hand -> Move.COUNTERATTACK
            else -> Move.WAIT
        }
        val why = when (preferred) {
            Move.DEFEND -> "At least one enemy-side troop has a repeated downward movement trend across $requiredSamples or more samples. Defence takes priority; exact identity and outcome are not predicted."
            Move.COUNTERATTACK -> "No repeated advancing enemy threat is currently confirmed, and both combo cards are in the recognised hand with sufficient reported elixir (${ownElixir}/10). This is only an opportunity, not a guarantee."
            Move.WAIT -> "The available evidence does not justify a counterattack. ${if (ownElixir == null) "Elixir is unconfirmed." else "Affordable recognised cards: ${affordable.size}."} Waiting avoids spending on a guess."
        }
        val status = if (eligible.isEmpty()) "INSUFFICIENT ENEMY-TROOP EVIDENCE" else "COARSE TREND ONLY"
        val confidence = when {
            advancing.isNotEmpty() && leadingLane != null -> "Low-to-moderate: repeated broad detector tracks; no exact card identity or path prediction."
            advancing.isNotEmpty() -> "Low: movement trend exists but lane assignment is uncertain."
            else -> "Low/unknown: insufficient repeated evidence for an advancing threat."
        }
        return Prediction(status, laneText, threat, alternatives, preferred, why, confidence)
    }

    @Synchronized fun reset() { history.clear() }
}

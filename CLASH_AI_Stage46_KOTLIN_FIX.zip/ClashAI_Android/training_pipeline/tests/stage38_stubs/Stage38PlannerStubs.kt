package com.clashai.coach
object CardCatalog {
 val costs = mapOf("Cannon" to 3, "Musketeer" to 4, "Knight" to 3, "Hog Rider" to 4, "Fireball" to 4)
 fun countersFor(card: String) = when(card) { "Hog Rider" -> listOf("Cannon"); "Balloon" -> listOf("Musketeer"); else -> emptyList() }
}
class TacticalCombinationEngine { data class Combo(val lead:String,val support:String,val totalCost:Int,val reason:String,val confidence:String) }
class GameModeIntelligence { enum class Mode { NORMAL, CHAOS } }
class BattlefieldUnderstandingEngine {
 enum class TroopDomain { AIR, GROUND, UNKNOWN }; enum class ObjectKind { TROOP, BUILDING, SPELL_EFFECT, UNKNOWN }
 data class TrackedObject(val trackId:Int,val label:String,val kind:ObjectKind,val troopDomain:TroopDomain,val side:BattlefieldStateModel.Side,val lane:BattlefieldStateModel.Lane,val movement:BattlefieldStateModel.Movement,val confidence:Float,val identityConfirmed:Boolean,val centerX:Float,val centerY:Float,val towerProximity:String)
}
class BattlefieldStateModel { enum class Side { FRIENDLY, ENEMY, UNKNOWN }; enum class Lane { LEFT, RIGHT, CENTER, UNKNOWN }; enum class Movement { TOWARD_TOP, TOWARD_BOTTOM, MOSTLY_STATIONARY, UNKNOWN } }

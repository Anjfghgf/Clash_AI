package com.clashai.coach

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ImageView
import android.graphics.BitmapFactory
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var timerText: TextView
    private lateinit var enemyCardsText: TextView
    private lateinit var enemyElixirText: TextView
    private lateinit var ownElixirText: TextView
    private lateinit var adviceText: TextView
    private lateinit var handText: TextView
    private lateinit var ocrText: TextView
    private lateinit var deploymentText: TextView
    private lateinit var cycleText: TextView
    private lateinit var memoryText: TextView
    private val battleMemory = BattleMemory()
    private lateinit var deploymentPreview: ImageView
    private val deploymentSamples = mutableListOf<String>()
    private val observed = linkedSetOf<String>()
    private val hand = linkedSetOf<String>()
    private val enemySpend = mutableListOf<Int?>()
    private val enemyPlays = mutableListOf<String>()
    private val enemyPlayTimes = mutableListOf<Long>()
    private var startedAt = 0L
    private var running = false
    private var ownElixir = 5
    private var doubleElixir = false
    private val handler = Handler(Looper.getMainLooper())

    private val ticker = object : Runnable {
        override fun run() {
            if (running) {
                refreshElixir()
                handler.postDelayed(this, 1000)
            }
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == ScreenCaptureService.ACTION_DEPLOYMENT_CANDIDATE) {
                val sample = intent.getStringExtra(ScreenCaptureService.EXTRA_SNAPSHOT_PATH).orEmpty()
                if (sample.isNotBlank()) {
                    deploymentSamples.add(sample)
                    BitmapFactory.decodeFile(sample)?.let { deploymentPreview.setImageBitmap(it) }
                }
                deploymentText.text = "Possible opponent deployment detected (${deploymentSamples.size} sample(s)). Latest opponent-arena crop shown below. Confirm the card in the tracker; identity is not automatic yet."
                status.text = "Battlefield activity detected — awaiting card confirmation."
                return
            }
            val recognized = intent?.getStringExtra(ScreenCaptureService.EXTRA_TEXT).orEmpty()
            if (recognized.isNotBlank()) {
                ocrText.text = "Latest screen text:\n$recognized"
            }
        }
    }

    private val captureLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val service = Intent(this, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_START
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
            }
            ContextCompat.startForegroundService(this, service)
            status.text = "Screen analysis is running. Card artwork is not yet automatically classified."
        } else status.text = "Screen capture permission was not granted."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CardCatalog.initialize(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 32)
            setBackgroundColor(0xFF101827.toInt())
        }
        fun heading(value: String, size: Float = 18f) = TextView(this).apply {
            text = value; textSize = size; setTextColor(0xFFFFFFFF.toInt()); setPadding(0, 12, 0, 7)
        }
        fun section(value: String) { root.addView(heading(value, 20f)) }
        fun note(value: String): TextView = heading(value, 14f).also { root.addView(it) }
        fun button(value: String, action: () -> Unit) {
            root.addView(Button(this).apply { text = value; setOnClickListener { action() } })
        }
        root.addView(heading("CLASH AI COACH", 27f))
        root.addView(heading("LIVE BATTLE ASSISTANT", 13f))
        status = note("Ready. Start a match, then start screen analysis.")
        button("START SCREEN ANALYSIS") { requestCapture() }
        button("STOP SCREEN ANALYSIS") {
            startService(Intent(this, ScreenCaptureService::class.java).setAction(ScreenCaptureService.ACTION_STOP))
            status.text = "Screen analysis stopped."
        }

        section("BATTLE TIMER & ELIXIR")
        timerText = note("Match not started")
        enemyElixirText = note("Enemy elixir estimate: 5 / 10")
        ownElixirText = note("Your elixir: 5 / 10 (adjust below)")
        val seek = SeekBar(this).apply { max = 10; progress = ownElixir }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) { ownElixir = progress; ownElixirText.text = "Your elixir: $ownElixir / 10 (manual estimate)"; updateCoach() }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(seek)
        button("START / RESET MATCH TIMER") { resetMatch() }
        button("FORCE DOUBLE ELIXIR OVERRIDE") { doubleElixir = !doubleElixir; updateCoach(); status.text = if (doubleElixir) "Double elixir override ON" else "Automatic elixir timing restored" }
        button("+1 YOUR ELIXIR") { ownElixir = (ownElixir + 1).coerceAtMost(10); seek.progress = ownElixir; ownElixirText.text = "Your elixir: $ownElixir / 10 (manual estimate)"; updateCoach() }
        button("-1 YOUR ELIXIR") { ownElixir = (ownElixir - 1).coerceAtLeast(0); seek.progress = ownElixir; ownElixirText.text = "Your elixir: $ownElixir / 10 (manual estimate)"; updateCoach() }

        section("LIVE ENEMY DEPLOYMENT DETECTION")
        deploymentText = note("Waiting for a battlefield change. This detects possible activity, not the card name yet.")
        deploymentPreview = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(0xFF263449.toInt())
            minimumHeight = 180
        }
        root.addView(deploymentPreview, LinearLayout.LayoutParams(-1, 260))
        note("When a deployment is detected, review the opponent-arena crop and tap its card in the tracker below to confirm the identity.")

        section("BATTLE MEMORY & RECENT PLAYS")
        memoryText = note("Recent confirmed enemy plays will appear here.")
        note("Battle memory is local to this match. Confirm card identities manually; screen activity detection does not identify card artwork.")

        section("ENEMY CARD CYCLE")
        cycleText = note("Play four other cards after a card is used before it cycles back.")

        section("ENEMY CARD TRACKER")
        enemyCardsText = note("No enemy cards recorded yet.")
        note("Tap a card when you see the opponent play it. OCR text matches are only possible observations.")
        addCardButtons(root, "Record enemy card", CardCatalog.names) { card ->
            enemyPlays.add(card); observed.add(card); enemySpend.add(CardCatalog.costs[card]); enemyPlayTimes.add(elapsedSeconds()); battleMemory.record(card, elapsedSeconds()); updateCoach()
        }
        button("UNDO LAST ENEMY CARD") {
            if (enemySpend.isNotEmpty()) { enemySpend.removeAt(enemySpend.lastIndex); enemyPlays.removeAt(enemyPlays.lastIndex); enemyPlayTimes.removeAt(enemyPlayTimes.lastIndex); battleMemory.undo(); observed.clear(); observed.addAll(enemyPlays); updateCoach() }
        }
        button("CLEAR ENEMY CARD LOG") { observed.clear(); enemySpend.clear(); enemyPlays.clear(); enemyPlayTimes.clear(); battleMemory.clear(); updateCoach() }

        section("YOUR 4 CARD HAND")
        handText = note("Select up to 4 cards currently in your hand.")
        addCardButtons(root, "Select / unselect your card", CardCatalog.names) { card ->
            if (hand.contains(card)) hand.remove(card) else if (hand.size < 4) hand.add(card)
            handText.text = if (hand.isEmpty()) "Select up to 4 cards currently in your hand." else "Your hand: ${hand.joinToString(" • ")}"
            updateCoach()
        }
        button("CLEAR MY HAND") { hand.clear(); handText.text = "Select up to 4 cards currently in your hand."; updateCoach() }

        section("AI DEFENCE & ATTACK ADVICE")
        adviceText = note("Record an enemy card and select your hand to receive suggestions.")
        section("SCREEN TEXT OBSERVATIONS")
        ocrText = note("Waiting for screen capture…")
        root.addView(heading("Live detection beta: captures local opponent-arena samples when large visual changes occur. These samples are evidence for review, not confirmed card identities. OCR is diagnostic only. Enemy elixir is an estimate based on logged plays and the match phase.", 12f))
        setContentView(ScrollView(this).apply { addView(root) })
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
        }
        updateCoach()
    }

    private fun addCardButtons(root: LinearLayout, title: String, cards: List<String>, action: (String) -> Unit) {
        root.addView(TextView(this).apply { text = title; textSize = 12f; setTextColor(0xFFB8C5D8.toInt()); setPadding(0, 6, 0, 4) })
        // Compact text buttons keep the app usable on a phone without requiring external card images.
        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        cards.chunked(3).forEach { group ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            group.forEach { card ->
                row.addView(Button(this).apply {
                    text = "$card\n${CardCatalog.costs[card] ?: "?"} elixir"
                    textSize = 10f
                    isAllCaps = false
                    setOnClickListener { action(card) }
                }, LinearLayout.LayoutParams(0, -2, 1f))
            }
            rows.addView(row)
        }
        root.addView(rows)
    }

    private fun resetMatch() {
        startedAt = System.currentTimeMillis(); running = true; doubleElixir = false
        enemySpend.clear(); enemyPlays.clear(); enemyPlayTimes.clear(); observed.clear(); deploymentSamples.clear(); battleMemory.clear(); ownElixir = 5
        refreshElixir(); handler.removeCallbacks(ticker); handler.post(ticker); updateCoach()
        status.text = "Match timer started. Log enemy plays as they happen."
    }

    private fun elapsedSeconds(): Long = if (startedAt == 0L) 0L else ((System.currentTimeMillis() - startedAt) / 1000L).coerceAtLeast(0L)

    private fun regenBetween(start: Long, end: Long): Double {
        var cursor = start
        var amount = 0.0
        while (cursor < end) {
            val phaseBoundary = when {
                cursor < 120L -> 120L
                cursor < 240L -> 240L
                else -> end
            }
            val next = minOf(end, phaseBoundary)
            val secondsPerElixir = when {
                cursor >= 240L -> 2.8 / 3.0
                doubleElixir || cursor >= 120L -> 1.4
                else -> 2.8
            }
            amount += (next - cursor).toDouble() / secondsPerElixir
            cursor = next
        }
        return amount
    }

    private fun refreshElixir() {
        val elapsed = elapsedSeconds()
        val phase = when { elapsed >= 240L -> 3; doubleElixir || elapsed >= 120L -> 2; else -> 1 }
        val spent = enemySpend.filterNotNull().sum()
        var estimate = 5.0
        var previousTime = 0L
        for (index in enemySpend.indices) {
            val playTime = enemyPlayTimes.getOrNull(index) ?: previousTime
            estimate = (estimate + regenBetween(previousTime, playTime)).coerceAtMost(10.0)
            enemySpend[index]?.let { estimate = (estimate - it).coerceAtLeast(0.0) }
            previousTime = playTime
        }
        estimate = (estimate + regenBetween(previousTime, elapsed)).coerceIn(0.0, 10.0)
        val mins = elapsed / 60; val secs = elapsed % 60
        timerText.text = String.format(Locale.US, "Match time: %02d:%02d", mins, secs)
        enemyElixirText.text = String.format(Locale.US, "Enemy elixir estimate: %.1f / 10  •  known logged spend: %d  •  %s", estimate, spent, when (phase) { 3 -> "TRIPLE"; 2 -> "DOUBLE"; else -> "SINGLE" })
        ownElixirText.text = "Your elixir: $ownElixir / 10 (manual estimate)"
    }

    private fun updateCoach() {
        enemyCardsText.text = if (observed.isEmpty()) "No enemy cards recorded yet." else observed.joinToString(" • ")
        refreshElixir()
        val latest = enemyPlays.lastOrNull()
        val cycleHints = observed.mapNotNull { card ->
            val lastIndex = enemyPlays.indexOfLast { it == card }
            if (lastIndex < 0) null else {
                val playedSince = enemyPlays.lastIndex - lastIndex
                "$card: ${(4 - playedSince).coerceAtLeast(0)} card(s)"
            }
        }
        memoryText.text = "${battleMemory.count()} confirmed play(s) this match\n" + battleMemory.recentSummary(8)
        cycleText.text = if (battleMemory.count() == 0) "No enemy cycle data yet." else battleMemory.cycleSummary()
        val counterOptions = latest?.let { CardCatalog.countersFor(it) }.orEmpty()
        val available = counterOptions.filter { hand.contains(it) }
        val defence = when {
            latest == null -> "Record the enemy's latest card to get specific defence advice."
            available.isNotEmpty() -> "DEFEND vs $latest: use ${available.joinToString(" or ")}. These are suggested counters, not guaranteed wins."
            counterOptions.isNotEmpty() -> "DEFEND vs $latest: common answers include ${counterOptions.take(3).joinToString(", ")}. Select your actual hand to narrow the advice."
            else -> "DEFEND: keep a building or a suitable high-DPS / swarm answer ready for $latest. Avoid overspending."
        }
        val attack = when {
            hand.isEmpty() -> "ATTACK: select your four-card hand for card-specific attack suggestions."
            ownElixir < 4 -> "ATTACK: wait for more elixir or use a low-cost cycle card. Avoid committing your whole hand."
            observed.isEmpty() -> "ATTACK: build a push behind a surviving defender; keep enough elixir for their likely counter."
            else -> "ATTACK: consider a small counter-push with ${hand.first()}; don't stack support into a spell they've shown. Track their remaining counters before committing."
        }
        adviceText.text = "$defence\n\n$attack\n\nTRACKING: ${observed.size} unique enemy card(s) recorded; ${enemySpend.size} enemy play(s) logged."
    }

    @Suppress("DEPRECATION")
    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply { addAction(ScreenCaptureService.ACTION_OCR); addAction(ScreenCaptureService.ACTION_DEPLOYMENT_CANDIDATE) }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(screenReceiver, filter)
    }

    override fun onStop() { runCatching { unregisterReceiver(screenReceiver) }; super.onStop() }
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); super.onDestroy() }

    private fun requestCapture() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        captureLauncher.launch(manager.createScreenCaptureIntent())
    }
}

package com.clashai.coach

import kotlin.math.hypot

/**
 * Stage 36: turns full-frame detector boxes into a conservative, temporal arena state.
 * It deliberately keeps broad object class, troop domain, team and exact card identity
 * separate. Generic `troop` detections never become air/ground or a named card by guess.
 */
class BattlefieldUnderstandingEngine(
    private val stateModel: BattlefieldStateModel = BattlefieldStateModel(),
    private val maxAssociationDistance: Float = 0.14f,
    private val staleAfterMs: Long = 6500L
) {
    enum class ObjectKind { TROOP, BUILDING, SPELL_EFFECT, UNKNOWN }
    enum class TroopDomain { AIR, GROUND, UNKNOWN }

    data class TrackedObject(
        val trackId: Int,
        val label: String,
        val kind: ObjectKind,
        val troopDomain: TroopDomain,
        val side: BattlefieldStateModel.Side,
        val lane: BattlefieldStateModel.Lane,
        val movement: BattlefieldStateModel.Movement,
        val confidence: Float,
        val identityConfirmed: Boolean,
        val centerX: Float,
        val centerY: Float,
        val towerProximity: String
    )

    data class Snapshot(
        val objects: List<TrackedObject>,
        val state: BattlefieldStateModel.Snapshot,
        val summary: String,
        val modelReady: Boolean
    )

    private data class MutableTrack(
        val id: Int,
        var label: String,
        var x: Float,
        var y: Float,
        var vx: Float,
        var vy: Float,
        var lastSeenMs: Long,
        var hits: Int
    )

    private val tracks = linkedMapOf<Int, MutableTrack>()
    private var nextId = 1

    @Synchronized
    fun update(
        detections: List<ArenaObjectDetectionPostprocessor.Detection>,
        timestampMs: Long,
        modelReady: Boolean
    ): Snapshot {
        val seen = mutableSetOf<Int>()
        val observations = mutableListOf<BattlefieldStateModel.Observation>()
        val assigned = mutableListOf<Pair<Int, ArenaObjectDetectionPostprocessor.Detection>>()

        detections.sortedByDescending { it.confidence }.forEach { detection ->
            val x = ((detection.left + detection.right) / 2f).coerceIn(0f, 1f)
            val y = ((detection.top + detection.bottom) / 2f).coerceIn(0f, 1f)
            val match = tracks.values
                .filter { it.id !in seen && it.label.equals(detection.label, ignoreCase = true) }
                .map { it to hypot(x - it.x, y - it.y) }
                .filter { it.second <= maxAssociationDistance }
                .minByOrNull { it.second }?.first

            val track = if (match == null) {
                MutableTrack(nextId++, detection.label, x, y, 0f, 0f, timestampMs, 1)
                    .also { tracks[it.id] = it }
            } else {
                val dt = ((timestampMs - match.lastSeenMs).coerceAtLeast(1L)) / 1000f
                val instantVx = (x - match.x) / dt
                val instantVy = (y - match.y) / dt
                match.vx = match.vx * 0.55f + instantVx * 0.45f
                match.vy = match.vy * 0.55f + instantVy * 0.45f
                match.x = x
                match.y = y
                match.label = detection.label
                match.lastSeenMs = timestampMs
                match.hits++
                match
            }
            seen += track.id
            assigned += track.id to detection
            observations += BattlefieldStateModel.Observation(
                trackId = track.id,
                centerX = x,
                centerY = y,
                velocityX = track.vx,
                velocityY = track.vy,
                detectorLabel = detection.label,
                detectorConfidence = detection.confidence,
                timestampMs = timestampMs
            )
        }

        tracks.entries.removeAll { timestampMs - it.value.lastSeenMs > staleAfterMs }
        val state = stateModel.update(observations)
        val stateById = state.objects.associateBy { it.trackId }
        val objects = assigned.mapNotNull { (id, detection) ->
            val s = stateById[id] ?: return@mapNotNull null
            val kind = kindFor(detection.label)
            val domain = domainFor(detection.label)
            TrackedObject(
                trackId = id,
                label = detection.label,
                kind = kind,
                troopDomain = domain,
                side = s.side,
                lane = s.lane,
                movement = s.movement,
                confidence = detection.confidence.coerceIn(0f, 1f),
                identityConfirmed = s.identityConfirmed,
                centerX = s.centerX,
                centerY = s.centerY,
                towerProximity = towerProximity(s.side, s.centerY)
            )
        }
        val summary = when {
            !modelReady -> "BATTLEFIELD: detector model not installed; motion-only hints are not troop identities."
            objects.isEmpty() -> "BATTLEFIELD: detector ready; no objects passed the confidence threshold."
            else -> buildString {
                append("BATTLEFIELD: ${objects.size} detected object(s)")
                val friendly = objects.count { it.side == BattlefieldStateModel.Side.FRIENDLY }
                val enemy = objects.count { it.side == BattlefieldStateModel.Side.ENEMY }
                val unknown = objects.size - friendly - enemy
                append(" · friendly $friendly · enemy $enemy · uncertain $unknown")
                if (objects.any { it.troopDomain == TroopDomain.UNKNOWN && it.kind == ObjectKind.TROOP }) {
                    append(" · air/ground subtype unknown")
                }
            }
        }
        return Snapshot(objects, state, summary, modelReady)
    }

    private fun kindFor(label: String): ObjectKind = when {
        label.contains("building", true) -> ObjectKind.BUILDING
        label.contains("spell", true) || label.contains("effect", true) -> ObjectKind.SPELL_EFFECT
        label.contains("troop", true) || label.contains("unit", true) -> ObjectKind.TROOP
        else -> ObjectKind.UNKNOWN
    }

    private fun domainFor(label: String): TroopDomain = when {
        label.contains("air", true) -> TroopDomain.AIR
        label.contains("ground", true) -> TroopDomain.GROUND
        else -> TroopDomain.UNKNOWN
    }

    /** Standard portrait arena approximation; not a precise pathing or tower-target calculation. */
    private fun towerProximity(side: BattlefieldStateModel.Side, y: Float): String {
        val distance = when (side) {
            BattlefieldStateModel.Side.ENEMY -> kotlin.math.abs(y - 0.13f)
            BattlefieldStateModel.Side.FRIENDLY -> kotlin.math.abs(y - 0.87f)
            BattlefieldStateModel.Side.UNKNOWN -> return "UNKNOWN"
        }
        return when {
            distance <= 0.18f -> "NEAR_TOWER_ZONE"
            distance <= 0.38f -> "MID_ARENA"
            else -> "FAR_FROM_TOWER"
        }
    }

    @Synchronized fun reset() {
        tracks.clear()
        stateModel.reset()
        nextId = 1
    }
}

package com.clashai.coach

import kotlin.math.max
import kotlin.math.min

/**
 * Stage 17: post-processes raw YOLOv8-style TFLite detection output.
 * Supports [1, 4+classes, candidates] and [1, candidates, 4+classes].
 * Coordinates are interpreted as xywh in model-input pixels, or normalized xywh
 * when all four values are within approximately [0,1]. This is a postprocessor,
 * not a model loader and not connected to live capture until a compatible model exists.
 */
class ArenaObjectDetectionPostprocessor(
    private val labels: List<String>,
    private val inputSize: Int = 640,
    private val confidenceThreshold: Float = 0.35f,
    private val iouThreshold: Float = 0.45f,
    private val maxDetections: Int = 40
) {
    data class Detection(
        val classIndex: Int,
        val label: String,
        val confidence: Float,
        val left: Float,
        val top: Float,
        val right: Float,
        val bottom: Float
    )

    init {
        require(labels.isNotEmpty()) { "Detection labels must not be empty" }
        require(labels.all { it.isNotBlank() }) { "Detection labels must be non-empty" }
        require(inputSize > 0)
        require(confidenceThreshold in 0f..1f && iouThreshold in 0f..1f)
        require(maxDetections > 0)
    }

    /** outputShape excludes batch dimension, e.g. [4+classes, candidates]. */
    fun decode(values: FloatArray, outputShape: IntArray): List<Detection> {
        if (outputShape.size != 2 || outputShape.any { it <= 0 }) return emptyList()
        val a = outputShape[0]
        val b = outputShape[1]
        val channelFirst = a == 4 + labels.size
        val channelLast = b == 4 + labels.size
        if (!channelFirst && !channelLast) return emptyList()
        val candidates = if (channelFirst) b else a
        if (values.size != a * b) return emptyList()
        val raw = ArrayList<Detection>()

        fun at(candidate: Int, channel: Int): Float =
            if (channelFirst) values[channel * candidates + candidate]
            else values[candidate * (4 + labels.size) + channel]

        for (i in 0 until candidates) {
            val cx = at(i, 0); val cy = at(i, 1)
            val w = at(i, 2); val h = at(i, 3)
            if (!cx.isFinite() || !cy.isFinite() || !w.isFinite() || !h.isFinite() || w <= 0f || h <= 0f) continue
            var bestClass = -1
            var bestScore = 0f
            for (c in labels.indices) {
                val score = at(i, 4 + c)
                if (score.isFinite() && score > bestScore) { bestScore = score; bestClass = c }
            }
            if (bestClass < 0 || bestScore < confidenceThreshold) continue
            val normalized = max(max(kotlin.math.abs(cx), kotlin.math.abs(cy)), max(w, h)) <= 1.5f
            val scale = if (normalized) 1f else inputSize.toFloat()
            val left = ((cx - w / 2f) / scale).coerceIn(0f, 1f)
            val top = ((cy - h / 2f) / scale).coerceIn(0f, 1f)
            val right = ((cx + w / 2f) / scale).coerceIn(0f, 1f)
            val bottom = ((cy + h / 2f) / scale).coerceIn(0f, 1f)
            if (right <= left || bottom <= top) continue
            raw += Detection(bestClass, labels[bestClass], bestScore, left, top, right, bottom)
        }
        return classAwareNms(raw).take(maxDetections)
    }

    private fun classAwareNms(items: List<Detection>): List<Detection> {
        val kept = mutableListOf<Detection>()
        items.sortedByDescending { it.confidence }.forEach { candidate ->
            val suppressed = kept.any { existing ->
                existing.classIndex == candidate.classIndex && iou(existing, candidate) > iouThreshold
            }
            if (!suppressed) kept += candidate
        }
        return kept
    }

    private fun iou(a: Detection, b: Detection): Float {
        val iw = (min(a.right, b.right) - max(a.left, b.left)).coerceAtLeast(0f)
        val ih = (min(a.bottom, b.bottom) - max(a.top, b.top)).coerceAtLeast(0f)
        val intersection = iw * ih
        val areaA = (a.right - a.left) * (a.bottom - a.top)
        val areaB = (b.right - b.left) * (b.bottom - b.top)
        val union = areaA + areaB - intersection
        return if (union > 0f) intersection / union else 0f
    }
}

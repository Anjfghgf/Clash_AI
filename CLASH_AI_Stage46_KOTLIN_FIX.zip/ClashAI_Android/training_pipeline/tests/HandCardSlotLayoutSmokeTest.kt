package com.clashai.coach

fun main() {
    val slots = HandCardSlotLayout.forFrame(360, 800)
    check(slots.size == 4)
    check(slots.map { it.index } == listOf(0, 1, 2, 3))
    check(slots.all { it.left >= 0f && it.top >= 0f && it.right <= 1f && it.bottom <= 1f })
    check(slots.all { it.left < it.right && it.top < it.bottom })
    check(HandCardSlotLayout.forFrame(800, 360).isEmpty())
    check(HandCardSlotLayout.forFrame(0, 0).isEmpty())
    println("Stage 23 hand-slot layout smoke checks passed")
}

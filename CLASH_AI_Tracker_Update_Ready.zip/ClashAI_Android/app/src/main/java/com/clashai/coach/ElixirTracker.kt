package com.clashai.coach

import kotlin.math.min

/** Time-based estimate. It does not read the opponent's hidden elixir bar. */
class ElixirTracker {
    private var start = 0L
    private var pausedAt = 0L
    private var pausedTotal = 0L
    private var paused = false
    private var spent = 0

    fun start(now: Long = System.currentTimeMillis()) {
        start = now; pausedAt = 0L; pausedTotal = 0L; paused = false; spent = 0
    }
    fun setPaused(value: Boolean, now: Long = System.currentTimeMillis()) {
        if (value && !paused) { paused = true; pausedAt = now }
        else if (!value && paused) { pausedTotal += now - pausedAt; paused = false }
    }
    fun spend(cost: Int) { spent += cost.coerceAtLeast(0) }
    fun refund(cost: Int) { spent = (spent - cost.coerceAtLeast(0)).coerceAtLeast(0) }
    fun elapsedSeconds(now: Long = System.currentTimeMillis()): Int {
        if (start == 0L) return 0
        val end = if (paused) pausedAt else now
        return ((end - start - pausedTotal).coerceAtLeast(0) / 1000L).toInt()
    }
    fun current(doubleElixir: Boolean, now: Long = System.currentTimeMillis()): Double {
        val elapsed = elapsedSeconds(now).toDouble()
        val single = if (doubleElixir) min(elapsed, 120.0) else elapsed
        val double = if (doubleElixir) (elapsed - 120.0).coerceAtLeast(0.0) else 0.0
        return (5.0 + single / 2.8 + double / 1.4 - spent).coerceIn(0.0, 10.0)
    }
}

# CLASH AI — Stage 26: Live Battle Decision Integration

Version: 0.25.0 (versionCode 25)

## Added
- The screen-capture service now passes the four-slot hand recognizer's stable results into the existing explainable BattleDecisionEngine.
- Card-specific advice is enabled only when all four slots have stable, distinct card identities.
- Own elixir is treated as confirmed only after repeated lower-HUD OCR readings. A single OCR read is not used for affordability advice.
- Decision logic now accepts an unknown own-elixir value and avoids making exact affordability claims when it is unknown.
- Live tactical advice is retained in the floating coach between OCR refreshes instead of being overwritten by the next visual-status update.
- Battlefield motion counts are included as tentative evidence, not troop identities.

## Important limitations
- No trained card_classifier.tflite is bundled. Automatic card names therefore remain unavailable until the user imports a correctly trained model.
- Enemy card plays/deck and enemy elixir are not yet automatically confirmed in this live service path. The decision engine labels enemy elixir unknown and does not invent a value.
- The decision engine is rule-based coaching, not a trained strategy policy or autonomous gameplay. It does not tap cards or control the game.
- HUD crop positions and OCR accuracy need testing on the user's phone and game layout.
- Full Android APK build and live-device validation were not possible in this environment; source-level and isolated logic checks are reported separately.

## Evidence rules
- Four stable, distinct card identities required before card-specific hand advice.
- Repeated OCR required before using own elixir as a numeric input.
- Unconfirmed battlefield tracks remain tentative.
- Missing enemy information remains unknown.

package com.clashai.coach

/**
 * Stage 18: evidence-aware live coaching. It accumulates observations within a match,
 * but does not train model weights or turn visual hypotheses into confirmed card plays.
 */
class LiveBattleCoach {
    data class Advice(
        val headline: String,
        val action: String,
        val evidence: String,
        val confidence: String
    ) {
        fun render(): String = "$headline\n$action\nEvidence: $evidence\nAssessment: $confidence"
    }

    private var observations = 0
    private var persistentTrackEvents = 0
    private var transientEvents = 0
    private var stablePatternEvents = 0
    private var stableRecognitionEvents = 0
    private var lastAdviceKey = ""

    @Synchronized
    fun observe(
        regionCount: Int,
        persistentTracks: Int,
        patternLabels: List<String>,
        stableRecognitionCount: Int
    ): Advice {
        observations++
        if (persistentTracks > 0) persistentTrackEvents++
        if (patternLabels.any { it == "TRANSIENT_EFFECT_SUSPECT" }) transientEvents++
        if (patternLabels.any { it == "MOVING_OBJECT_CANDIDATE" || it == "PERSISTENT_VISUAL_OBJECT" }) stablePatternEvents++
        if (stableRecognitionCount > 0) stableRecognitionEvents++

        val moving = patternLabels.count { it == "MOVING_OBJECT_CANDIDATE" }
        val persistent = patternLabels.count { it == "PERSISTENT_VISUAL_OBJECT" }
        val key: String
        val headline: String
        val action: String
        val confidence: String
        when {
            stableRecognitionCount > 0 -> {
                key = "recognition_candidate"
                headline = "REVIEW A REPEATED CARD CANDIDATE"
                action = "Check the highlighted crop against the live arena. If you can verify the card yourself, log it; otherwise leave the enemy deck unchanged."
                confidence = "Repeated model candidate only; not a confirmed enemy play."
            }
            persistentTracks >= 2 || moving >= 2 -> {
                key = "multi_track"
                headline = "POSSIBLE MULTI-UNIT ACTIVITY"
                action = "Watch both lanes before committing. Keep some elixir available until the objects and their direction become clearer; avoid stacking support blindly."
                confidence = "Early tactical hint from multiple visual tracks, not proof of a push."
            }
            moving > 0 -> {
                key = "moving"
                headline = "MOVEMENT CANDIDATE DETECTED"
                action = "Keep watching this lane and wait for another observation. Don't spend a counter based only on motion."
                confidence = "Tentative: moving effects and animations can look like troops."
            }
            persistent > 0 -> {
                key = "persistent"
                headline = "PERSISTENT OBJECT CANDIDATE"
                action = "Observe whether it changes position or interacts with another unit. It may be a building, troop, or fixed arena animation."
                confidence = "Low-to-medium visual evidence; identity and team are unknown."
            }
            transientEvents > 0 -> {
                key = "transient"
                headline = "SHORT-LIVED EFFECT SUSPECTED"
                action = "Wait for the next frames before reacting. A brief flash or spell animation should not trigger a card or deck decision."
                confidence = "Tentative visual event."
            }
            else -> {
                key = "quiet"
                headline = "NO CLEAR BATTLEFIELD EVENT YET"
                action = "Keep your current hand and elixir in mind. The coach will offer a more specific suggestion when it has stronger evidence."
                confidence = "Insufficient visual evidence."
            }
        }
        lastAdviceKey = key
        val evidence = "observations=$observations; events with persistent tracks=$persistentTrackEvents; repeated pattern events=$stablePatternEvents; transient-effect events=$transientEvents; repeated recognition events=$stableRecognitionEvents; current motion regions=$regionCount"
        return Advice(headline, action, evidence, confidence)
    }

    @Synchronized
    fun summary(): String = "Learning this match: $observations observations · $persistentTrackEvents persistent-track events · $stablePatternEvents repeated-pattern events · $stableRecognitionEvents repeated-recognition events."

    @Synchronized
    fun reset() {
        observations = 0
        persistentTrackEvents = 0
        transientEvents = 0
        stablePatternEvents = 0
        stableRecognitionEvents = 0
        lastAdviceKey = ""
    }
}

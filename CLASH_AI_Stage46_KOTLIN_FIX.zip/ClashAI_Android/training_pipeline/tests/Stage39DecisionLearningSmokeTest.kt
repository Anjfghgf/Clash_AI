package com.clashai.coach

fun main() {
    val engine = DecisionLearningEngine()
    check(!engine.recordConfirmedOutcome(DecisionLearningEngine.Outcome.SUCCESS))
    engine.recordRecommendation("NORMAL", "DEFEND", "Consider Knight")
    check(engine.recordConfirmedOutcome(DecisionLearningEngine.Outcome.SUCCESS))
    val s = engine.statsFor("NORMAL", "DEFEND", "Consider Knight")!!
    check(s.recommendations == 1 && s.success == 1 && s.confirmedOutcomes == 1)
    check(s.successRate == 1.0)
    check(!engine.recordConfirmedOutcome(DecisionLearningEngine.Outcome.UNSUCCESSFUL))
    engine.recordRecommendation("CHAOS", "OBSERVE", "Wait for evidence")
    engine.recordConfirmedOutcome(DecisionLearningEngine.Outcome.NEUTRAL)
    val summary = engine.summary()
    check(summary.contains("2 recommendations") && summary.contains("2 player-confirmed outcomes"))
    val restored = DecisionLearningEngine()
    restored.restore(DecisionLearningEngine.Key("NORMAL", "DEFEND", "Consider Knight"), s, false)
    check(restored.statsFor("NORMAL", "DEFEND", "Consider Knight")?.success == 1)
    println("Stage 39 decision learning smoke checks passed")
}

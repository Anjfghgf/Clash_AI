package com.clashai.coach

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var textOutput: TextView
    private lateinit var enemyCards: TextView
    private lateinit var advice: TextView
    private val observed = linkedSetOf<String>()

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val recognized = intent?.getStringExtra(ScreenCaptureService.EXTRA_TEXT).orEmpty()
            if (recognized.isNotBlank()) {
                textOutput.text = "Latest screen text:\n$recognized"
                CardCatalog.findNames(recognized).forEach { observed.add(it) }
                updateCoach()
            }
        }
    }

    private val captureLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val service = Intent(this, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_START
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
            }
            ContextCompat.startForegroundService(this, service)
            status.text = "Screen analysis is running. Android shows a capture notification."
        } else status.text = "Screen capture permission was not granted."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFF101827.toInt())
        }
        fun heading(value: String, size: Float = 18f) = TextView(this).apply {
            text = value; textSize = size; setTextColor(0xFFFFFFFF.toInt()); setPadding(0, 12, 0, 8)
        }
        root.addView(heading("CLASH AI COACH", 26f))
        root.addView(heading("Live screen companion • Prototype", 14f))
        status = heading("Ready. Start a Clash Royale match, then tap Start screen analysis.", 14f)
        root.addView(status)
        val start = Button(this).apply { text = "Start screen analysis"; setOnClickListener { requestCapture() } }
        root.addView(start)
        root.addView(Button(this).apply {
            text = "Stop analysis"
            setOnClickListener {
                startService(Intent(this@MainActivity, ScreenCaptureService::class.java).setAction(ScreenCaptureService.ACTION_STOP))
                status.text = "Screen analysis stopped."
            }
        })
        root.addView(heading("Opponent cards detected in readable screen text"))
        enemyCards = heading("No cards observed yet.", 14f); root.addView(enemyCards)
        root.addView(heading("Coach suggestion"))
        advice = heading("Play normally. As card names are detected, this prototype will estimate their elixir costs.", 14f)
        root.addView(advice)
        root.addView(heading("Screen text (OCR)"))
        textOutput = heading("Waiting for screen capture…", 13f); root.addView(textOutput)
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
        }
    }

    @Suppress("DEPRECATION")
    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(ScreenCaptureService.ACTION_OCR)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(screenReceiver, filter)
    }

    override fun onStop() {
        runCatching { unregisterReceiver(screenReceiver) }
        super.onStop()
    }

    private fun requestCapture() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        captureLauncher.launch(manager.createScreenCaptureIntent())
    }

    private fun updateCoach() {
        enemyCards.text = if (observed.isEmpty()) "No cards observed yet." else observed.joinToString(" • ")
        val avg = observed.mapNotNull { CardCatalog.costs[it] }.average()
        advice.text = if (observed.isEmpty()) "No reliable card names detected yet. Card artwork recognition is not included in this prototype."
        else "${observed.size} possible card name(s) found in OCR text. Their average listed cost is ${"%.1f".format(avg)} elixir. This is not yet a confirmed enemy deck or live elixir count."
    }
}

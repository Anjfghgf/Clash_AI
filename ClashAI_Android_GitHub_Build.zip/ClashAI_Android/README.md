# CLASH AI Coach

Android companion app for Clash Royale battle coaching.

## Current features
- Bundled Clash Royale card catalogue and known elixir costs.
- Manual enemy-card play log and player-hand selection.
- Enemy card-cycle estimates based on the last four confirmed opponent plays.
- Enemy elixir simulation that applies logged card costs at their play timestamps, respects the 10-elixir cap, and changes regeneration by match phase.
- Approximate match timer with automatic single/double/triple-elixir phase labels; a manual double-elixir override is also available.
- Basic defensive counter and offensive coaching suggestions.
- User-approved Android MediaProjection screen capture with a persistent foreground notification.
- On-device OCR diagnostics.
- Experimental opponent-arena visual-change detector.
- When a large opponent-arena change is detected, the app saves a local crop and displays the latest crop in the app for review.

## Recognition status and limitations
The visual-change detector only flags possible battlefield activity. The crop is diagnostic evidence; it is **not** a confirmed enemy-card identity. The app still requires the player to confirm the card in the enemy tracker. OCR is diagnostic only and does not reliably identify troop sprites. A trained on-device object-detection/classification model and representative labelled gameplay frames are still required for reliable automatic card naming.

Enemy elixir is an estimate, not a value read directly from the opponent's UI. It depends on the match timer and the accuracy/completeness of manually logged enemy plays. The cycle estimate is also based only on confirmed logged plays.

## Screen capture and privacy
- Screen capture starts only after the player taps Start Screen Analysis and accepts Android's system permission prompt.
- Frame analysis and deployment-crop saving happen on-device. Crops are stored in the app's private cache and are not uploaded by this app.
- A persistent notification indicates that screen analysis is active.
- Tap Stop Screen Analysis to end capture.

## Build
Open the `ClashAI_Android` folder in Android Studio or run `gradle --no-daemon assembleDebug` from this folder with Android SDK configured.

## On-device vision dataset: manual card-region annotation

When a possible opponent deployment is detected, the app stores a temporary opponent-arena crop. After the user confirms the enemy card in the tracker, CLASH AI now opens a crop selector. Drag a tight rectangle around the visible deployed unit/card artwork and choose **Save card crop**. The app stores the cropped JPEG and a JSON label locally under `filesDir/vision_samples/<card_name>/`.

These are manually labelled card-region samples intended for future on-device model training. They are not model predictions, and no automatic card recognition model is bundled in this stage. Dataset collection quality depends on clear, correctly labelled crops. Images remain on the phone unless the user exports or shares them.


## API card IDs in the vision dataset

The bundled `app/src/main/assets/cards.json` contains 123 API card records. Each manually annotated card crop now stores the matching `cardId` alongside `cardLabel`, elixir cost, rarity, and reference image URL in its JSON metadata. This preserves the official API identity for future model class mapping. The API ID is a card identifier, not a trained recognition model. No automatic card classifier is included yet; crops are labelled training data only.


## Stage 4: on-device recognition runtime foundation
- Added TensorFlow Lite runtime support and a guarded `CardRecognitionEngine`.
- The engine expects `card_classifier.tflite` and `card_labels.txt` in app assets.
- Model input contract: FLOAT32 RGB tensor `[1,224,224,3]`, values normalized to `[0,1]`.
- Model output contract: FLOAT32 `[1,class_count]` with classes in the exact order listed in `card_labels.txt` (`cardId|Card Name`).
- The engine maps model classes to the official IDs in `cards.json` and rejects predictions below 78% confidence.
- **No trained model is included in this stage.** The app reports the model as unavailable until genuine gameplay training data is used to create a compatible model. This is intentional: it prevents false automatic card calls.
- The uploaded XRecorder video is 240x552 and heavily compressed. It can help inspect match timing and large events, but it is not sufficient by itself to label all card classes reliably.

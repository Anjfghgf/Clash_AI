#!/usr/bin/env python3
"""Audit a card dataset before training; does not alter or label images."""
import argparse,csv,hashlib,json
from collections import defaultdict
from pathlib import Path
from PIL import Image

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--dataset',type=Path,required=True); ap.add_argument('--out',type=Path)
 a=ap.parse_args(); csvp=a.dataset/'labels.csv'
 if not csvp.is_file(): raise SystemExit('labels.csv not found')
 rows=list(csv.DictReader(csvp.open(encoding='utf-8-sig'))); classes=defaultdict(lambda:{'samples':0,'sessions':set(),'names':set()}); errors=[]; hashes=defaultdict(list)
 for i,r in enumerate(rows,2):
  try:
   cid=int(r['card_id']); name=r['card_name'].strip(); sid=r['session_id'].strip(); p=(a.dataset/r['image_path']).resolve()
   if not name or not sid: raise ValueError('blank card_name or session_id')
   if not p.is_file(): raise ValueError('image file missing')
   with Image.open(p) as im:
    im.verify()
   digest=hashlib.sha256(p.read_bytes()).hexdigest(); hashes[digest].append({'row':i,'session_id':sid,'card_id':cid,'path':str(p)})
   classes[cid]['samples']+=1; classes[cid]['sessions'].add(sid); classes[cid]['names'].add(name)
  except Exception as e: errors.append({'row':i,'reason':str(e)})
 duplicate_groups=[v for v in hashes.values() if len(v)>1]
 summary={str(cid):{'samples':v['samples'],'sessions':len(v['sessions']),'card_names':sorted(v['names'])} for cid,v in classes.items()}
 inconsistent={cid:v for cid,v in summary.items() if len(v['card_names'])!=1}
 report={'rows':len(rows),'valid_classes':len(classes),'classes':summary,'invalid_rows':errors,'exact_duplicate_groups':duplicate_groups,'inconsistent_card_names':inconsistent,
         'training_ready_default':not errors and not inconsistent and len(classes)>=2 and all(v['samples']>=30 and v['sessions']>=3 for v in summary.values()),
         'note':'Duplicates and repeated frames can inflate scores. Review duplicate groups and make sure each session_id is one independent match.'}
 out=a.out or a.dataset/'dataset_audit.json'; out.write_text(json.dumps(report,indent=2)); print(json.dumps({'rows':len(rows),'classes':len(classes),'invalid_rows':len(errors),'duplicate_groups':len(duplicate_groups),'training_ready_default':report['training_ready_default'],'report':str(out)},indent=2))
if __name__=='__main__': main()

# Stage 29 — Card Counter + Attack Strategy + Feedback Learning

## Added
- `CardStrategyEngine.kt` separates broad unit class (air, ground, building, spell/effect) from tactical role (win condition, tank, anti-air, splash, swarm, support, defensive building, spell, cycle).
- Curated profiles cover a useful set of common cards. Unknown/unlisted cards stay `UNKNOWN`; the system does not guess their class or role.
- Defensive recommendations use the existing counter guide, current recognised hand and confirmed elixir. Exact enemy-card counters are only used when an exact enemy card is supplied as confirmed evidence.
- Attack recommendations choose only from the recognised hand and require a confirmed elixir reading. They consider win-condition/tank role, known opponent deck warnings, cost, and learned user feedback. Advice is a suggestion, not an automatic card deployment.
- Outcome learning is persistent in app-private SharedPreferences. Main screen buttons let the user confirm whether the latest recommendation worked. Only that explicit feedback changes bounded preferences; the AI does not label its own predictions as successful.
- Fixed Stage 28 detector metadata to say `TEAM_UNCONFIRMED_FULL_FRAME`; full-frame detections do not prove which side owns an object.
- Screen capture now includes a separate `CARD STRATEGY` section in the live coach.

## Important limits
- No trained battlefield detector weights or card identity model are bundled. Broad detector labels are not exact troop/card identity.
- The current live pipeline does not yet feed a verified enemy card or a complete opponent deck into the new strategy engine. Therefore live recommendations currently focus on safe hand/elixir-aware attack choices and cautious observations; exact counter suggestions become available once confirmed enemy-card evidence is connected.
- Air/ground profiles are curated metadata for known cards, not inferred from a generic `troop` detection. Unlisted cards remain unknown.
- No autonomous game input is performed.
- Android APK build/device test remains unverified in this environment (no Gradle executable/wrapper available).

## Feedback interface
`ScreenCaptureService.ACTION_RECORD_STRATEGY_OUTCOME` accepts `strategy_mode` (`ATTACK` or `DEFEND`), `strategy_matchup`, `strategy_card`, and boolean `strategy_success`. The app's two feedback buttons send this action for the most recent displayed strategy recommendation.

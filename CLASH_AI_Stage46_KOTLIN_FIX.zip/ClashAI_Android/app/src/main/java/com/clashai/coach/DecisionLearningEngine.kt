package com.clashai.coach

/** Evidence-gated learning: recommendations are logged separately from user-confirmed outcomes. */
class DecisionLearningEngine {
    enum class Outcome { SUCCESS, NEUTRAL, UNSUCCESSFUL }
    data class Key(val mode: String, val priority: String, val recommendation: String)
    data class Stats(val recommendations: Int, val success: Int, val neutral: Int, val unsuccessful: Int) {
        val confirmedOutcomes: Int get() = success + neutral + unsuccessful
        val successRate: Double? get() = if (confirmedOutcomes == 0) null else success.toDouble() / confirmedOutcomes
    }
    private val stats = linkedMapOf<Key, MutableList<Int>>()
    private var pending: Key? = null

    @Synchronized fun recordRecommendation(mode: String, priority: String, recommendation: String): Key {
        val key = Key(mode.ifBlank { "UNKNOWN" }, priority.take(100), recommendation.take(240))
        val counts = stats.getOrPut(key) { mutableListOf(0, 0, 0, 0) }
        // OCR refreshes may repeat the same plan many times per minute; count it once
        // while that recommendation is still awaiting the player's feedback.
        if (pending != key) counts[0]++
        pending = key
        return key
    }

    /** Only call after the player explicitly reports the outcome. */
    @Synchronized fun recordConfirmedOutcome(outcome: Outcome): Boolean {
        val key = pending ?: return false
        val counts = stats[key] ?: return false
        counts[when (outcome) { Outcome.SUCCESS -> 1; Outcome.NEUTRAL -> 2; Outcome.UNSUCCESSFUL -> 3 }]++
        pending = null
        return true
    }

    @Synchronized fun statsFor(mode: String, priority: String, recommendation: String): Stats? {
        val c = stats[Key(mode, priority.take(100), recommendation.take(240))] ?: return null
        return Stats(c[0], c[1], c[2], c[3])
    }

    /** Conservative, mode-specific feedback. It never treats missing feedback as failure. */
    @Synchronized fun adaptiveInsight(mode: String, priority: String): String {
        val matching = stats.filterKeys { it.mode == mode && it.priority == priority }
        val confirmed = matching.values.sumOf { it[1] + it[2] + it[3] }
        if (confirmed < 3) return "ADAPTIVE LEARNING: collecting evidence for this mode and situation ($confirmed/3 confirmed outcomes). No strategy adjustment yet."
        val ranked = matching.mapNotNull { (key, counts) ->
            val n = counts[1] + counts[2] + counts[3]
            if (n < 3) null else key.recommendation to (counts[1].toDouble() / n)
        }.sortedBy { it.second }
        if (ranked.isEmpty()) return "ADAPTIVE LEARNING: $confirmed confirmed outcomes across this situation; individual strategies need at least 3 outcomes before comparison."
        val weakest = ranked.first()
        val strongest = ranked.last()
        val weakRate = (weakest.second * 100).toInt()
        val strongRate = (strongest.second * 100).toInt()
        return when {
            ranked.size >= 2 && strongest.second - weakest.second >= 0.25 ->
                "ADAPTIVE LEARNING: in $mode / $priority, '${weakest.first.take(90)}' has $weakRate% reported success while '${strongest.first.take(90)}' has $strongRate%. Treat this as a small-sample warning, not proof; favour checking the stronger historical option when the battlefield conditions match."
            else -> "ADAPTIVE LEARNING: $confirmed confirmed outcomes recorded for $mode / $priority. No clear strategy difference yet; keep evaluating current battlefield evidence."
        }
    }

    @Synchronized fun summary(): String {
        val recommendations = stats.values.sumOf { it[0] }
        val outcomes = stats.values.sumOf { it[1] + it[2] + it[3] }
        val successes = stats.values.sumOf { it[1] }
        return "DECISION LEARNING: $recommendations recommendations logged · $outcomes player-confirmed outcomes · $successes reported successful. Unreported outcomes are not treated as failures."
    }

    @Synchronized fun restore(key: Key, value: Stats, isPending: Boolean) {
        stats[key] = mutableListOf(value.recommendations, value.success, value.neutral, value.unsuccessful)
        if (isPending) pending = key
    }

    @Synchronized fun snapshot(): List<Triple<Key, Stats, Boolean>> = stats.map { (k, c) ->
        Triple(k, Stats(c[0], c[1], c[2], c[3]), pending == k)
    }
}

package com.clashai.coach

import android.content.Context
import org.json.JSONObject

data class ClashCard(
    val id: Int,
    val name: String,
    val elixirCost: Int?,
    val rarity: String?,
    val maxLevel: Int?,
    val maxEvolutionLevel: Int?,
    val imageUrl: String?
)

/**
 * Loads the card reference data bundled in app/src/main/assets/cards.json.
 * A missing elixirCost (for example Mirror) remains null rather than being
 * incorrectly treated as a zero-cost card.
 */
object CardDatabase {
    private var loadedCards: List<ClashCard> = emptyList()

    fun load(context: Context) {
        if (loadedCards.isNotEmpty()) return
        val jsonText = context.assets.open("cards.json").bufferedReader().use { it.readText() }
        val root = JSONObject(jsonText)
        val items = root.getJSONArray("items")
        val parsed = ArrayList<ClashCard>(items.length())
        for (i in 0 until items.length()) {
            val item = items.getJSONObject(i)
            val iconUrls = item.optJSONObject("iconUrls")
            parsed += ClashCard(
                id = item.optInt("id"),
                name = item.optString("name"),
                elixirCost = if (item.has("elixirCost") && !item.isNull("elixirCost")) item.optInt("elixirCost") else null,
                rarity = item.optString("rarity").takeIf { it.isNotBlank() },
                maxLevel = item.optInt("maxLevel").takeIf { item.has("maxLevel") },
                maxEvolutionLevel = item.optInt("maxEvolutionLevel").takeIf { item.has("maxEvolutionLevel") },
                imageUrl = iconUrls?.optString("medium")?.takeIf { !it.isNullOrBlank() }
            )
        }
        loadedCards = parsed.sortedBy { it.name.lowercase() }
    }

    fun all(): List<ClashCard> = loadedCards
    fun findByName(name: String): ClashCard? =
        loadedCards.firstOrNull { it.name.equals(name, ignoreCase = true) }
    fun findById(id: Int): ClashCard? = loadedCards.firstOrNull { it.id == id }
}

# Stage 48 — Floating Coach UI Simplification (in progress)

## Included in this patch
- Replaced the long diagnostic text overlay with a compact floating panel.
- Added three selectable tabs: LIVE, DECK, and COACH.
- Added a collapse/expand control.
- Kept the panel movable by dragging its header.
- Limited displayed text so the overlay does not cover most of the game screen.
- The tabs filter the existing status text; they do not claim uninstalled models are available.

## Still required for Stage 48
- Install and validate compatible arena/card recognition models and label files.
- Verify elixir and enemy deck tracking against real match captures.
- Connect all screens to a single shared battle-state model.
- Complete Normal and Chaos mode device tests.
- Run a full Gradle/APK build and test the overlay on the target Android device.

## Validation status
- Source patch and archive integrity prepared.
- Full Gradle/APK build not run in this environment (Gradle executable/wrapper unavailable).

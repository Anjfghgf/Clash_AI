package com.clashai.coach

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import kotlin.math.max
import kotlin.math.min

/** Optional, separate battlefield detector. It must never use the player's hand-card model. */
class ArenaDetectorRuntime(
    private val context: Context,
    private val modelAssetName: String = "arena_detector.tflite",
    private val labelsAssetName: String = "arena_detector_labels.txt",
    private val confidenceThreshold: Float = 0.40f
) : AutoCloseable {
    data class Status(val ready: Boolean, val message: String)
    data class Result(val detections: List<ArenaObjectDetectionPostprocessor.Detection>, val status: Status)

    private var interpreter: Interpreter? = null
    private var postprocessor: ArenaObjectDetectionPostprocessor? = null
    private var inputSize = 640
    private var lastError = "Arena detector model is not bundled."

    val status: Status get() = Status(interpreter != null, if (interpreter != null) "Arena detector ready" else lastError)

    init { loadFromAssets() }

    @Synchronized private fun loadFromAssets() {
        closeInterpreter()
        try {
            val modelPath = modelAssetName
            val labelsPath = labelsAssetName
            val labels = context.assets.open(labelsPath).bufferedReader().useLines { seq ->
                seq.map { it.trim() }.filter { it.isNotEmpty() && !it.startsWith("#") }.toList()
            }
            require(labels.size >= 2) { "Detector labels file must contain at least two classes." }
            val model = context.assets.openFd(modelPath)
            val mapped = FileInputStream(model.fileDescriptor).channel.use { channel ->
                channel.map(FileChannel.MapMode.READ_ONLY, model.startOffset, model.declaredLength)
            }
            model.close()
            val candidate = Interpreter(mapped, Interpreter.Options().setNumThreads(2))
            val input = candidate.getInputTensor(0)
            val shape = input.shape()
            require(shape.size == 4 && shape[0] == 1 && shape[1] == shape[2] && shape[3] == 3) {
                "Expected detector input [1,size,size,3], got ${shape.contentToString()}"
            }
            require(input.dataType() == org.tensorflow.lite.DataType.FLOAT32) { "Only FLOAT32 detector input is supported." }
            inputSize = shape[1]
            val output = candidate.getOutputTensor(0)
            require(output.dataType() == org.tensorflow.lite.DataType.FLOAT32) { "Only FLOAT32 detector output is supported." }
            val outShape = output.shape()
            require(outShape.size == 3 && outShape[0] == 1) { "Expected one YOLO output [1,channels,candidates] or [1,candidates,channels]." }
            val twoDim = intArrayOf(outShape[1], outShape[2])
            require(twoDim[0] == 4 + labels.size || twoDim[1] == 4 + labels.size) {
                "Detector output ${outShape.contentToString()} does not match ${labels.size} labels."
            }
            interpreter = candidate
            postprocessor = ArenaObjectDetectionPostprocessor(labels, inputSize, confidenceThreshold, 0.45f, 40)
            lastError = ""
        } catch (e: Exception) {
            closeInterpreter()
            lastError = "Arena detector unavailable: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    @Synchronized fun detect(bitmap: Bitmap): Result {
        val runner = interpreter ?: return Result(emptyList(), status)
        return try {
            val tensor = runner.getInputTensor(0)
            val size = inputSize
            val scale = min(size.toFloat() / bitmap.width, size.toFloat() / bitmap.height)
            val resizedW = (bitmap.width * scale).toInt().coerceAtLeast(1)
            val resizedH = (bitmap.height * scale).toInt().coerceAtLeast(1)
            val left = (size - resizedW) / 2
            val top = (size - resizedH) / 2
            val resized = Bitmap.createScaledBitmap(bitmap, resizedW, resizedH, true)
            val canvasBitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val canvas = android.graphics.Canvas(canvasBitmap)
            canvas.drawColor(android.graphics.Color.rgb(114, 114, 114))
            canvas.drawBitmap(resized, left.toFloat(), top.toFloat(), null)
            resized.recycle()
            val pixels = IntArray(size * size)
            canvasBitmap.getPixels(pixels, 0, size, 0, 0, size, size)
            canvasBitmap.recycle()
            val input = ByteBuffer.allocateDirect(tensor.numBytes()).order(ByteOrder.nativeOrder()).asFloatBuffer()
            pixels.forEach { px ->
                input.put(((px shr 16) and 255) / 255f)
                input.put(((px shr 8) and 255) / 255f)
                input.put((px and 255) / 255f)
            }
            input.rewind()
            val outputTensor = runner.getOutputTensor(0)
            val shape = outputTensor.shape()
            val outputBuffer = ByteBuffer.allocateDirect(outputTensor.numBytes()).order(ByteOrder.nativeOrder())
            runner.run(input, outputBuffer)
            outputBuffer.rewind()
            val raw = outputBuffer.asFloatBuffer()
            val values = FloatArray(raw.remaining()); raw.get(values)
            val detections = postprocessor?.decode(values, intArrayOf(shape[1], shape[2])).orEmpty().mapNotNull { d ->
                // Undo letterbox: return normalized coordinates in the original bitmap.
                val l = ((d.left * size - left) / resizedW).coerceIn(0f, 1f)
                val t = ((d.top * size - top) / resizedH).coerceIn(0f, 1f)
                val r = ((d.right * size - left) / resizedW).coerceIn(0f, 1f)
                val b = ((d.bottom * size - top) / resizedH).coerceIn(0f, 1f)
                if (r <= l || b <= t) null else d.copy(left=l, top=t, right=r, bottom=b)
            }
            Result(detections, status)
        } catch (e: Exception) {
            lastError = "Arena detector inference failed: ${e.message ?: e.javaClass.simpleName}"
            Result(emptyList(), status)
        }
    }

    private fun closeInterpreter() { try { interpreter?.close() } catch (_: Exception) {}; interpreter = null; postprocessor = null }
    @Synchronized override fun close() = closeInterpreter()
}

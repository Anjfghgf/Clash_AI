#!/usr/bin/env python3
"""Train a session-separated gameplay card classifier and export Android TFLite."""
import argparse, csv, json, hashlib
from pathlib import Path
import numpy as np
from PIL import Image
from sklearn.model_selection import GroupShuffleSplit
from sklearn.metrics import classification_report, confusion_matrix


def load_rows(csv_path, min_per_class, min_sessions):
    rows=list(csv.DictReader(csv_path.open(encoding='utf-8-sig')))
    by={}
    for r in rows:
        try:
            cid=int(r['card_id']); sid=r['session_id'].strip(); name=r['card_name'].strip()
            p=(csv_path.parent/r['image_path']).resolve()
            if sid and name and p.is_file(): by.setdefault(cid,[]).append((p,sid,name))
        except Exception: continue
    keep={k:v for k,v in by.items() if len(v)>=min_per_class and len({x[1] for x in v})>=min_sessions}
    return keep, {str(k):{'samples':len(v),'sessions':len({x[1] for x in v})} for k,v in by.items()}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--dataset',type=Path,required=True); ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--epochs',type=int,default=20); ap.add_argument('--batch-size',type=int,default=24)
    ap.add_argument('--min-samples-per-class',type=int,default=30); ap.add_argument('--min-sessions-per-class',type=int,default=3)
    ap.add_argument('--validation-size',type=float,default=.2); ap.add_argument('--seed',type=int,default=42)
    args=ap.parse_args()
    if not .1 <= args.validation_size <= .4: ap.error('--validation-size must be 0.1..0.4')
    import tensorflow as tf
    tf.keras.utils.set_random_seed(args.seed)
    csv_path=args.dataset/'labels.csv'
    if not csv_path.is_file(): raise SystemExit(f'Missing labels.csv: {csv_path}')
    classes, all_counts=load_rows(csv_path,args.min_samples_per_class,args.min_sessions_per_class)
    if len(classes)<2: raise SystemExit('Need at least 2 classes; each needs the minimum labelled crops across at least 3 independent match sessions.')
    records=[]
    for cid,items in classes.items():
        names={x[2] for x in items}
        if len(names)!=1: raise SystemExit(f'Card ID {cid} has inconsistent names: {sorted(names)}')
        for p,sid,name in items: records.append((str(p),cid,sid,name))
    paths=np.array([r[0] for r in records]); yraw=np.array([r[1] for r in records]); groups=np.array([r[2] for r in records])
    class_ids=sorted(set(yraw.tolist())); id_to_idx={v:i for i,v in enumerate(class_ids)}
    y=np.array([id_to_idx[v] for v in yraw],dtype=np.int32)
    # Group split: never put frames from the same match session in both sets.
    chosen=None
    splitter=GroupShuffleSplit(n_splits=100,test_size=args.validation_size,random_state=args.seed)
    for tr,va in splitter.split(paths,y,groups):
        if set(y[tr])==set(range(len(class_ids))) and set(y[va])==set(range(len(class_ids))):
            chosen=(tr,va); break
    if chosen is None: raise SystemExit('Could not split every class across independent train/validation sessions. Gather more distinct matches for the missing cards.')
    tr,va=chosen
    def load_image(path):
        with Image.open(path) as im: return np.asarray(im.convert('RGB').resize((224,224)),dtype=np.float32)/255.0
    x_train=np.stack([load_image(paths[i]) for i in tr]); x_val=np.stack([load_image(paths[i]) for i in va])
    y_train=tf.keras.utils.to_categorical(y[tr],len(class_ids)); y_val=tf.keras.utils.to_categorical(y[va],len(class_ids))
    inp=tf.keras.Input((224,224,3),name='rgb_0_1')
    aug=tf.keras.Sequential([
        tf.keras.layers.RandomTranslation(.035,.035),
        tf.keras.layers.RandomZoom(.06),
        tf.keras.layers.RandomContrast(.08)
    ],name='gameplay_augmentation')
    x=aug(inp)
    x=tf.keras.layers.Lambda(lambda z: tf.keras.applications.mobilenet_v2.preprocess_input(z*255.0),name='mobilenet_preprocess')(x)
    base=tf.keras.applications.MobileNetV2(include_top=False,weights='imagenet',input_shape=(224,224,3))
    base.trainable=False
    z=base(x,training=False); z=tf.keras.layers.GlobalAveragePooling2D()(z); z=tf.keras.layers.Dropout(.3)(z)
    out=tf.keras.layers.Dense(len(class_ids),activation='softmax',name='card_probabilities')(z)
    model=tf.keras.Model(inp,out)
    model.compile(optimizer=tf.keras.optimizers.Adam(1e-3),loss='categorical_crossentropy',metrics=['accuracy',tf.keras.metrics.TopKCategoricalAccuracy(k=min(3,len(class_ids)),name='top3')])
    args.out.mkdir(parents=True,exist_ok=True)
    callbacks=[tf.keras.callbacks.EarlyStopping(patience=5,restore_best_weights=True,monitor='val_accuracy'),
               tf.keras.callbacks.ModelCheckpoint(args.out/'best.keras',save_best_only=True,monitor='val_accuracy')]
    hist=model.fit(x_train,y_train,validation_data=(x_val,y_val),epochs=args.epochs,batch_size=args.batch_size,callbacks=callbacks,verbose=2)
    model=tf.keras.models.load_model(args.out/'best.keras')
    loss,acc,top3=model.evaluate(x_val,y_val,verbose=0)
    probs=model.predict(x_val,verbose=0); pred=probs.argmax(axis=1); truth=y[va]
    converter=tf.lite.TFLiteConverter.from_keras_model(model); converter.optimizations=[tf.lite.Optimize.DEFAULT]
    tflite=converter.convert(); model_path=args.out/'card_classifier.tflite'; model_path.write_bytes(tflite)
    # Validate exported model shape and probability output before producing a package.
    interpreter=tf.lite.Interpreter(model_path=str(model_path)); interpreter.allocate_tensors()
    input_detail=interpreter.get_input_details()[0]; output_detail=interpreter.get_output_details()[0]
    if input_detail['shape'].tolist()!=[1,224,224,3] or input_detail['dtype']!=np.float32: raise SystemExit('Exported TFLite input does not match Android [1,224,224,3] FLOAT32 contract')
    if output_detail['shape'].tolist()!=[1,len(class_ids)] or output_detail['dtype']!=np.float32: raise SystemExit('Exported TFLite output does not match label count / FLOAT32 contract')
    interpreter.set_tensor(input_detail['index'],x_val[:1]); interpreter.invoke(); sample=interpreter.get_tensor(output_detail['index'])[0]
    if not np.isfinite(sample).all() or abs(float(sample.sum())-1.0)>.05: raise SystemExit('Exported model output failed softmax sanity check')
    labels_path=args.out/'card_labels.txt'
    with labels_path.open('w',encoding='utf-8') as f:
        for cid in class_ids: f.write(f'{cid}|{next(r[3] for r in records if r[1]==cid)}\n')
    report={'model':'MobileNetV2','input':'FLOAT32 [1,224,224,3], RGB [0,1]','output':f'FLOAT32 [1,{len(class_ids)}], softmax',
      'preprocessing':'model applies augmentation only during training, multiplies RGB [0,1] by 255 then MobileNetV2 preprocess_input; Android supplies RGB [0,1]',
      'class_count':len(class_ids),'class_ids':class_ids,'train_samples':len(tr),'validation_samples':len(va),
      'train_sessions':sorted(set(groups[tr])),'validation_sessions':sorted(set(groups[va])),
      'validation_loss':float(loss),'validation_accuracy':float(acc),'validation_top3':float(top3),
      'classification_report':classification_report(truth,pred,labels=list(range(len(class_ids))),target_names=[next(r[3] for r in records if r[1]==cid) for cid in class_ids],output_dict=True,zero_division=0),
      'confusion_matrix':confusion_matrix(truth,pred,labels=list(range(len(class_ids)))).tolist(),
      'history':{k:[float(v) for v in vals] for k,vals in hist.history.items()},'tflite_bytes':len(tflite),
      'files':['card_classifier.tflite','card_labels.txt'],'caution':'Do not auto-confirm cards based on a weak model. Review per-class results and test on entirely unseen matches before live use.'}
    (args.out/'training_report.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({k:report[k] for k in ['class_count','train_samples','validation_samples','validation_accuracy','validation_top3','tflite_bytes']},indent=2))

if __name__=='__main__': main()

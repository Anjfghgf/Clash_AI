# CLASH AI — Stage 37: Automatic Enemy Intelligence

## Implemented

- Added a separate optional `enemy_card_detector.tflite` runtime using the same validated TFLite detector adapter, but with its own labels file and confidence threshold. It is deliberately separate from the player's hand-card classifier.
- The live capture service now runs both the broad arena detector and the exact enemy-card detector on the same full-frame battle image, then feeds their boxes into the temporal battlefield tracker.
- Added `EnemyIntelligencePipeline`: only a stable exact label matching a canonical card name, on the enemy side, with confidence >= 0.90 is accepted as an enemy card play. Generic labels such as `air_troop`, `ground_troop`, `building`, `spell_effect`, and `troop_unknown` never become card identities.
- Accepted plays build a maximum eight-card enemy deck, preserve confirmed play order, and provide four-card-cycle status.
- Enemy elixir is explicitly unknown unless a caller configures a verified starting range, match start time, and mode-specific regeneration rate. No guessed elixir values are fed to the tactical engine.
- Enemy deck, latest confirmed enemy card, rotation summary and elixir-known state are passed into the live tactical context. The floating coach displays enemy intelligence and exact-card-model status.
- Added a separate training guide for the enemy card detector, requiring labelled battlefield sprites and session-separated validation.

## Required training assets

The repository does **not** contain `enemy_card_detector.tflite` or `enemy_card_detector_labels.txt`. The app reports this honestly and continues without exact enemy card identity. The existing broad detector's five labels are not enough to identify exact cards.

To train the exact-card model, collect user-owned or creator-authorised gameplay recordings. Annotate actual arena sprites with the exact card name (for example `Hog Rider`, `Baby Dragon`) rather than using card-menu artwork or generic troop labels. Use the detection dataset preparation and training scripts. Ensure each class is represented in train, validation and test sessions. Copy the resulting TFLite file to `app/src/main/assets/enemy_card_detector.tflite` and its exact generated labels to `app/src/main/assets/enemy_card_detector_labels.txt`.

## Important limits

- Automatic enemy deck construction remains inactive until the exact-card detector is trained, installed and validated on real gameplay footage.
- Enemy side uses the standard portrait arena position estimate; river-band/uncertain objects are not accepted.
- A stable exact-name visual detection is evidence, not proof of a game event; false positives remain possible and should be reviewed during testing.
- The enemy elixir range remains unknown by default. It is unsafe to infer it without verified starting elixir and game-mode regeneration settings.
- No automated card placement or game control is implemented.
- Full Android APK build and real-device match test are not verified in this environment.

## Verification

- Stage 37 pure Kotlin enemy-intelligence smoke checks passed.
- Stage 36 battlefield understanding regression smoke checks passed.
- Python training-script syntax checks passed.
- Static service integration checks passed.
- Full Android Gradle/APK build and device gameplay were not verified. See `STAGE37_TESTS.md`.

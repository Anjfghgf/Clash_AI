import com.clashai.coach.TrackRecognitionVerifier

/** Run with kotlinc alongside TrackRecognitionVerifier.kt; no Android SDK is needed. */
fun main() {
    val consistent = TrackRecognitionVerifier()
    check(!consistent.observe(11, "Hog Rider", 0.91f).stable)
    check(!consistent.observe(11, "Hog Rider", 0.87f).stable)
    val acceptedCandidate = consistent.observe(11, "Hog Rider", 0.89f)
    check(acceptedCandidate.stable)
    check(acceptedCandidate.candidateCard == "Hog Rider")
    check(acceptedCandidate.votes == 3)

    val inconsistent = TrackRecognitionVerifier()
    inconsistent.observe(12, "Hog Rider", 0.96f)
    inconsistent.observe(12, "Balloon", 0.96f)
    check(!inconsistent.observe(12, "Golem", 0.96f).stable)

    val lowConfidence = TrackRecognitionVerifier()
    check(lowConfidence.observe(13, "Wizard", 0.77f).votes == 0)

    val separateTracks = TrackRecognitionVerifier()
    separateTracks.observe(20, "Knight", 0.9f)
    check(separateTracks.observe(21, "Knight", 0.9f).votes == 1)
    separateTracks.retainOnly(setOf(21))
    check(separateTracks.observe(21, "Knight", 0.9f).observations == 2)

    println("PASS: temporal consensus, disagreement rejection, confidence gate, per-track isolation, pruning")
}

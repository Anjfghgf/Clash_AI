package com.clashai.coach

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class ScreenCaptureService : Service() {
    companion object {
        const val ACTION_START = "com.clashai.coach.START"
        const val ACTION_STOP = "com.clashai.coach.STOP"
        const val ACTION_OCR = "com.clashai.coach.OCR"
        const val ACTION_DEPLOYMENT_CANDIDATE = "com.clashai.coach.DEPLOYMENT_CANDIDATE"
        const val EXTRA_TEXT = "recognized_text"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "clash_ai_capture"
        private const val NOTIFICATION_ID = 401
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var lastFrameAt = 0L
    private var previousArenaSample: IntArray? = null
    private var lastCandidateAt = 0L
    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() { stopCapture() }
    }
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopCapture()
            ACTION_START -> {
                startForeground(NOTIFICATION_ID, notification())
                val code = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                @Suppress("DEPRECATION")
                val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                    else intent.getParcelableExtra(EXTRA_RESULT_DATA)
                if (data != null) beginCapture(code, data)
            }
        }
        return START_NOT_STICKY
    }

    private fun beginCapture(resultCode: Int, data: Intent) {
        stopProjectionOnly()
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        projection?.registerCallback(projectionCallback, Handler(mainLooper))
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        val density = metrics.densityDpi
        thread = HandlerThread("ClashAI-FrameReader").also { it.start() }
        val handler = Handler(thread!!.looper)
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ source ->
            val now = System.currentTimeMillis()
            val frame = source.acquireLatestImage() ?: return@setOnImageAvailableListener
            if (now - lastFrameAt < 1800L) { frame.close(); return@setOnImageAvailableListener }
            lastFrameAt = now
            if (detectArenaChange(frame, now)) {
                sendBroadcast(Intent(ACTION_DEPLOYMENT_CANDIDATE).setPackage(packageName))
            }
            runOcr(frame)
        }, handler)
        display = projection?.createVirtualDisplay(
            "ClashAI-Screen", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, handler
        )
    }


    /** Detects a large visual change in the opponent-side arena region.
     * This is only a deployment-event hint, not a card identity classifier.
     */
    private fun detectArenaChange(frame: Image, now: Long): Boolean {
        val plane = frame.planes.firstOrNull() ?: return false
        val buffer = plane.buffer.duplicate()
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val width = frame.width
        val height = frame.height
        val columns = 48
        val rows = 48
        val sample = IntArray(columns * rows)
        var index = 0
        for (gy in 0 until rows) {
            val y = (height * (0.10f + 0.38f * gy / (rows - 1))).toInt().coerceIn(0, height - 1)
            for (gx in 0 until columns) {
                val x = (width * (0.15f + 0.70f * gx / (columns - 1))).toInt().coerceIn(0, width - 1)
                val offset = y * rowStride + x * pixelStride
                if (offset + 2 >= buffer.limit()) return false
                val r = buffer.get(offset).toInt() and 0xff
                val g = buffer.get(offset + 1).toInt() and 0xff
                val b = buffer.get(offset + 2).toInt() and 0xff
                sample[index++] = (r * 30 + g * 59 + b * 11) / 100
            }
        }
        val previous = previousArenaSample
        previousArenaSample = sample
        if (previous == null || previous.size != sample.size) return false
        var changed = 0
        var totalDifference = 0L
        for (i in sample.indices) {
            val difference = kotlin.math.abs(sample[i] - previous[i])
            if (difference >= 28) changed++
            totalDifference += difference
        }
        val changedRatio = changed.toFloat() / sample.size
        val averageDifference = totalDifference.toFloat() / sample.size
        val isLargeChange = changedRatio >= 0.16f && averageDifference >= 12f
        if (isLargeChange && now - lastCandidateAt >= 2800L) {
            lastCandidateAt = now
            return true
        }
        return false
    }

    private fun runOcr(frame: Image) {
        val image = try { InputImage.fromMediaImage(frame, 0) } catch (_: Exception) { frame.close(); return }
        recognizer.process(image)
            .addOnSuccessListener { result ->
                sendBroadcast(Intent(ACTION_OCR).setPackage(packageName).putExtra(EXTRA_TEXT, result.text))
            }
            .addOnCompleteListener { frame.close() }
    }

    private fun notification(): Notification {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "CLASH AI screen analysis", NotificationManager.IMPORTANCE_LOW)
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("CLASH AI is analysing your screen")
            .setContentText("Tap Stop in CLASH AI to end screen capture")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true).build()
    }

    private fun stopProjectionOnly() {
        display?.release(); display = null
        reader?.close(); reader = null
        thread?.quitSafely(); thread = null
        projection?.stop(); projection = null
        previousArenaSample = null
    }

    private fun stopCapture() {
        stopProjectionOnly()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { stopProjectionOnly(); recognizer.close(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}

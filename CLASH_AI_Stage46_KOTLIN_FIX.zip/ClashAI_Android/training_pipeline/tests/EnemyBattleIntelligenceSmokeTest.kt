package com.clashai.coach

fun main() {
    val ai = EnemyBattleIntelligence()
    check(!ai.observe(EnemyBattleIntelligence.Observation("Hog Rider", .99f, EnemyBattleIntelligence.Evidence.MOTION_ONLY, 1000)))
    check(!ai.observe(EnemyBattleIntelligence.Observation("Hog Rider", .99f, EnemyBattleIntelligence.Evidence.ARENA_CARD_MODEL, 1100)))
    check(!ai.observe(EnemyBattleIntelligence.Observation("Hog Rider", .99f, EnemyBattleIntelligence.Evidence.ARENA_CARD_MODEL, 1200)))
    check(ai.observe(EnemyBattleIntelligence.Observation("Hog Rider", .99f, EnemyBattleIntelligence.Evidence.ARENA_CARD_MODEL, 1300)))
    check(ai.confirmedDeck() == listOf("Hog Rider"))
    check(ai.currentHandExclusions() == setOf("Hog Rider"))
    check(!ai.recordConfirmed("Hog Rider", 1400)) // duplicate deployment burst rejected
    check(ai.recordConfirmed("Fireball", 4000))
    check(ai.confirmedDeck().size == 2)
    check(ai.undo())
    check(ai.confirmedDeck() == listOf("Hog Rider"))
    val unknown = ai.estimateElixir(null, null, 30.0, null)
    check(!unknown.known)
    val known = ai.estimateElixir(5.0, 5.0, 10.0, 0.1)
    check(known.known && known.low <= known.high)
    ai.reset()
    check(ai.confirmedDeck().isEmpty())
    println("Stage 27 EnemyBattleIntelligence smoke checks passed")
}

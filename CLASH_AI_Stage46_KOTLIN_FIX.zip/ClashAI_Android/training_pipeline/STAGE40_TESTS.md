# Stage 40 verification

Pure Kotlin smoke test: `Stage40AdaptiveLearningSmokeTest.kt`.

Checks: no insight before minimum evidence; per-recommendation minimum sample; successful vs unsuccessful comparison; game modes isolated; unreported recommendations do not count as outcomes.

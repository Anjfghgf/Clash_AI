package com.clashai.coach
class LiveHudAnalyzer { data class TextRegion(val text:String,val left:Float,val top:Float,val right:Float,val bottom:Float) }
object CardCatalog { fun findNames(text:String):List<String> = listOf("Knight").filter { text.contains(it.lowercase()) } }

package com.clashai.coach

fun main() {
    val actionEngine = PlayerActionPlanEngine()
    val strategyEngine = BattleStrategyEngine()
    val basePlan = TacticalDecisionPlanner.Plan("OBSERVE", "Hold", "Evidence incomplete", "Both lanes", "Low", "Reserve")
    val emptySituation = SituationalAwarenessEngine.Assessment(emptyList(), SituationalAwarenessEngine.Pressure.UNKNOWN)
    val waitStrategy = strategyEngine.evaluate(
        emptyList(), null, null, basePlan,
        MatchPredictionEngine.Prediction("INSUFFICIENT", "Unknown", MatchPredictionEngine.Threat.UNKNOWN),
        emptySituation, emptyList(), GameModeIntelligence.Mode.NORMAL
    )
    val waitAction = actionEngine.create(waitStrategy, basePlan, emptyList(), null, null, null)
    check(waitAction.action == PlayerActionPlanEngine.ActionType.WAIT)
    check(waitAction.card == null && waitAction.requiresConfirmation)
    check(waitAction.render().contains("HUMAN CONFIRMATION REQUIRED"))

    val combo = TacticalCombinationEngine.Combo("Giant", "Musketeer", 9, "Tank plus support", "Low")
    val attackStrategy = strategyEngine.evaluate(
        listOf("Giant", "Musketeer"), 9, combo, basePlan,
        MatchPredictionEngine.Prediction("NO PUSH", "No lane pressure", MatchPredictionEngine.Threat.LOW),
        emptySituation, emptyList(), GameModeIntelligence.Mode.NORMAL
    )
    val attackAction = actionEngine.create(attackStrategy, basePlan, listOf("Giant", "Musketeer"), 9, combo, null)
    check(attackAction.action == PlayerActionPlanEngine.ActionType.COUNTERATTACK)
    check(attackAction.card == "Giant")
    check(attackAction.elixirCost == 9 && attackAction.requiresConfirmation)

    val staleCombo = actionEngine.create(attackStrategy, basePlan, listOf("Giant"), 4, combo, null)
    check(staleCombo.card == null)
    check(staleCombo.steps.any { it.contains("no longer verified") })

    val push = SituationalAwarenessEngine.Assessment(
        listOf(SituationalAwarenessEngine.Group(BattlefieldStateModel.Side.ENEMY, 2, 2)),
        SituationalAwarenessEngine.Pressure.HIGH
    )
    val defendStrategy = strategyEngine.evaluate(
        listOf("Knight"), 5, null, basePlan,
        MatchPredictionEngine.Prediction("PUSH", "left lane pressure", MatchPredictionEngine.Threat.HIGH),
        push, emptyList(), GameModeIntelligence.Mode.NORMAL
    )
    val defendAction = actionEngine.create(defendStrategy, basePlan, listOf("Knight"), 5, null, null)
    check(defendAction.action == PlayerActionPlanEngine.ActionType.DEFEND)
    check(defendAction.requiresConfirmation)
    check(defendAction.render().contains("not a verified counter"))
    println("Stage 44 player action plan smoke checks passed")
}

# CLASH AI — Stage 35: Automatic Chaos Draft Assistant

## What changed
- Added `ChaosDraftAutoPilot`, a temporal OCR state layer for Chaos selection.
- Requires a card name to appear in at least 2 of the last 3 observations before treating it as a stable visible candidate.
- Uses the Stage 34 saved upper/lower calibration. It does not infer which side belongs to the user.
- Automatically updates the visible own/opponent card lists from stable OCR observations, with an eight-card cap for each side.
- Automatically runs `ChaosCompetitiveDraftEngine` against stable visible candidates not already listed as own/opponent picks.
- Sends the recommended next pick, reason, and alternatives to the floating coach during Chaos selection.
- Persists the current draft lists and latest recommendation in app-private preferences.
- Keeps Chaos draft observations separate from the four-card battle hand. Both Normal and Chaos continue to use the shared battle engine after selection.

## Important boundaries
- One-time screen-side calibration is still required because the app cannot safely assume whether the upper or lower half belongs to the user.
- OCR must read a card name correctly in repeated frames. If text is absent, obscured, or misread, the system waits or may produce an incomplete candidate list.
- Visible OCR candidates are not proof that a game accepted a pick. The recommendation is advisory; the app does not tap/select cards or control the game client.
- The OCR-derived candidate pool may be incomplete or include non-offer card labels on unfamiliar layouts. Manual correction remains available in the existing draft panel.
- No trained OCR/card model is bundled. This stage uses the existing ML Kit text recognition and card-name catalogue.
- Full Android Gradle build and real-device Chaos gameplay remain unverified in this environment.

## Verification
- `Stage35ChaosAutoPilotSmokeTest.kt` compiled with `kotlinc` and passed.
- Python training pipeline scripts passed `py_compile`.
- Static checks confirmed the service calls the auto-pilot only in the Chaos selection phase and persists capped lists.
- ZIP integrity check passed.

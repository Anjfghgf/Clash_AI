# CLASH AI Coach — Android prototype

This early Android/Kotlin prototype builds a debug APK with GitHub Actions.

## Included
- User-approved Android screen capture and foreground notification.
- On-device ML Kit OCR for diagnostic text.
- Battle timer with pause/resume and a double-elixir toggle.
- Approximate own/opponent elixir estimates based on elapsed time.
- Opponent card play log with elixir costs and undo.

## Limitations
- Automatic recognition of Clash Royale card artwork is NOT implemented. The live battle screen usually shows card artwork, not card names.
- Opponent card plays must be selected in the app. Opponent elixir is estimated, not read from a hidden game bar.
- Own elixir is currently time-estimated; reading the visible elixir bar is not yet implemented.
- Full 8-card deck/cycle prediction and tactical recommendations are not implemented.
- The app does not tap, control, modify, or inject into Clash Royale.

Run the GitHub Actions workflow to build `app-debug.apk`.

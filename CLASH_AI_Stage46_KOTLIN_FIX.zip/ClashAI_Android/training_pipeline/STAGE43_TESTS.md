# Stage 43 test notes

Run the pure strategy smoke test:

```bash
kotlinc app/src/main/java/com/clashai/coach/BattleStrategyEngine.kt training_pipeline/tests/stage41_stubs/Stage41PredictionStubs.kt training_pipeline/tests/stage43_stubs/Stage43StrategyStubs.kt training_pipeline/tests/Stage43BattleStrategySmokeTest.kt -include-runtime -d stage43-test.jar
java -jar stage43-test.jar
```

Coverage:
- incomplete hand/elixir and unknown battlefield -> WAIT
- affordable recognised combo with no push -> COUNTERATTACK
- high grouped enemy pressure -> DEFEND
- lane focus and candidate ranking are rendered
- output explicitly avoids win guarantees

Stage 40 and Stage 41 regression smoke tests and Python script syntax checks were also rerun. Full Android APK/device testing requires the Android Gradle/SDK environment and is not claimed here.

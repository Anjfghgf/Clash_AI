package com.clashai.coach

/**
 * Stage 43: explainable match-level strategy selection.
 * Produces a ranked recommendation only; it never taps, places, or controls the game.
 */
class BattleStrategyEngine {
    enum class Action { DEFEND, COUNTERATTACK, WAIT }
    enum class Urgency { UNKNOWN, LOW, MEDIUM, HIGH }

    data class Candidate(
        val action: Action,
        val score: Int,
        val available: Boolean,
        val summary: String,
        val evidence: String
    )

    data class Strategy(
        val selected: Action,
        val urgency: Urgency,
        val laneFocus: String,
        val rankedCandidates: List<Candidate>,
        val nextStep: String,
        val explanation: String,
        val confidence: String,
        val limitations: String
    ) {
        fun render(): String = buildString {
            append("BATTLE STRATEGY: $selected · urgency=$urgency\n")
            append("LANE FOCUS: $laneFocus\n")
            append("OPTIONS: ")
            append(rankedCandidates.joinToString(" | ") { "${it.action} ${it.score}/100${if (it.available) "" else " (not justified)"}" })
            append("\nNEXT STEP: $nextStep\nWHY THIS MOVE: $explanation\nCONFIDENCE: $confidence\nLIMITS: $limitations")
        }
    }

    fun evaluate(
        hand: List<String>,
        ownElixir: Int?,
        combo: TacticalCombinationEngine.Combo?,
        plan: TacticalDecisionPlanner.Plan,
        prediction: MatchPredictionEngine.Prediction,
        situation: SituationalAwarenessEngine.Assessment,
        confirmedEnemyDeck: List<String>,
        mode: GameModeIntelligence.Mode
    ): Strategy {
        val recognisedHand = hand.distinct()
        val comboReady = combo != null && combo.lead in recognisedHand && combo.support in recognisedHand &&
            ownElixir != null && combo.totalCost <= ownElixir
        val hasEnemyPush = situation.groups.any {
            it.side == BattlefieldStateModel.Side.ENEMY && it.troopCount > 0 && it.movingTowardBottom > 0
        }
        val urgency = when {
            prediction.threat == MatchPredictionEngine.Threat.HIGH || situation.pressure == SituationalAwarenessEngine.Pressure.HIGH -> Urgency.HIGH
            prediction.threat == MatchPredictionEngine.Threat.MEDIUM || situation.pressure == SituationalAwarenessEngine.Pressure.MEDIUM -> Urgency.MEDIUM
            prediction.threat == MatchPredictionEngine.Threat.LOW || hasEnemyPush -> Urgency.LOW
            else -> Urgency.UNKNOWN
        }
        val laneFocus = when {
            prediction.lanePressure.contains("left", ignoreCase = true) -> "LEFT lane is the current watch area; confirm visually"
            prediction.lanePressure.contains("right", ignoreCase = true) -> "RIGHT lane is the current watch area; confirm visually"
            else -> "Both lanes; no reliable single-lane focus"
        }

        val defendScore = when (urgency) {
            Urgency.HIGH -> 94
            Urgency.MEDIUM -> 78
            Urgency.LOW -> 58
            Urgency.UNKNOWN -> 35
        }
        val defendAvailable = hasEnemyPush || prediction.threat == MatchPredictionEngine.Threat.MEDIUM ||
            prediction.threat == MatchPredictionEngine.Threat.HIGH || plan.priority.startsWith("DEFEND")
        val counterScore = when {
            !comboReady -> 0
            hasEnemyPush -> 8
            urgency == Urgency.HIGH -> 12
            urgency == Urgency.MEDIUM -> 34
            urgency == Urgency.LOW -> 66
            else -> 76
        }
        val waitScore = when {
            ownElixir == null || recognisedHand.size != 4 -> 88
            urgency == Urgency.HIGH -> 18
            urgency == Urgency.MEDIUM -> 38
            urgency == Urgency.LOW -> 54
            else -> 72
        }
        val candidates = listOf(
            Candidate(Action.DEFEND, defendScore, defendAvailable,
                plan.recommendation,
                "Urgency=$urgency; grouped advancing enemy evidence=${if (hasEnemyPush) "present" else "not confirmed"}."),
            Candidate(Action.COUNTERATTACK, counterScore, comboReady,
                if (comboReady) "${combo!!.lead} + ${combo.support} (${combo.totalCost} elixir)" else "No affordable recognised two-card combination.",
                if (comboReady) "Both cards are in the current recognised hand and fit reported elixir." else "Hand, elixir, or combination evidence is incomplete."),
            Candidate(Action.WAIT, waitScore, true,
                "Preserve elixir and gather another observation.",
                "Waiting is the fallback when the board or affordability is uncertain.")
        ).sortedByDescending { it.score }

        val selected = when {
            urgency == Urgency.HIGH || urgency == Urgency.MEDIUM && defendAvailable -> Action.DEFEND
            comboReady && !hasEnemyPush && urgency != Urgency.HIGH -> Action.COUNTERATTACK
            ownElixir == null || recognisedHand.size != 4 || urgency == Urgency.UNKNOWN -> Action.WAIT
            defendAvailable && urgency == Urgency.LOW -> Action.DEFEND
            else -> Action.WAIT
        }
        val nextStep = when (selected) {
            Action.DEFEND -> "Inspect the indicated lane and choose a suitable affordable response from your hand. Do not place based on an unverified object."
            Action.COUNTERATTACK -> "Consider ${combo!!.lead} with ${combo.support}; check lane safety and the opponent's available counters before committing."
            Action.WAIT -> "Keep your current elixir, confirm the hand and battlefield, then reassess after another observation."
        }
        val explanation = when (selected) {
            Action.DEFEND -> "Defence ranks first because the observed threat is $urgency. The tactical planner says: ${plan.reason}"
            Action.COUNTERATTACK -> "No high-priority advancing threat is established and the recognised combination is affordable. Known opponent deck size=${confirmedEnemyDeck.distinct().size}; unknown cards may still answer it."
            Action.WAIT -> "A decisive play is not supported by the current evidence. Waiting avoids committing to uncertain card identity, lane, or elixir."
        }
        val confidence = when {
            selected == Action.DEFEND && urgency == Urgency.HIGH -> "Low-to-moderate; based on broad tracks and grouped movement, not exact card identities."
            selected == Action.DEFEND -> "Low; inspect the battlefield before acting."
            selected == Action.COUNTERATTACK && confirmedEnemyDeck.size >= 8 -> "Moderate for hand/elixir feasibility; low for outcome because enemy cycle and live responses are incomplete."
            selected == Action.COUNTERATTACK -> "Low; opponent deck information is incomplete."
            else -> "Unknown/low; more reliable observations are needed."
        }
        val limits = "Rule-based comparison for ${mode.name}; it cannot guarantee a win, predict exact placements, or operate the game's controls."
        return Strategy(selected, urgency, laneFocus, candidates, nextStep, explanation, confidence, limits)
    }
}

package com.clashai.coach

/**
 * Converts repeated OCR observations into conservative Chaos draft state.
 * It never assumes an uncalibrated screen side and never exceeds eight cards.
 */
class ChaosDraftAutoPilot {
    data class Result(
        val calibrated: Boolean,
        val stableVisibleCards: List<String>,
        val ownVisibleCards: List<String>,
        val opponentVisibleCards: List<String>,
        val recommendation: ChaosCompetitiveDraftEngine.PickAdvice?,
        val message: String
    )

    private val observations = ArrayDeque<Set<String>>()

    fun observe(
        allCandidates: List<String>,
        upperCandidates: List<String>,
        lowerCandidates: List<String>,
        mapping: ChaosDraftScreenMapping,
        currentOwnPicks: List<String>,
        currentOpponentPicks: List<String>,
        strategy: CardStrategyEngine
    ): Result {
        val cleanAll = clean(allCandidates)
        observations.add(cleanAll.toSet())
        while (observations.size > 3) observations.removeFirst()
        val stable = cleanAll.filter { card -> observations.count { card in it } >= 2 }

        if (!mapping.isCalibrated) return Result(
            false, stable, emptyList(), emptyList(), null,
            "Chaos draft detected. Waiting for one-time screen-side calibration; no player side will be guessed."
        )

        val mapped = mapping.map(clean(upperCandidates), clean(lowerCandidates))
        val own = (currentOwnPicks + mapped.ourCards.filter { it in stable })
            .distinctBy { it.lowercase() }.take(8)
        val opponent = (currentOpponentPicks + mapped.opponentCards.filter { it in stable })
            .distinctBy { it.lowercase() }.take(8)
        val excluded = (own + opponent).map { it.lowercase() }.toSet()
        val pool = stable.filter { it.lowercase() !in excluded }
        val advice = if (own.size < 8 && pool.isNotEmpty()) {
            ChaosCompetitiveDraftEngine(strategy).recommend(pool, own, opponent)
        } else null
        val message = when {
            own.size >= 8 -> "Our eight-card Chaos deck is complete. No ninth card will be added."
            advice != null -> "AUTO DRAFT ADVICE: ${advice.card}. ${advice.reason}"
            stable.isEmpty() -> "Waiting for repeated OCR card names before recommending a pick."
            else -> "Stable cards detected, but no unselected candidate is reliable enough to recommend yet."
        }
        return Result(true, stable, own, opponent, advice, message)
    }

    fun reset() { observations.clear() }

    private fun clean(cards: List<String>): List<String> = cards
        .map { it.trim() }
        .filter { it.isNotBlank() && CardCatalog.names.any { known -> known.equals(it, ignoreCase = true) } }
        .distinctBy { it.lowercase() }
}

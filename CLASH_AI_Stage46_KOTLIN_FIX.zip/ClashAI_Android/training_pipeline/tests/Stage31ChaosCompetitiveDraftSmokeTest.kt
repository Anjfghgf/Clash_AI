package com.clashai.coach

/** Run with the app's Kotlin sources; validates 8-card limit and public-pick-aware scoring. */
fun main() {
    val engine = ChaosCompetitiveDraftEngine(CardStrategyEngine())
    check(engine.recommend(listOf("Musketeer", "Golem", "Arrows"), List(8) { "Knight$it" }, emptyList()) == null)
    val own = listOf("Giant", "Knight", "Fireball")
    val offers = listOf("Archers", "Minion Horde", "Valkyrie", "Zap")
    val baseline = engine.recommend(offers, own, emptyList()) ?: error("baseline pick missing")
    val enemyAware = engine.recommend(offers, own, listOf("Balloon", "Minion Horde")) ?: error("enemy-aware pick missing")
    check(enemyAware.denialScore >= baseline.denialScore)
    check(enemyAware.card in offers)
    check(enemyAware.alternatives.size <= 3)
    check("opponent's visible picks" in enemyAware.reason || enemyAware.denialScore == 0)
    println("Stage31 chaos competitive draft smoke checks passed")
}

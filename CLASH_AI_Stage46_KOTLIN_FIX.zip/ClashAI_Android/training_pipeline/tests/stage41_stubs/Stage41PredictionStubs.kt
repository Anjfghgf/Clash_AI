package com.clashai.coach

object CardCatalog { val costs = mapOf("Knight" to 3, "Archers" to 3, "Giant" to 5, "Musketeer" to 4) }
class BattlefieldUnderstandingEngine {
    enum class ObjectKind { TROOP, BUILDING, SPELL_EFFECT, UNKNOWN }
    enum class TroopDomain { AIR, GROUND, UNKNOWN }
    data class TrackedObject(
        val trackId: Int, val label: String, val kind: ObjectKind, val troopDomain: TroopDomain,
        val side: BattlefieldStateModel.Side, val lane: BattlefieldStateModel.Lane,
        val movement: BattlefieldStateModel.Movement, val confidence: Float,
        val identityConfirmed: Boolean, val centerX: Float, val centerY: Float, val towerProximity: String
    )
}
class BattlefieldStateModel {
    enum class Side { FRIENDLY, ENEMY, UNKNOWN }
    enum class Lane { LEFT, RIGHT, CENTER, UNKNOWN }
    enum class Movement { TOWARD_TOP, TOWARD_BOTTOM, MOSTLY_STATIONARY, UNKNOWN }
}
class TacticalCombinationEngine {
    data class Combo(val lead: String, val support: String, val totalCost: Int, val reason: String, val confidence: String)
}
class TacticalDecisionPlanner {
    data class Plan(val priority: String, val recommendation: String, val reason: String, val laneHint: String, val confidence: String, val reserveWarning: String)
}

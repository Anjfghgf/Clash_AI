# Stage 40 — Adaptive Strategy Intelligence

Version: 0.40.0 (versionCode 40)

## Added
- Mode- and tactical-priority-specific adaptive insights from player-confirmed outcomes.
- Compares repeated recommendation texts only after each has at least three confirmed outcomes.
- Reports a conservative historical comparison when the observed success-rate gap is at least 25 percentage points.
- Adds the insight to the live coach summary beside the tactical plan.
- Keeps unreported recommendations out of outcome counts; no outcome is inferred from OCR refreshes or the AI's own recommendation.

## Limits
- This is evidence-based statistical guidance, not neural-network training or autonomous policy retraining.
- The comparison is observational and can be affected by different battlefield conditions, opponent decks, player execution, and small samples.
- A historical success rate does not guarantee a future result. The current battlefield evidence and player judgement remain primary.
- No automatic card deployment or game control is introduced.
- Full APK build/device test requires Android SDK and Gradle; these are not available in the current build environment.

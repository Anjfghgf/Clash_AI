# Stage 48 – Floating Coach Tabs

## UI change
The floating coach is split into three independent views:

- **ELIXIR** – own/enemy elixir readings and elixir-related OCR details.
- **ENEMY DECK** – confirmed enemy card identities and enemy card-model status.
- **ADVICE** – tactical recommendations, action plans, combinations, and strategy summaries.

The panel remains movable and can be collapsed with the header button. Each tab shows a short waiting message when no matching information is available; unconfirmed data is not presented as confirmed.

## Verification
Source-level change only. An Android build was not run in this environment because the Gradle executable/wrapper is unavailable. Run `gradle --no-daemon assembleDebug` in CI or Android Studio to verify compilation.

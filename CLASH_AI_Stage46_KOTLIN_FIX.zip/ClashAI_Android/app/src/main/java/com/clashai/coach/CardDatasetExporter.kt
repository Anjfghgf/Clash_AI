package com.clashai.coach

import android.content.Context
import android.net.Uri
import org.json.JSONObject
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Exports only manually confirmed card-only crops with matching metadata. */
object CardDatasetExporter {
    data class ExportResult(val exported: Int, val skipped: Int, val cards: Int)

    private data class Sample(val image: java.io.File, val metadata: JSONObject, val cardId: Int, val cardName: String)

    fun export(context: Context, destination: Uri): ExportResult {
        val root = java.io.File(context.filesDir, "vision_samples")
        val samples = mutableListOf<Sample>()
        var skipped = 0
        if (root.exists()) {
            root.walkTopDown().filter { it.isFile && it.name.startsWith("card_") && it.extension.equals("jpg", true) }.forEach { image ->
                try {
                    val metadataFile = java.io.File(image.parentFile, image.nameWithoutExtension + ".json")
                    val metadata = JSONObject(metadataFile.readText())
                    val id = metadata.optInt("cardId", -1)
                    val name = metadata.optString("cardLabel", "")
                    val valid = metadata.optBoolean("readyForTraining", false) &&
                        metadata.optString("sampleType") == "manually_annotated_card_crop" &&
                        id >= 0 && name.isNotBlank() && image.length() > 0L
                    if (valid) samples.add(Sample(image, metadata, id, name)) else skipped++
                } catch (_: Exception) { skipped++ }
            }
        }

        val cards = samples.map { it.cardId }.distinct().size
        context.contentResolver.openOutputStream(destination)?.use { output ->
            ZipOutputStream(output).use { zip ->
                val csv = buildString {
                    append("image_path,card_id,card_name,elixir_cost,rarity,elapsed_seconds\n")
                    samples.forEach { sample ->
                        val relative = "images/${sample.cardId}/${sample.image.name}"
                        val name = sample.cardName.replace("\"", "\"\"")
                        val rarity = sample.metadata.optString("rarity", "unknown").replace("\"", "\"\"")
                        append("\"$relative\",${sample.cardId},\"$name\",${sample.metadata.optInt("elixirCost", -1)},\"$rarity\",${sample.metadata.optLong("elapsedSeconds", 0L)}\n")
                    }
                }
                zip.putNextEntry(ZipEntry("labels.csv"))
                zip.write(csv.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
                samples.forEach { sample ->
                    val relative = "images/${sample.cardId}/${sample.image.name}"
                    zip.putNextEntry(ZipEntry(relative))
                    sample.image.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                }

                val summary = JSONObject()
                    .put("formatVersion", 1)
                    .put("datasetType", "manually_labelled_clash_royale_card_crops")
                    .put("exportedSampleCount", samples.size)
                    .put("skippedInvalidSampleCount", skipped)
                    .put("uniqueCardCount", cards)
                    .put("imageFormat", "JPEG")
                    .put("important", "These are manually selected card crops, not automatically detected predictions. Split by match/session when creating train and validation sets.")
                zip.putNextEntry(ZipEntry("dataset_summary.json"))
                zip.write(summary.toString(2).toByteArray(Charsets.UTF_8))
                zip.closeEntry()

                zip.putNextEntry(ZipEntry("README.txt"))
                zip.write(("CLASH AI card crop dataset\n\n" +
                    "images/ contains confirmed card-only JPEG crops grouped by Clash Royale card ID.\n" +
                    "labels.csv maps each image to its card ID and metadata.\n" +
                    "dataset_summary.json describes this export.\n\n" +
                    "Review images before training. Remove duplicates and poor crops. Keep separate matches/sessions in the same train or validation split to reduce leakage. Do not treat the card reference image URL as a gameplay sample.\n").toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
        } ?: throw IllegalStateException("Android could not open the selected destination")
        return ExportResult(samples.size, skipped, cards)
    }
}

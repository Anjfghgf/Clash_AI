package com.clashai.coach

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Small app-private persistent store for decision history; never infers a match result. */
class DecisionLearningStore(context: Context) {
    private val prefs = context.getSharedPreferences("clash_ai_decision_learning", Context.MODE_PRIVATE)
    private val engine = DecisionLearningEngine()

    init { load() }

    @Synchronized fun recordRecommendation(mode: String, priority: String, recommendation: String) {
        engine.recordRecommendation(mode, priority, recommendation); save()
    }
    @Synchronized fun recordOutcome(outcome: DecisionLearningEngine.Outcome): Boolean {
        val accepted = engine.recordConfirmedOutcome(outcome)
        if (accepted) save()
        return accepted
    }
    @Synchronized fun summary(): String = engine.summary()
    @Synchronized fun adaptiveInsight(mode: String, priority: String): String = engine.adaptiveInsight(mode, priority)

    private fun save() {
        val array = JSONArray()
        engine.snapshot().forEach { (key, stats, pending) ->
            array.put(JSONObject().put("mode", key.mode).put("priority", key.priority)
                .put("recommendation", key.recommendation).put("recommendations", stats.recommendations)
                .put("success", stats.success).put("neutral", stats.neutral)
                .put("unsuccessful", stats.unsuccessful).put("pending", pending))
        }
        prefs.edit().putString("records", array.toString()).apply()
    }
    private fun load() {
        val array = runCatching { JSONArray(prefs.getString("records", "[]")) }.getOrNull() ?: return
        // Rehydrate through the same evidence-gated API. Outcomes are replayed only if stored.
        for (i in 0 until array.length()) {
            val o = array.optJSONObject(i) ?: continue
            val mode = o.optString("mode", "UNKNOWN")
            val priority = o.optString("priority")
            val recommendation = o.optString("recommendation")
            engine.restore(
                DecisionLearningEngine.Key(mode, priority, recommendation),
                DecisionLearningEngine.Stats(
                    o.optInt("recommendations").coerceIn(0, 10000),
                    o.optInt("success").coerceIn(0, 10000),
                    o.optInt("neutral").coerceIn(0, 10000),
                    o.optInt("unsuccessful").coerceIn(0, 10000)
                ),
                o.optBoolean("pending")
            )
        }
    }
}

# Stage 42 smoke test

Run:

```bash
kotlinc app/src/main/java/com/clashai/coach/BattlefieldStateModel.kt \
  app/src/main/java/com/clashai/coach/ArenaObjectDetectionPostprocessor.kt \
  app/src/main/java/com/clashai/coach/BattlefieldUnderstandingEngine.kt \
  app/src/main/java/com/clashai/coach/SituationalAwarenessEngine.kt \
  training_pipeline/tests/Stage42SituationalAwarenessSmokeTest.kt \
  -include-runtime -d stage42-test.jar
java -jar stage42-test.jar
```

Checks: same-lane troop clustering, developing-push detection, coarse pressure levels, nearby-building interaction notes, spell/effect caution, and rejection of unknown-side/unknown-lane observations.

Stage 41 prediction and Stage 40 adaptive-learning smoke tests should also be rerun as regression checks.

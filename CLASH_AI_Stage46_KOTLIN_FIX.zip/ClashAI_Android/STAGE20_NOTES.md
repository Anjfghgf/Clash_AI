# Stage 20 — Battlefield State Model

## Added
- `BattlefieldStateModel.kt`: a conservative temporal state layer for normalized 2D observations.
- Assigns likely friendly/enemy side from vertical position, while keeping a river band as UNKNOWN.
- Assigns left/right/center lane, coarse movement direction, and track persistence.
- Accepts detector labels only when supplied with confidence >= 0.70; identity becomes stable only after repeated votes.
- Produces a snapshot with counts, readable summary, and uncertainty cautions.
- MainActivity now displays the state-model summary alongside the Stage 19 advice.
- Added a standalone Kotlin smoke test for side/lane uncertainty, repeated label verification, and reset.

## Important integration boundary
The current live capture path does not yet pass reliable normalized bounding-box coordinates and detector labels into this model. Therefore the in-app state summary remains in its waiting state until that observation bridge is connected. The model is implemented and tested as a component; it is NOT yet live troop tracking, target prediction, or autonomous gameplay.

## Coordinate assumptions
- Input coordinates are normalized to 0..1.
- The river is approximated around y=0.5 with a configurable uncertainty band.
- This assumption must be calibrated against actual screen orientation, arena crop, UI scaling, and game modes before relying on side assignments.
- Movement is a coarse velocity sign, not a path prediction.

## Test
`kotlinc app/src/main/java/com/clashai/coach/BattlefieldStateModel.kt training_pipeline/tests/BattlefieldStateModelSmokeTest.kt -include-runtime -d stage20-test.jar && java -jar stage20-test.jar`

Result: passed in the build environment.

package com.clashai.coach

fun main() {
    val model = BattlefieldStateModel()
    val first = model.update(listOf(
        BattlefieldStateModel.Observation(1, 0.22f, 0.25f, 0f, 0.04f, "Knight", 0.91f, 1000L),
        BattlefieldStateModel.Observation(2, 0.78f, 0.76f, 0f, -0.03f, null, 0f, 1000L),
        BattlefieldStateModel.Observation(3, 0.50f, 0.51f, 0f, 0f, null, 0f, 1000L)
    ))
    check(first.enemyCount == 1 && first.friendlyCount == 1 && first.unknownCount == 1)
    repeat(2) { i -> model.update(listOf(
        BattlefieldStateModel.Observation(1, 0.22f, 0.25f, 0f, 0.04f, "Knight", 0.91f, 1100L + i)
    )) }
    val state = model.snapshot().objects.first { it.trackId == 1 }
    check(state.identityConfirmed && state.detectorLabel == "Knight")
    model.reset()
    check(model.snapshot().objects.isEmpty())
    println("Stage 20 BattlefieldStateModel smoke checks passed")
}

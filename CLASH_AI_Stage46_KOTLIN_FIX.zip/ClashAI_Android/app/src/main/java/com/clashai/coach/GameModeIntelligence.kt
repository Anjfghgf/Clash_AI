package com.clashai.coach

/** Mode-aware rules. Unknown/special modes never inherit normal-mode assumptions silently. */
class GameModeIntelligence {
    enum class Mode { NORMAL, DOUBLE_ELIXIR, TRIPLE_ELIXIR, DRAFT, CHAOS, TWO_V_TWO, SUDDEN_DEATH, UNKNOWN }
    data class ModeProfile(
        val mode: Mode,
        val title: String,
        val elixirRateMultiplier: Double?,
        val deckIsFixedEight: Boolean,
        val draftSelection: Boolean,
        val teamPlay: Boolean,
        val notes: String
    )
    data class DraftAdvice(val card: String, val score: Int, val reason: String, val alternatives: List<String>)

    fun profile(mode: Mode): ModeProfile = when (mode) {
        Mode.NORMAL -> ModeProfile(mode, "Normal", 1.0, true, false, false, "Standard battle assumptions; verify game timer and elixir readings.")
        Mode.DOUBLE_ELIXIR -> ModeProfile(mode, "Double Elixir", 2.0, true, false, false, "Faster elixir changes punish windows and allows larger pushes; confirm the mode before relying on rate estimates.")
        Mode.TRIPLE_ELIXIR -> ModeProfile(mode, "Triple Elixir", 3.0, true, false, false, "High-tempo mode: evaluate repeated pushes and spell value; confirm mode-specific rules.")
        Mode.DRAFT -> ModeProfile(mode, "Draft", null, true, true, false, "Choose exactly eight cards from the offered pool; mode-specific elixir rules remain unverified.")
        Mode.CHAOS -> ModeProfile(mode, "Chaos", null, true, true, false, "Build an eight-card deck from the cards offered in the supplied selection file; do not guess unavailable choices or special elixir rules.")
        Mode.TWO_V_TWO -> ModeProfile(mode, "2v2", null, true, false, true, "Each player uses an eight-card deck; consider allied support but do not assume teammate cards unless observed.")
        Mode.SUDDEN_DEATH -> ModeProfile(mode, "Sudden Death", null, true, false, false, "Use the eight-card deck structure; prioritise objective pressure and verify event-specific elixir rules.")
        Mode.UNKNOWN -> ModeProfile(mode, "Unknown / Special", null, true, false, false, "Keep the confirmed eight-card deck structure; leave unverified elixir timing and other special rules unknown.")
    }

    /** Pick one offered card for a draft/Chaos choice using deck coverage, not card popularity. */
    fun recommendDraftPick(options: List<String>, currentDeck: List<String>, cardRoles: (String) -> Set<CardStrategyEngine.Role>): DraftAdvice? {
        val selectedNames = currentDeck.map { it.trim().lowercase() }.toSet()
        val offered = options.map { it.trim() }.filter { it.isNotEmpty() && it.lowercase() !in selectedNames }.distinct()
        if (offered.isEmpty()) return null
        val deck = currentDeck.distinct()
        if (deck.size >= 8) return null
        val currentRoles = deck.flatMap { cardRoles(it) }.toSet()
        val scores = offered.map { card ->
            val roles = cardRoles(card)
            var score = 0
            if (CardStrategyEngine.Role.WIN_CONDITION in roles && CardStrategyEngine.Role.WIN_CONDITION !in currentRoles) score += 5
            if (CardStrategyEngine.Role.ANTI_AIR in roles && CardStrategyEngine.Role.ANTI_AIR !in currentRoles) score += 4
            if (CardStrategyEngine.Role.SPLASH in roles && CardStrategyEngine.Role.SPLASH !in currentRoles) score += 3
            if (CardStrategyEngine.Role.SPELL in roles && CardStrategyEngine.Role.SPELL !in currentRoles) score += 2
            if (CardStrategyEngine.Role.TANK in roles && CardStrategyEngine.Role.TANK !in currentRoles) score += 2
            if (roles.any { it == CardStrategyEngine.Role.UNKNOWN } || roles.isEmpty()) score -= 2
            if (card in deck) score -= 8
            card to score
        }.sortedByDescending { it.second }
        val best = scores.first()
        val roleNames = cardRoles(best.first).filter { it != CardStrategyEngine.Role.UNKNOWN }.joinToString(", ") { it.name.lowercase().replace('_', ' ') }
        val reason = if (best.second < 0) "No offered card clearly improves known deck coverage; this is only the least-bad listed option." else "Adds useful role coverage${if (roleNames.isNotBlank()) " ($roleNames)" else ""} compared with the cards already selected."
        return DraftAdvice(best.first, best.second, reason, scores.drop(1).take(2).map { it.first })
    }
}

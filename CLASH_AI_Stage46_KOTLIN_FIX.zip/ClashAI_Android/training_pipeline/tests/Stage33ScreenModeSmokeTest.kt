package com.clashai.coach

fun main() {
    val detector = GameScreenModeDetector()
    val draft = listOf(LiveHudAnalyzer.TextRegion("Choose your cards", 100f, 200f, 500f, 250f))
    check(detector.observe(draft, 600, 1000, listOf("Knight")).phase == GameScreenModeDetector.Phase.UNKNOWN)
    check(detector.observe(draft, 600, 1000, listOf("Knight")).phase == GameScreenModeDetector.Phase.CHAOS_SELECTION)

    detector.reset()
    val battle = listOf(LiveHudAnalyzer.TextRegion("5", 270f, 850f, 300f, 900f))
    check(detector.observe(battle, 600, 1000, listOf("Knight")).phase == GameScreenModeDetector.Phase.UNKNOWN)
    check(detector.observe(battle, 600, 1000, listOf("Knight")).phase == GameScreenModeDetector.Phase.BATTLE)

    detector.reset()
    val unclear = listOf(LiveHudAnalyzer.TextRegion("Clash Royale", 20f, 20f, 200f, 60f))
    repeat(3) { check(detector.observe(unclear, 600, 1000, listOf("Knight")).phase == GameScreenModeDetector.Phase.UNKNOWN) }
    println("Stage 33 screen-mode smoke checks passed")
}

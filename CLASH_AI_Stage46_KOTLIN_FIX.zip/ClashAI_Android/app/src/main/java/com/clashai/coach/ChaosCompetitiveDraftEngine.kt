package com.clashai.coach

/** Competitive Chaos draft: improves our deck while considering publicly visible opponent picks. */
class ChaosCompetitiveDraftEngine(private val strategy: CardStrategyEngine) {
    data class PickAdvice(
        val card: String,
        val totalScore: Int,
        val ownDeckScore: Int,
        val denialScore: Int,
        val reason: String,
        val alternatives: List<String>
    )

    fun recommend(
        offeredCards: List<String>,
        ownPicks: List<String>,
        opponentVisiblePicks: List<String>
    ): PickAdvice? {
        if (ownPicks.size >= 8) return null
        val own = ownPicks.distinct()
        val enemy = opponentVisiblePicks.distinct()
        val alreadyChosen = own.map { it.lowercase() }.toSet()
        val options = offeredCards.distinct().filter { it.isNotBlank() && it.lowercase() !in alreadyChosen }
        if (options.isEmpty()) return null

        val ownRoles = own.flatMap { strategy.profile(it).roles }.toSet()
        val scored = options.map { card ->
            val profile = strategy.profile(card)
            var ownScore = 0
            profile.roles.filter { it != CardStrategyEngine.Role.UNKNOWN }.forEach { role ->
                if (role !in ownRoles) ownScore += when (role) {
                    CardStrategyEngine.Role.WIN_CONDITION -> 7
                    CardStrategyEngine.Role.ANTI_AIR -> 6
                    CardStrategyEngine.Role.SPLASH -> 5
                    CardStrategyEngine.Role.SPELL -> 4
                    CardStrategyEngine.Role.TANK -> 3
                    CardStrategyEngine.Role.SUPPORT -> 2
                    CardStrategyEngine.Role.DEFENSIVE_BUILDING -> 3
                    CardStrategyEngine.Role.SWARM -> 2
                    CardStrategyEngine.Role.CYCLE -> 1
                    else -> 0
                }
            }
            if (own.isEmpty() && CardStrategyEngine.Role.WIN_CONDITION in profile.roles) ownScore += 3
            if (own.isNotEmpty() && own.none { strategy.profile(it).roles.contains(CardStrategyEngine.Role.ANTI_AIR) } && profile.roles.contains(CardStrategyEngine.Role.ANTI_AIR)) ownScore += 3
            if (own.isNotEmpty() && own.none { strategy.profile(it).roles.contains(CardStrategyEngine.Role.SPELL) } && profile.roles.contains(CardStrategyEngine.Role.SPELL)) ownScore += 2
            if (profile.cost != null) {
                val currentCosts = own.mapNotNull { strategy.profile(it).cost ?: CardCatalog.costs[it] }
                val avg = if (currentCosts.isEmpty()) 4.0 else currentCosts.average()
                if (profile.cost > 6 && avg > 4.4) ownScore -= 3
                if (profile.cost <= 3 && avg > 4.0) ownScore += 2
            }
            if (profile.roles.contains(CardStrategyEngine.Role.UNKNOWN)) ownScore -= 3

            // Publicly visible opponent picks create denial value only when this card's role plausibly answers them.
            var denial = 0
            enemy.forEach { enemyCard ->
                val enemyProfile = strategy.profile(enemyCard)
                if (CardStrategyEngine.Role.WIN_CONDITION in enemyProfile.roles && CardStrategyEngine.Role.ANTI_AIR in profile.roles) denial += 3
                if (CardStrategyEngine.Role.SWARM in enemyProfile.roles && CardStrategyEngine.Role.SPLASH in profile.roles) denial += 3
                if (CardStrategyEngine.Role.TANK in enemyProfile.roles &&
                    (CardStrategyEngine.Role.TANK in profile.roles || CardStrategyEngine.Role.SUPPORT in profile.roles || CardStrategyEngine.Role.SPELL in profile.roles)) denial += 1
            }
            // Do not overvalue denial if our own deck still lacks a win condition or essential coverage.
            val total = ownScore + denial.coerceAtMost(6)
            Triple(card, total, ownScore to denial)
        }.sortedWith(compareByDescending<Triple<String, Int, Pair<Int, Int>>> { it.second }.thenBy { strategy.profile(it.first).cost ?: 99 })

        val best = scored.first()
        val ownReason = if (best.third.first > 0) "improves our deck's role coverage" else "is the strongest remaining fit among known offered cards"
        val denyReason = if (best.third.second > 0) " and also gives us a useful answer to the opponent's visible picks" else ""
        val unknownNote = if (strategy.profile(best.first).roles.contains(CardStrategyEngine.Role.UNKNOWN)) " Card role data is incomplete, so confidence is limited." else ""
        return PickAdvice(best.first, best.second, best.third.first, best.third.second,
            "Choose ${best.first}: it $ownReason$denyReason.$unknownNote Opponent picks are treated as public draft information, not proof of their final deck.",
            scored.drop(1).take(3).map { it.first })
    }
}

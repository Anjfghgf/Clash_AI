package com.clashai.coach

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView

/** Small, movable, non-interactive overlay for live match advice. */
class FloatingCoachOverlay(private val context: Context) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var view: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    fun show(initialText: String = "CLASH AI\nWaiting for battlefield observations…") {
        val existing = view
        if (existing != null) { update(initialText); return }
        val text = TextView(context).apply {
            this.text = initialText
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(18, 14, 18, 14)
            maxWidth = (context.resources.displayMetrics.widthPixels * 0.72f).toInt()
            background = GradientDrawable().apply {
                setColor(0xEE101827.toInt())
                cornerRadius = 18f
                setStroke(2, 0xFF5B8DEF.toInt())
            }
            elevation = 12f
            setOnTouchListener(DragTouchListener())
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val layout = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 12
            y = (context.resources.displayMetrics.heightPixels * 0.18f).toInt()
        }
        try {
            windowManager.addView(text, layout)
            view = text
            params = layout
        } catch (_: Exception) {
            view = null
            params = null
        }
    }

    fun update(message: String) {
        mainHandler.post {
            view?.text = "CLASH AI COACH\n$message\n\nTentative visual analysis — verify before acting."
        }
    }

    fun hide() {
        view?.let { runCatching { windowManager.removeView(it) } }
        view = null
        params = null
    }

    private inner class DragTouchListener : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val p = params ?: return false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = p.x; startY = p.y
                    touchX = event.rawX; touchY = event.rawY
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = startX + (touchX - event.rawX).toInt()
                    p.y = startY + (event.rawY - touchY).toInt()
                    runCatching { windowManager.updateViewLayout(v, p) }
                    return true
                }
            }
            return event.action == MotionEvent.ACTION_UP
        }
    }
}

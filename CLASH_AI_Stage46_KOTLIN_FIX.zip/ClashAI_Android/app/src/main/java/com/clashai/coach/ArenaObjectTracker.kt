package com.clashai.coach

import kotlin.math.hypot

/**
 * Associates frame-difference regions across frames using box overlap and centre distance.
 * Tracks are visual-motion hypotheses only; they are not guaranteed to be troops.
 */
class ArenaObjectTracker(
    private val maxMissedFrames: Int = 3,
    private val maxMatchDistance: Float = 0.16f,
    private val smoothing: Float = 0.65f
) {
    data class Track(
        val id: Int,
        val left: Float,
        val top: Float,
        val right: Float,
        val bottom: Float,
        val velocityX: Float,
        val velocityY: Float,
        val hits: Int,
        val missedFrames: Int,
        val changedCells: Int
    ) {
        val centerX: Float get() = (left + right) / 2f
        val centerY: Float get() = (top + bottom) / 2f
        val persistent: Boolean get() = hits >= 2 && missedFrames == 0
    }

    private data class MutableTrack(
        val id: Int,
        var left: Float, var top: Float, var right: Float, var bottom: Float,
        var velocityX: Float = 0f, var velocityY: Float = 0f,
        var hits: Int = 1, var missed: Int = 0,
        var changedCells: Int = 0,
        var lastSeenMs: Long
    )

    private val tracks = mutableListOf<MutableTrack>()
    private var nextId = 1

    @Synchronized
    fun update(regions: List<ArenaMotionDetector.Region>, timestampMs: Long): List<Track> {
        tracks.forEach { it.missed++ }
        val unmatched = tracks.toMutableSet()
        // Largest regions are assigned first, reducing small noisy regions stealing a match.
        regions.sortedByDescending { it.changedCells }.forEach { region ->
            val cx = (region.left + region.right) / 2f
            val cy = (region.top + region.bottom) / 2f
            val match = unmatched.map { track ->
                val tx = (track.left + track.right) / 2f
                val ty = (track.top + track.bottom) / 2f
                val distance = hypot(cx - tx, cy - ty)
                val overlap = iou(region, track)
                track to (distance - overlap * 0.08f)
            }.filter { (track, _) ->
                val tx = (track.left + track.right) / 2f
                val ty = (track.top + track.bottom) / 2f
                hypot(cx - tx, cy - ty) <= maxMatchDistance || iou(region, track) >= 0.08f
            }.minByOrNull { it.second }?.first

            if (match == null) {
                tracks += MutableTrack(nextId++, region.left, region.top, region.right, region.bottom,
                    changedCells = region.changedCells, lastSeenMs = timestampMs)
            } else {
                unmatched.remove(match)
                val dt = ((timestampMs - match.lastSeenMs).coerceAtLeast(1L)) / 1000f
                val oldX = (match.left + match.right) / 2f
                val oldY = (match.top + match.bottom) / 2f
                val vx = (cx - oldX) / dt
                val vy = (cy - oldY) / dt
                match.velocityX = match.velocityX * 0.5f + vx * 0.5f
                match.velocityY = match.velocityY * 0.5f + vy * 0.5f
                match.left = match.left * (1f - smoothing) + region.left * smoothing
                match.top = match.top * (1f - smoothing) + region.top * smoothing
                match.right = match.right * (1f - smoothing) + region.right * smoothing
                match.bottom = match.bottom * (1f - smoothing) + region.bottom * smoothing
                match.hits++
                match.missed = 0
                match.changedCells = region.changedCells
                match.lastSeenMs = timestampMs
            }
        }
        tracks.removeAll { it.missed > maxMissedFrames }
        return tracks.map {
            Track(it.id, it.left, it.top, it.right, it.bottom, it.velocityX, it.velocityY,
                it.hits, it.missed, it.changedCells)
        }.sortedBy { it.id }
    }

    private fun iou(region: ArenaMotionDetector.Region, track: MutableTrack): Float {
        val width = (minOf(region.right, track.right) - maxOf(region.left, track.left)).coerceAtLeast(0f)
        val height = (minOf(region.bottom, track.bottom) - maxOf(region.top, track.top)).coerceAtLeast(0f)
        val intersection = width * height
        val areaA = (region.right - region.left).coerceAtLeast(0f) * (region.bottom - region.top).coerceAtLeast(0f)
        val areaB = (track.right - track.left).coerceAtLeast(0f) * (track.bottom - track.top).coerceAtLeast(0f)
        val union = areaA + areaB - intersection
        return if (union > 0f) intersection / union else 0f
    }

    @Synchronized
    fun reset() { tracks.clear(); nextId = 1 }
}

# Stage 33 — Automatic Screen Phase Recognition

## Added
- `GameScreenModeDetector` uses OCR text, known card names, screen position and repeated observations to classify `CHAOS_SELECTION`, `BATTLE`, or `UNKNOWN`.
- Requires repeated evidence (2 of the latest 3 recognised observations) before switching phase. Uncertain frames do not force a mode switch.
- A confirmed Chaos selection phase switches the shared engine context to Chaos and sends recognised offered-card names to the Chaos draft panel.
- Upper-screen and lower-screen card-name candidates are reported separately. Their ownership is deliberately NOT assumed: the app must calibrate which region belongs to the user/opponent before opponent-aware draft scoring can trust it.
- Draft candidates are kept separate from the four-card battle hand. Hand analysis is suppressed while the selection phase is active.
- On a confirmed battle phase, the draft panel stops receiving draft candidates and the shared battle engine resumes. The selected game mode remains Chaos if the battle followed a Chaos draft.

## Limits
- OCR/layout heuristics are not a trained screen classifier. Unusual UI layouts, translations, animations, card names rendered as artwork, or low-resolution capture can produce `UNKNOWN` or missed cards.
- Card names are OCR candidates, not confirmed card identities. User review remains necessary.
- Upper/lower candidate groups are not yet mapped to player/opponent ownership. That mapping requires a verified Chaos screen layout or a one-time user calibration.
- No trained model weights are bundled. Full APK build and live device validation are pending.

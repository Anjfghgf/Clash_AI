package com.clashai.coach

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class ScreenCaptureService : Service() {
    companion object {
        const val ACTION_START = "com.clashai.coach.START"
        const val ACTION_STOP = "com.clashai.coach.STOP"
        const val ACTION_OCR = "com.clashai.coach.OCR"
        const val EXTRA_TEXT = "recognized_text"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "clash_ai_capture"
        private const val NOTIFICATION_ID = 401
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var lastFrameAt = 0L
    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() { stopCapture() }
    }
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopCapture()
            ACTION_START -> {
                startForeground(NOTIFICATION_ID, notification())
                val code = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                @Suppress("DEPRECATION")
                val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                    else intent.getParcelableExtra(EXTRA_RESULT_DATA)
                if (data != null) beginCapture(code, data)
            }
        }
        return START_NOT_STICKY
    }

    private fun beginCapture(resultCode: Int, data: Intent) {
        stopProjectionOnly()
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        projection?.registerCallback(projectionCallback, Handler(mainLooper))
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        val density = metrics.densityDpi
        thread = HandlerThread("ClashAI-FrameReader").also { it.start() }
        val handler = Handler(thread!!.looper)
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ source ->
            val now = System.currentTimeMillis()
            val frame = source.acquireLatestImage() ?: return@setOnImageAvailableListener
            if (now - lastFrameAt < 1800L) { frame.close(); return@setOnImageAvailableListener }
            lastFrameAt = now
            runOcr(frame)
        }, handler)
        display = projection?.createVirtualDisplay(
            "ClashAI-Screen", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, handler
        )
    }

    private fun runOcr(frame: Image) {
        val image = try { InputImage.fromMediaImage(frame, 0) } catch (_: Exception) { frame.close(); return }
        recognizer.process(image)
            .addOnSuccessListener { result ->
                sendBroadcast(Intent(ACTION_OCR).setPackage(packageName).putExtra(EXTRA_TEXT, result.text))
            }
            .addOnCompleteListener { frame.close() }
    }

    private fun notification(): Notification {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "CLASH AI screen analysis", NotificationManager.IMPORTANCE_LOW)
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("CLASH AI is analysing your screen")
            .setContentText("Tap Stop in CLASH AI to end screen capture")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true).build()
    }

    private fun stopProjectionOnly() {
        display?.release(); display = null
        reader?.close(); reader = null
        thread?.quitSafely(); thread = null
        projection?.stop(); projection = null
    }

    private fun stopCapture() {
        stopProjectionOnly()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { stopProjectionOnly(); recognizer.close(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}

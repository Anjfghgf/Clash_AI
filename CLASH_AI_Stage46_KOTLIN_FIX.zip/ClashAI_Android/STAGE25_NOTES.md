# Stage 25 — Trainable & Installable Card Model

## Added
- Dataset audit script checks corrupt/missing images, inconsistent names, exact duplicate files, per-card sample counts and independent match sessions.
- Classifier training now performs augmentation inside the model graph during training, keeps match sessions separated, emits per-class metrics/confusion matrix, and validates exported TFLite tensor shapes plus a live inference sanity check.
- Android can import a trained `.tflite` model and matching `card_labels.txt` through the system document picker.
- Model pair is installed into app-private storage only after runtime tensor and card-catalogue validation; failed installation restores the previous pair.
- Capture service can reload the model without requiring a full app reinstall.

## Verification
- Python syntax checks and synthetic dataset audit tests: run in this build.
- Android Kotlin/Gradle APK build: not run in this environment.
- No trained model bundled: no verified labelled multi-match dataset is present.
- Live card recognition accuracy: not claimed; requires real gameplay testing after model training.

## Important
A classifier can only recognise classes it was trained on. Do not treat a high score on near-duplicate frames as proof of accuracy. Test on matches not used in training.

package com.clashai.coach

import android.content.Context
import org.json.JSONObject
import kotlin.math.max

/** Stage 29: explainable attack/defence card strategy with conservative, persistent outcome learning. */
class CardStrategyEngine(context: Context) {
    enum class UnitClass { AIR, GROUND, BUILDING, SPELL_EFFECT, UNKNOWN }
    enum class Role { WIN_CONDITION, TANK, ANTI_AIR, SPLASH, SWARM, SUPPORT, DEFENSIVE_BUILDING, SPELL, CYCLE, UNKNOWN }
    data class CardProfile(val unitClass: UnitClass, val roles: Set<Role>, val targetsAir: Boolean = false,
                           val targetsGround: Boolean = false, val cost: Int? = null)
    data class BattlefieldUnit(val label: String, val confidence: Double, val teamKnown: Boolean = false)
    data class Input(val hand: List<String>, val ownElixir: Int?, val confirmedEnemyCard: String?,
                     val enemyDeck: List<String>, val battlefield: List<BattlefieldUnit>,
                     val enemyElixirLow: Double? = null, val enemyElixirHigh: Double? = null)
    data class Advice(val mode: String, val card: String, val reason: String, val confidence: String,
                      val alternatives: List<String>, val learningNote: String, val matchup: String = "") {
        fun render() = "${mode}: $card\nMATCHUP: $matchup\nWHY: $reason\nCONFIDENCE: $confidence" +
            (if (alternatives.isEmpty()) "" else "\nALTERNATIVES: ${alternatives.joinToString(" · ")}") +
            "\nLEARNING: $learningNote"
    }

    private val prefs = context.getSharedPreferences("clash_ai_strategy_learning", Context.MODE_PRIVATE)
    private val profiles = mapOf(
        "Minions" to p(UnitClass.AIR, Role.SWARM, Role.ANTI_AIR, air = true, ground = true, cost = 3),
        "Minion Horde" to p(UnitClass.AIR, Role.SWARM, Role.ANTI_AIR, air = true, ground = true, cost = 5),
        "Bats" to p(UnitClass.AIR, Role.SWARM, Role.ANTI_AIR, air = true, ground = true, cost = 2),
        "Mega Minion" to p(UnitClass.AIR, Role.SUPPORT, Role.ANTI_AIR, air = true, ground = true, cost = 3),
        "Baby Dragon" to p(UnitClass.AIR, Role.SPLASH, Role.SUPPORT, Role.ANTI_AIR, air = true, ground = true, cost = 4),
        "Balloon" to p(UnitClass.AIR, Role.WIN_CONDITION, Role.TANK, air = false, ground = true, cost = 5),
        "Lava Hound" to p(UnitClass.AIR, Role.WIN_CONDITION, Role.TANK, air = false, ground = true, cost = 7),
        "Inferno Dragon" to p(UnitClass.AIR, Role.SUPPORT, Role.ANTI_AIR, air = true, ground = true, cost = 4),
        "Phoenix" to p(UnitClass.AIR, Role.SUPPORT, Role.ANTI_AIR, air = true, ground = true, cost = 4),
        "Knight" to p(UnitClass.GROUND, Role.SUPPORT, air = false, ground = true, cost = 3),
        "Valkyrie" to p(UnitClass.GROUND, Role.SPLASH, Role.SUPPORT, air = false, ground = true, cost = 4),
        "P.E.K.K.A" to p(UnitClass.GROUND, Role.TANK, Role.SUPPORT, air = false, ground = true, cost = 7),
        "Mega Knight" to p(UnitClass.GROUND, Role.TANK, Role.SPLASH, air = false, ground = true, cost = 7),
        "Giant" to p(UnitClass.GROUND, Role.WIN_CONDITION, Role.TANK, air = false, ground = true, cost = 5),
        "Golem" to p(UnitClass.GROUND, Role.WIN_CONDITION, Role.TANK, air = false, ground = true, cost = 8),
        "Hog Rider" to p(UnitClass.GROUND, Role.WIN_CONDITION, air = false, ground = true, cost = 4),
        "Royal Giant" to p(UnitClass.GROUND, Role.WIN_CONDITION, Role.TANK, air = false, ground = true, cost = 6),
        "Skeleton Army" to p(UnitClass.GROUND, Role.SWARM, air = false, ground = true, cost = 3),
        "Archers" to p(UnitClass.GROUND, Role.ANTI_AIR, Role.SUPPORT, air = true, ground = true, cost = 3),
        "Musketeer" to p(UnitClass.GROUND, Role.ANTI_AIR, Role.SUPPORT, air = true, ground = true, cost = 4),
        "Wizard" to p(UnitClass.GROUND, Role.SPLASH, Role.ANTI_AIR, air = true, ground = true, cost = 5),
        "Executioner" to p(UnitClass.GROUND, Role.SPLASH, Role.ANTI_AIR, air = true, ground = true, cost = 5),
        "Hunter" to p(UnitClass.GROUND, Role.ANTI_AIR, Role.SUPPORT, air = true, ground = true, cost = 4),
        "Cannon" to p(UnitClass.BUILDING, Role.DEFENSIVE_BUILDING, air = false, ground = true, cost = 3),
        "Tesla" to p(UnitClass.BUILDING, Role.DEFENSIVE_BUILDING, Role.ANTI_AIR, air = true, ground = true, cost = 4),
        "Inferno Tower" to p(UnitClass.BUILDING, Role.DEFENSIVE_BUILDING, Role.ANTI_AIR, air = true, ground = true, cost = 5),
        "Tesla" to p(UnitClass.BUILDING, Role.DEFENSIVE_BUILDING, Role.ANTI_AIR, air = true, ground = true, cost = 4),
        "Fireball" to p(UnitClass.SPELL_EFFECT, Role.SPELL, air = true, ground = true, cost = 4),
        "Arrows" to p(UnitClass.SPELL_EFFECT, Role.SPELL, air = true, ground = true, cost = 3),
        "The Log" to p(UnitClass.SPELL_EFFECT, Role.SPELL, air = false, ground = true, cost = 2),
        "Zap" to p(UnitClass.SPELL_EFFECT, Role.SPELL, air = true, ground = true, cost = 2),
        "Poison" to p(UnitClass.SPELL_EFFECT, Role.SPELL, air = true, ground = true, cost = 4),
        "Rocket" to p(UnitClass.SPELL_EFFECT, Role.SPELL, air = true, ground = true, cost = 6),
        "Skeleton Dragons" to p(UnitClass.AIR, Role.SPLASH, Role.ANTI_AIR, air = true, ground = true, cost = 4),
        "Electro Dragon" to p(UnitClass.AIR, Role.SPLASH, Role.ANTI_AIR, air = true, ground = true, cost = 5),
        "Flying Machine" to p(UnitClass.AIR, Role.SUPPORT, Role.ANTI_AIR, air = true, ground = true, cost = 4),
        "Skeleton Barrel" to p(UnitClass.AIR, Role.WIN_CONDITION, Role.SWARM, air = false, ground = true, cost = 3),
        "Inferno Dragon" to p(UnitClass.AIR, Role.ANTI_AIR, Role.SUPPORT, air = true, ground = true, cost = 4),
        "Night Witch" to p(UnitClass.GROUND, Role.SUPPORT, air = false, ground = true, cost = 4),
        "Goblin Hut" to p(UnitClass.BUILDING, Role.DEFENSIVE_BUILDING, air = false, ground = false, cost = 4),
        "Barbarian Hut" to p(UnitClass.BUILDING, Role.DEFENSIVE_BUILDING, air = false, ground = false, cost = 6),
        "Furnace" to p(UnitClass.BUILDING, Role.DEFENSIVE_BUILDING, air = false, ground = false, cost = 4),
        "Tombstone" to p(UnitClass.BUILDING, Role.DEFENSIVE_BUILDING, air = false, ground = false, cost = 3),
        "Goblin Cage" to p(UnitClass.BUILDING, Role.DEFENSIVE_BUILDING, air = false, ground = false, cost = 4),
        "Goblin Drill" to p(UnitClass.BUILDING, Role.WIN_CONDITION, Role.DEFENSIVE_BUILDING, air = false, ground = false, cost = 4),
        "Mortar" to p(UnitClass.BUILDING, Role.WIN_CONDITION, Role.DEFENSIVE_BUILDING, air = false, ground = true, cost = 4),
        "X-Bow" to p(UnitClass.BUILDING, Role.WIN_CONDITION, Role.DEFENSIVE_BUILDING, air = false, ground = true, cost = 6),
        "Earthquake" to p(UnitClass.SPELL_EFFECT, Role.SPELL, air = false, ground = true, cost = 3),
        "Giant Snowball" to p(UnitClass.SPELL_EFFECT, Role.SPELL, air = true, ground = true, cost = 2),
        "Tornado" to p(UnitClass.SPELL_EFFECT, Role.SPELL, air = true, ground = true, cost = 3),
        "Freeze" to p(UnitClass.SPELL_EFFECT, Role.SPELL, air = true, ground = true, cost = 4),
        "Lightning" to p(UnitClass.SPELL_EFFECT, Role.SPELL, air = true, ground = true, cost = 6),
        "Barbarian Barrel" to p(UnitClass.SPELL_EFFECT, Role.SPELL, air = false, ground = true, cost = 2),
        "Rage" to p(UnitClass.SPELL_EFFECT, Role.SPELL, air = true, ground = true, cost = 2),
        "Royal Recruits" to p(UnitClass.GROUND, Role.SWARM, Role.SUPPORT, air = false, ground = true, cost = 7),
        "Three Musketeers" to p(UnitClass.GROUND, Role.ANTI_AIR, Role.SUPPORT, air = true, ground = true, cost = 9),
        "Dart Goblin" to p(UnitClass.GROUND, Role.ANTI_AIR, Role.SUPPORT, air = true, ground = true, cost = 3),
        "Princess" to p(UnitClass.GROUND, Role.SPLASH, Role.ANTI_AIR, air = true, ground = true, cost = 3),
        "Magic Archer" to p(UnitClass.GROUND, Role.SPLASH, Role.ANTI_AIR, air = true, ground = true, cost = 4),
        "Electro Wizard" to p(UnitClass.GROUND, Role.ANTI_AIR, Role.SUPPORT, air = true, ground = true, cost = 4),
        "Ice Wizard" to p(UnitClass.GROUND, Role.SPLASH, Role.ANTI_AIR, air = true, ground = true, cost = 3),
        "Bowler" to p(UnitClass.GROUND, Role.SPLASH, Role.SUPPORT, air = false, ground = true, cost = 5),
        "Bomber" to p(UnitClass.GROUND, Role.SPLASH, air = false, ground = true, cost = 2),
        "Guards" to p(UnitClass.GROUND, Role.SWARM, air = false, ground = true, cost = 3),
        "Goblin Gang" to p(UnitClass.GROUND, Role.SWARM, air = false, ground = true, cost = 3),
        "Goblins" to p(UnitClass.GROUND, Role.SWARM, air = false, ground = true, cost = 2),
        "Spear Goblins" to p(UnitClass.GROUND, Role.SWARM, Role.ANTI_AIR, air = true, ground = true, cost = 2),
        "Wall Breakers" to p(UnitClass.GROUND, Role.WIN_CONDITION, Role.SWARM, air = false, ground = true, cost = 2),
        "Miner" to p(UnitClass.GROUND, Role.WIN_CONDITION, Role.SUPPORT, air = false, ground = true, cost = 3),
        "Bandit" to p(UnitClass.GROUND, Role.SUPPORT, air = false, ground = true, cost = 3),
        "Ram Rider" to p(UnitClass.GROUND, Role.WIN_CONDITION, Role.SUPPORT, air = false, ground = true, cost = 5),
        "Royal Hogs" to p(UnitClass.GROUND, Role.WIN_CONDITION, Role.SWARM, air = false, ground = true, cost = 5),
        "Electro Giant" to p(UnitClass.GROUND, Role.WIN_CONDITION, Role.TANK, air = false, ground = true, cost = 7),
        "Goblin Giant" to p(UnitClass.GROUND, Role.WIN_CONDITION, Role.TANK, air = false, ground = true, cost = 6)
    )

    private fun p(type: UnitClass, vararg roles: Role, air: Boolean, ground: Boolean, cost: Int) =
        CardProfile(type, roles.toSet(), air, ground, cost)

    fun profile(card: String): CardProfile = profiles[card] ?: CardProfile(UnitClass.UNKNOWN, setOf(Role.UNKNOWN), cost = CardCatalog.costs[card])

    @Synchronized fun evaluate(input: Input): Advice {
        val hand = input.hand.distinct().filter { it.isNotBlank() }
        val elixir = input.ownElixir
        val enemy = input.confirmedEnemyCard
        if (enemy != null) {
            val candidates = CardCatalog.countersFor(enemy).filter { it in hand && (elixir == null || (CardCatalog.costs[it] ?: 99) <= elixir) }
            if (candidates.isNotEmpty()) {
                val ranked = candidates.sortedByDescending { learnedWeight("DEFEND|$enemy|$it") }
                val chosen = ranked.first()
                return Advice("DEFEND", chosen, "A confirmed $enemy is logged. $chosen is a listed matchup option, is in your recognised hand, and fits the current elixir reading. Check placement, support troops and timing.", "Moderate for card availability; outcome is not guaranteed.", ranked.drop(1).take(2), learningSummary("DEFEND|$enemy|$chosen"), matchup = enemy)
            }
        }
        val affordableHand = hand.filter { card -> elixir != null && (CardCatalog.costs[card] ?: 99) <= elixir }
        val verifiedEnemyClasses = input.battlefield.filter { it.teamKnown && it.confidence >= 0.80 }
            .map { classifyObservedLabel(it.label) }.filter { it != UnitClass.UNKNOWN }.distinct()
        if (verifiedEnemyClasses.isNotEmpty() && affordableHand.isNotEmpty()) {
            val enemyClass = verifiedEnemyClasses.first()
            val categoryCounters = affordableHand.filter { card ->
                val own = profile(card)
                when (enemyClass) {
                    UnitClass.AIR -> own.targetsAir || own.roles.contains(Role.ANTI_AIR)
                    UnitClass.GROUND -> own.targetsGround
                    else -> false
                }
            }
            if (categoryCounters.isNotEmpty()) {
                val chosenCounter = categoryCounters.maxByOrNull { learnedWeight("DEFEND|CATEGORY_${enemyClass.name}|$it") }!!
                return Advice("DEFEND BY CATEGORY", chosenCounter, "A team-verified ${enemyClass.name.lowercase()} object is present. $chosenCounter can target this category and is affordable. This is a broad category response, not an exact card matchup; inspect its role and support.", "Moderate for category and hand fit; exact troop identity remains unknown.", categoryCounters.filter { it != chosenCounter }.take(2), learningSummary("DEFEND|CATEGORY_${enemyClass.name}|$chosenCounter"), matchup = "CATEGORY_${enemyClass.name}")
            }
        }
        val candidates = affordableHand
        if (candidates.isEmpty()) return Advice("HOLD / OBSERVE", "No safe card-specific suggestion", "Your hand or elixir is incomplete, or no recognised card is affordable. Avoid inventing a play.", "Low", emptyList(), "Waiting for a complete hand and reliable elixir reading.")

        // A push starter is favoured only when the opponent's immediate threat is not confirmed.
        val attackCandidates = candidates.filter { profile(it).roles.any { role -> role == Role.WIN_CONDITION || role == Role.TANK } }
        val supportCandidates = candidates.filter { profile(it).roles.any { role -> role == Role.SUPPORT || role == Role.ANTI_AIR || role == Role.SPLASH } }
        val knownEnemy = input.enemyDeck.distinct()
        val chosen = (attackCandidates.ifEmpty { candidates }).maxByOrNull { card ->
            val prof = profile(card)
            val synergy = if (prof.roles.contains(Role.WIN_CONDITION)) 3 else 0
            val matchup = knownEnemy.count { enemyCard ->
                val enemyProfile = profile(enemyCard)
                (enemyProfile.roles.contains(Role.ANTI_AIR) && prof.unitClass == UnitClass.AIR) ||
                    (enemyProfile.roles.contains(Role.SPLASH) && prof.roles.contains(Role.SWARM))
            }
            val costPenalty = (CardCatalog.costs[card] ?: 99) / 3
            learnedWeight("ATTACK|${knownEnemy.sorted().joinToString(",")}|$card") + synergy - matchup - costPenalty
        } ?: candidates.first()
        val support = supportCandidates.filter { it != chosen }.firstOrNull()
        val cost = CardCatalog.costs[chosen] ?: profile(chosen).cost
        val push = if (support != null && cost != null && elixir != null && elixir >= cost + (CardCatalog.costs[support] ?: 99)) " Consider $support as support only if the opponent cannot punish the other lane." else " Avoid adding support until you see the opponent's response."
        val knownCounter = knownEnemy.any { profile(it).roles.contains(Role.SPLASH) && profile(chosen).roles.contains(Role.SWARM) }
        val reason = if (attackCandidates.isNotEmpty()) "No confirmed immediate enemy card is available. $chosen is a recognised win-condition/tank option from your hand. ${if (knownCounter) "The known enemy deck may have a relevant answer, so avoid overcommitting." else "The known enemy deck does not currently show a confirmed direct matchup warning."}$push"
            else "No confirmed immediate enemy card is available. $chosen is an affordable available option; the system cannot confirm a full push plan from the current battlefield evidence."
        val key = "ATTACK|${knownEnemy.sorted().joinToString(",")}|$chosen"
        return Advice("ATTACK / PRESSURE", chosen, reason, if (input.enemyDeck.isNotEmpty()) "Low-to-moderate; opponent deck history is partial." else "Low; enemy deck and battlefield identity are not yet confirmed.", candidates.filter { it != chosen }.sortedByDescending { learnedWeight("ATTACK|${knownEnemy.sorted().joinToString(",")}|$it") }.take(2), learningSummary(key), matchup = knownEnemy.sorted().joinToString(","))
    }

    /** Call only after a user-confirmed outcome; predictions are never self-labelled as success. */
    fun recordOutcome(mode: String, matchup: String, card: String, successful: Boolean) {
        val key = "$mode|$matchup|$card"
        val old = prefs.getInt(key, 0)
        prefs.edit().putInt(key, (old + if (successful) 1 else -1).coerceIn(-10, 10))
            .putInt("${key}|samples", prefs.getInt("${key}|samples", 0) + 1).apply()
    }

    private fun learnedWeight(key: String): Int = prefs.getInt(key, 0).coerceIn(-10, 10)
    private fun learningSummary(key: String): String {
        val n = prefs.getInt("${key}|samples", 0)
        val score = learnedWeight(key)
        return if (n == 0) "No confirmed outcome history for this recommendation yet; starting neutral."
        else "Based on $n user-confirmed outcome(s); preference adjustment $score (bounded)."
    }

    fun classifyObservedLabel(label: String): UnitClass = when (label.lowercase()) {
        "troop_air", "air_troop" -> UnitClass.AIR
        "troop_ground", "ground_troop" -> UnitClass.GROUND
        "building" -> UnitClass.BUILDING
        "spell_effect", "spell" -> UnitClass.SPELL_EFFECT
        else -> UnitClass.UNKNOWN
    }

    fun learningStats(): JSONObject = JSONObject().put("storedOutcomeKeys", prefs.all.keys.count { it.endsWith("|samples") })
        .put("note", "Only explicitly confirmed outcomes update preferences; no automatic success claims.")
}

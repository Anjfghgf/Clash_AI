package com.clashai.coach

import android.app.AlertDialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

/** Lets the user mark the actual card/unit region inside an arena-event image. */
object CardCropLabeler {
    fun show(context: Context, sourcePath: String, card: ClashCard, elapsedSeconds: Long, onSaved: (Boolean) -> Unit) {
        val cardName = card.name
        val bitmap = BitmapFactory.decodeFile(sourcePath)
        if (bitmap == null) { onSaved(false); return }
        val selector = CropSelectorView(context, bitmap)
        val content = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 12, 20, 8)
            addView(TextView(context).apply { text = "Drag a box around the deployed $cardName. Include the unit/card artwork, not the whole arena." })
            addView(selector, LinearLayout.LayoutParams(-1, 420))
            addView(TextView(context).apply { text = "Tip: zoom is not required. Draw a tight rectangle around the clearest visible part." })
        }
        AlertDialog.Builder(context)
            .setTitle("Label $cardName crop")
            .setView(content)
            .setNegativeButton("Cancel") { _, _ -> bitmap.recycle(); onSaved(false) }
            .setPositiveButton("Save card crop", null)
            .setOnDismissListener { if (!bitmap.isRecycled) bitmap.recycle() }
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val crop = selector.createCrop()
                        if (crop == null) {
                            android.widget.Toast.makeText(context, "Draw a larger box around the card first.", android.widget.Toast.LENGTH_SHORT).show()
                        } else {
                            val saved = BattleSampleStore.saveCardCrop(context, crop, card, elapsedSeconds)
                            crop.recycle()
                            onSaved(saved != null)
                            dialog.dismiss()
                        }
                    }
                }
                dialog.show()
            }
    }

    private class CropSelectorView(context: Context, private val bitmap: Bitmap) : View(context) {
        private val imageRect = RectF()
        private val selection = RectF()
        private val imagePaint = Paint(Paint.FILTER_BITMAP_FLAG)
        private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x5533B5E5; style = Paint.Style.FILL }
        private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF33B5E5.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f }
        private var startX = 0f
        private var startY = 0f
        private var dragging = false

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val scale = minOf(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height)
            val w = bitmap.width * scale; val h = bitmap.height * scale
            imageRect.set((width - w) / 2f, (height - h) / 2f, (width + w) / 2f, (height + h) / 2f)
            canvas.drawBitmap(bitmap, null, imageRect, imagePaint)
            if (!selection.isEmpty) { canvas.drawRect(selection, boxPaint); canvas.drawRect(selection, borderPaint) }
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.x.coerceIn(imageRect.left, imageRect.right)
                    startY = event.y.coerceIn(imageRect.top, imageRect.bottom)
                    selection.set(startX, startY, startX, startY); dragging = true; invalidate(); return true
                }
                MotionEvent.ACTION_MOVE -> if (dragging) {
                    selection.set(minOf(startX, event.x), minOf(startY, event.y), maxOf(startX, event.x), maxOf(startY, event.y))
                    selection.intersect(imageRect); invalidate(); return true
                }
                MotionEvent.ACTION_UP -> { dragging = false; invalidate(); return true }
            }
            return true
        }

        fun createCrop(): Bitmap? {
            if (imageRect.isEmpty || selection.width() < 24f || selection.height() < 24f) return null
            val sx = bitmap.width / imageRect.width(); val sy = bitmap.height / imageRect.height()
            val left = ((selection.left - imageRect.left) * sx).toInt().coerceIn(0, bitmap.width - 1)
            val top = ((selection.top - imageRect.top) * sy).toInt().coerceIn(0, bitmap.height - 1)
            val right = ((selection.right - imageRect.left) * sx).toInt().coerceIn(left + 1, bitmap.width)
            val bottom = ((selection.bottom - imageRect.top) * sy).toInt().coerceIn(top + 1, bitmap.height)
            if (right - left < 24 || bottom - top < 24) return null
            return Bitmap.createBitmap(bitmap, left, top, right - left, bottom - top)
        }
    }
}

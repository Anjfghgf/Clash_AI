# Stage 44 — Player Action Plan

Version: 0.44.0 (versionCode 44)

## Added
- `PlayerActionPlanEngine.kt` converts the Stage 43 strategic choice into a structured action plan.
- Action plans include action type (DEFEND / COUNTERATTACK / WAIT), candidate card where justified, lane hint, known elixir cost, confidence, step-by-step human checklist, explanation, and safety note.
- Counterattack combinations are revalidated against the current recognised hand and elixir before being shown as an action.
- Defensive card suggestions distinguish a listed counter to a confirmed enemy card from a generic affordable fallback.
- `ScreenCaptureService` adds the plan to the live HUD and tactical summary.

## Safety and limits
- This is a human-confirmed coaching/action-planning layer. It does not tap, drag, deploy cards, or control Clash Royale.
- A suggested card is not a guarantee of a favourable matchup. The user must verify the battlefield, target, lane, card, and elixir.
- It does not guarantee wins.
- Reliable live actions still depend on a trained and installed battlefield/card model; no model weights are bundled.
- The Android APK and real-device capture loop were not built/tested in this environment because Android Gradle/SDK tooling is unavailable.

## Test
Run the Stage 44 smoke test with the app's Kotlin source set and its dependencies:
`training_pipeline/tests/Stage44PlayerActionPlanSmokeTest.kt`

The smoke test checks WAIT on insufficient evidence, revalidation of a counterattack combo, and mandatory confirmation for defensive actions.

package com.clashai.coach

/** Extracts known card names from a user-selected TXT/CSV/JSON-like selection file. */
object ChaosDraftFileParser {
    fun extractKnownCards(content: String, catalogue: List<String>): List<String> {
        if (content.isBlank() || catalogue.isEmpty()) return emptyList()
        val matches = catalogue.distinct().mapNotNull { name ->
            val regex = Regex("(?<![A-Za-z0-9])${Regex.escape(name)}(?![A-Za-z0-9])", RegexOption.IGNORE_CASE)
            regex.find(content)?.let { Triple(it.range.first, name, it.range.last) }
        }.sortedBy { it.first }
        val result = linkedSetOf<String>()
        matches.forEach { result.add(it.second) }
        return result.toList()
    }
}

package com.clashai.coach

/** Stage 38: explainable tactical planner. It recommends; it never taps or deploys cards. */
class TacticalDecisionPlanner {
    data class Input(
        val hand: List<String>,
        val ownElixir: Int?,
        val latestConfirmedEnemyCard: String?,
        val confirmedEnemyDeck: List<String>,
        val battlefield: List<BattlefieldUnderstandingEngine.TrackedObject>,
        val attackCombo: TacticalCombinationEngine.Combo?,
        val mode: GameModeIntelligence.Mode
    )
    data class Plan(
        val priority: String,
        val recommendation: String,
        val reason: String,
        val laneHint: String,
        val confidence: String,
        val reserveWarning: String
    ) {
        fun render() = "TACTICAL PLAN: $priority\nRECOMMENDATION: $recommendation\nWHY: $reason\nLANE / POSITION: $laneHint\nCONFIDENCE: $confidence\nELIXIR: $reserveWarning"
    }

    fun evaluate(input: Input): Plan {
        val hand = input.hand.distinct()
        val affordable = hand.filter { card ->
            val cost = CardCatalog.costs[card]
            input.ownElixir != null && cost != null && cost <= input.ownElixir
        }
        val confirmedEnemyObjects = input.battlefield.filter {
            it.side == BattlefieldStateModel.Side.ENEMY && it.confidence >= 0.70f &&
                it.kind == BattlefieldUnderstandingEngine.ObjectKind.TROOP
        }
        // Enemy units generally move from the upper half toward the bottom in portrait play.
        // The coarse tower-zone field refers to the unit's own-side tower, so it is not used here.
        val advancing = confirmedEnemyObjects.filter {
            it.movement == BattlefieldStateModel.Movement.TOWARD_BOTTOM || it.centerY >= 0.30f
        }
        val lane = advancing.map { it.lane }.firstOrNull { it != BattlefieldStateModel.Lane.UNKNOWN }
            ?.let { "Watch the ${it.name.lowercase()} lane; verify the object visually before placing." }
            ?: "No reliable lane call; keep both lanes under observation."
        val reserve = when {
            input.ownElixir == null -> "Elixir is unconfirmed; no cost-dependent play is recommended."
            input.ownElixir <= 2 -> "Low reserve (${input.ownElixir}/10); avoid an expensive commitment."
            input.ownElixir <= 4 -> "Keep a response available; avoid spending the full reserve."
            else -> "Do not spend everything on one push; retain a response if possible."
        }

        val exactEnemy = input.latestConfirmedEnemyCard
        if (exactEnemy != null) {
            val counters = CardCatalog.countersFor(exactEnemy).filter { it in affordable }
            if (counters.isNotEmpty()) {
                val chosen = counters.minByOrNull { CardCatalog.costs[it] ?: Int.MAX_VALUE }!!
                return Plan(
                    "DEFEND — confirmed card",
                    "Consider $chosen against $exactEnemy; check placement and timing yourself.",
                    "The enemy card is confirmed and $chosen is both in the recognised hand and affordable. A listed matchup is not a guaranteed counter.",
                    lane,
                    "Moderate for card identity and affordability; matchup outcome is uncertain.", reserve
                )
            }
            if (advancing.isNotEmpty()) return Plan(
                "DEFEND — no listed counter available",
                "Do not force an unavailable counter. Reassess your affordable hand and let existing tower/unit support contribute where safe.",
                "$exactEnemy is the latest confirmed play, but no listed counter is both recognised and affordable. ${advancing.size} enemy-side object(s) are in a potentially relevant area.",
                lane, "Moderate for the confirmed card; low for the full interaction.", reserve
            )
        }

        if (advancing.isNotEmpty()) {
            val airThreat = advancing.any { it.troopDomain == BattlefieldUnderstandingEngine.TroopDomain.AIR }
            val groundThreat = advancing.any { it.troopDomain == BattlefieldUnderstandingEngine.TroopDomain.GROUND }
            val suitable = affordable.filter { card ->
                val name = card.lowercase()
                if (airThreat && !groundThreat) listOf("archer", "musketeer", "hunter", "minion", "mega minion", "wizard", "dragon", "tesla", "inferno").any { it in name }
                else if (groundThreat && !airThreat) listOf("knight", "valkyrie", "pekka", "cannon", "tombstone", "inferno", "skeleton", "goblin", "bomber").any { it in name }
                else false
            }
            val suggestion = suitable.firstOrNull()
            return Plan(
                "DEFEND — category-level threat",
                suggestion?.let { "Consider $it as a broad ${if (airThreat && !groundThreat) "air-targeting" else "ground-response"} option after checking the target." }
                    ?: "Hold a flexible response and inspect the enemy object; no clearly suitable affordable card was identified.",
                "${advancing.size} enemy-side object(s) are tracked. Air/ground is used only when the detector explicitly supplied that subtype; this is not an exact card matchup.",
                lane, "Low-to-moderate; broad visual category only, not exact card identity.", reserve
            )
        }

        val combo = input.attackCombo
        if (combo != null) return Plan(
            "CONTROLLED ATTACK OPPORTUNITY",
            "Possible combination: ${combo.lead} + ${combo.support}. You decide whether the lane and timing are safe.",
            "Both cards are in the recognised hand and the combined cost (${combo.totalCost}) fits the current elixir reading. ${combo.reason}",
            "No confirmed advancing enemy threat; check both lanes and the opponent's remaining counters.",
            combo.confidence, reserve
        )
        if (affordable.isNotEmpty()) return Plan(
            "CYCLE / WAIT",
            "No strong two-card push is justified. Consider a low-cost cycle only if it is safe, otherwise wait for more information.",
            "No confirmed advancing enemy threat and no suitable attack combination was found from the current hand.",
            lane, "Low; tactical context is incomplete.", reserve
        )
        return Plan(
            "OBSERVE",
            "Wait for a reliable hand, elixir reading, or clearer battlefield evidence. No card is recommended.",
            "The planner avoids guessing when affordability or battlefield state is incomplete.",
            lane, "Low; insufficient evidence.", reserve
        )
    }
}

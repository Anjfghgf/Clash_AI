package com.clashai.coach

fun main() {
    val autopilot = ChaosDraftAutoPilot()
    val strategy = CardStrategyEngine()
    val upper = listOf("Knight", "Archers")
    val lower = listOf("Giant", "Fireball")
    val uncalibrated = ChaosDraftScreenMapping.fromStored("")
    autopilot.observe(upper + lower, upper, lower, uncalibrated, emptyList(), emptyList(), strategy)
    val waiting = autopilot.observe(upper + lower, upper, lower, uncalibrated, emptyList(), emptyList(), strategy)
    check(!waiting.calibrated)
    check(waiting.recommendation == null)

    val calibrated = ChaosDraftScreenMapping.fromStored("UPPER")
    autopilot.reset()
    autopilot.observe(upper + lower, upper, lower, calibrated, emptyList(), emptyList(), strategy)
    val stable = autopilot.observe(upper + lower, upper, lower, calibrated, emptyList(), emptyList(), strategy)
    check(stable.calibrated)
    check(stable.stableVisibleCards.containsAll(upper + lower))
    check(stable.ownVisibleCards == upper)
    check(stable.opponentVisibleCards == lower)
    check(stable.ownVisibleCards.size <= 8)
    check(stable.opponentVisibleCards.size <= 8)

    val full = autopilot.observe(upper + lower, upper, lower, calibrated,
        listOf("Knight", "Archers", "Musketeer", "Valkyrie", "Hog Rider", "Cannon", "Zap", "Giant"),
        emptyList(), strategy)
    check(full.ownVisibleCards.size == 8)
    check(full.message.contains("complete"))
    println("Stage 35 automatic Chaos draft smoke checks passed")
}

package com.clashai.coach

/**
 * Stage 19: explainable tactical assessment. Uses only confirmed card logs and
 * explicitly tentative visual evidence. This is a rule-based decision aid, not
 * a trained policy and never an autonomous player.
 */
class BattleDecisionEngine {
    data class Context(
        val latestConfirmedEnemyCard: String?,
        val confirmedEnemyDeck: List<String>,
        val availableHand: List<String>,
        val ownElixir: Int?,
        val enemyElixirLow: Double,
        val enemyElixirHigh: Double,
        val persistentTracks: Int,
        val motionCandidates: Int,
        val transientEffects: Int,
        val elapsedSeconds: Long,
        val enemyElixirKnown: Boolean = false
    )

    data class Decision(
        val situation: String,
        val recommendation: String,
        val reasoning: String,
        val confidence: String,
        val watchNext: String
    ) {
        fun render(): String = buildString {
            append("BATTLE ASSESSMENT: ").append(situation)
            append("\nRECOMMENDATION: ").append(recommendation)
            append("\nWHY: ").append(reasoning)
            append("\nCONFIDENCE: ").append(confidence)
            append("\nWATCH NEXT: ").append(watchNext)
        }
    }

    @Synchronized
    fun evaluate(c: Context): Decision {
        val low = c.enemyElixirLow.coerceIn(0.0, 10.0)
        val high = c.enemyElixirHigh.coerceIn(low, 10.0)
        val latest = c.latestConfirmedEnemyCard?.takeIf { it.isNotBlank() }
        val confirmed = c.confirmedEnemyDeck.distinct().take(8)
        val hand = c.availableHand.distinct()
        val moving = c.motionCandidates.coerceAtLeast(0)
        val persistent = c.persistentTracks.coerceAtLeast(0)
        val effects = c.transientEffects.coerceAtLeast(0)

        if (latest != null) {
            val counters = CardCatalog.countersFor(latest).distinct()
            val affordable = counters.filter { hand.contains(it) && c.ownElixir != null && estimatedCost(it) <= c.ownElixir }
            val chosen = affordable.firstOrNull()
            if (chosen != null) return Decision(
                "A confirmed enemy play: $latest",
                "Consider $chosen as a response if its placement and timing fit the arena. Keep an escape option if possible.",
                "$chosen is listed among the app's common answers to $latest, is in the recognised hand, and fits the confirmed elixir reading (${c.ownElixir}/10). A matchup suggestion is not a guaranteed counter.",
                "Moderate for hand availability; matchup outcome remains uncertain.",
                "Check the enemy support troops, lane, and whether $latest is already being handled by your tower or another unit."
            )
            if (counters.isNotEmpty()) return Decision(
                "A confirmed enemy play: $latest",
                "Avoid forcing an unavailable counter. Use a response already in your hand only if it can safely handle the threat; otherwise defend economically and reassess.",
                "Common answers recorded by the card guide: ${counters.take(3).joinToString()}. None is both in the selected hand and affordable from the current estimate.",
                "Moderate that the card was logged; low on the best response without full arena context.",
                "Track the unit's lane, remaining health, and any support before committing another card."
            )
        }

        if (persistent >= 2 || moving >= 2) return Decision(
            "Possible multi-object pressure",
            "Hold a flexible response and avoid committing your full elixir reserve until the objects are identified.",
            "The visual tracker currently reports $persistent persistent track(s) and $moving motion candidate(s). These may include animations, effects, or overlapping objects; no troop identity is confirmed.",
            "Low: visual evidence only.",
            "Look for stable team-side, direction, lane, and repeated identity across later frames."
        )
        if (moving > 0 || persistent > 0) return Decision(
            "Unidentified battlefield activity",
            "Observe another moment before choosing a specific counter. Keep your hand and elixir ready.",
            "There are $moving motion candidate(s) and $persistent persistent track(s), but no confirmed enemy card is available to this decision layer.",
            "Low: object identity and intent are unknown.",
            "Check whether the same object persists, moves toward a tower, or interacts with another unit."
        )
        if (effects > 0) return Decision(
            "Possible short-lived visual effect",
            "Do not spend a card solely because of this visual event; wait for a clearer battlefield state.",
            "$effects transient-effect hint(s) were reported. Brief animations and spell effects can resemble troop activity.",
            "Low: tentative visual classification.",
            "See whether a persistent unit or a confirmed enemy play follows the effect."
        )
        val reserveAdvice = when {
            c.ownElixir == null -> "Your elixir reading is not confirmed yet. Avoid advice that depends on an exact elixir count."
            c.ownElixir <= 2 -> "Your elixir is low (${c.ownElixir}/10); favour a safe low-cost cycle or wait rather than starting an expensive push."
            c.ownElixir <= 5 -> "Keep enough elixir for a response; avoid spending your entire reserve on support."
            hand.isEmpty() -> "Select or verify your current four-card hand before receiving card-specific advice."
            else -> "You have room to consider a measured play, but avoid committing without a lane or opponent read."
        }
        return Decision(
            "No confirmed immediate threat",
            reserveAdvice,
            "Confirmed enemy deck entries: ${confirmed.size}/8. " + if (c.enemyElixirKnown) "Enemy elixir estimate: ${"%.1f".format(java.util.Locale.US, low)}–${"%.1f".format(java.util.Locale.US, high)}." else "Enemy elixir: unknown; no reliable opponent play history is connected to this live view.",
            "Low-to-moderate: resource estimate and battlefield visibility are incomplete.",
            "Watch the opponent's next deployment and update the confirmed play log; do not fill deck slots from guesses."
        )
    }

    // Keep cost knowledge conservative; unknown cards are treated as unaffordable.
    private fun estimatedCost(card: String): Int = CardCatalog.costs[card] ?: 99
}

package com.clashai.coach

/** Approximate reference data used by the first prototype. */
object CardCatalog {
    val costs = linkedMapOf(
        "Skeletons" to 1, "Ice Spirit" to 1, "Fire Spirit" to 1, "Electro Spirit" to 1,
        "Heal Spirit" to 1, "The Log" to 2, "Zap" to 2, "Snowball" to 2,
        "Goblins" to 2, "Spear Goblins" to 2, "Bomber" to 2, "Bats" to 2,
        "Wall Breakers" to 2, "Rage" to 2, "Barbarian Barrel" to 2,
        "Knight" to 3, "Archers" to 3, "Minions" to 3, "Cannon" to 3,
        "Tombstone" to 3, "Goblin Gang" to 3, "Dart Goblin" to 3,
        "Mega Minion" to 3, "Princess" to 3, "Miner" to 3, "Bandit" to 3,
        "Royal Ghost" to 3, "Skeleton Army" to 3, "Guards" to 3,
        "Fireball" to 4, "Poison" to 4, "Musketeer" to 4, "Valkyrie" to 4,
        "Mini P.E.K.K.A" to 4, "Hog Rider" to 4, "Battle Ram" to 4,
        "Baby Dragon" to 4, "Inferno Tower" to 5, "Wizard" to 5,
        "Witch" to 5, "Prince" to 5, "Bowler" to 5, "Cannon Cart" to 5,
        "Royal Hogs" to 5, "Goblin Drill" to 4, "Giant" to 5,
        "Balloon" to 5, "Barbarian Hut" to 6, "Rocket" to 6,
        "Elite Barbarians" to 6, "Royal Giant" to 6, "X-Bow" to 6,
        "Golem" to 8, "Three Musketeers" to 9
    )

    fun findNames(text: String): List<String> {
        val normalized = text.lowercase().replace(Regex("[^a-z0-9. ]"), " ")
        return costs.keys.filter { name ->
            Regex("\\b${Regex.escape(name.lowercase())}\\b").containsMatchIn(normalized)
        }
    }
}

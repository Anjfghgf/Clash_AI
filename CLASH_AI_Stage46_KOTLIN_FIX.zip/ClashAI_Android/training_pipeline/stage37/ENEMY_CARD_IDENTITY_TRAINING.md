# Stage 37 — Training the exact enemy-card detector

The broad arena detector answers **what kind of object is this?** (air troop, ground troop, building, spell/effect). The separate enemy-card detector answers **which card produced this arena sprite?** These are different visual tasks.

## Data rules

1. Use your own gameplay recordings or footage for which the creator has explicitly authorised this training use. Publicly viewable videos are not automatically licensed for dataset creation.
2. Capture full battle frames at varied zoom, animation, lane, lighting, effects and troop scale.
3. Draw bounding boxes around visible arena units/buildings and label each with the exact card name from `CardCatalog` when genuinely identifiable.
4. If the exact card cannot be distinguished, do not guess. Leave it unlabelled for this exact-card dataset or use a separate broad-class dataset.
5. Do not use card-selection artwork as a substitute for battlefield sprites. The art and in-arena appearance differ.
6. Include multiple independent match sessions per card. The preparation script requires at least three sessions and every class in train, validation and test; for a 100+ class model, collect substantially more than this minimum.
7. Split by match/session, never by random frame, to prevent near-identical frames leaking between train and test.

## Annotation format

Use the existing `prepare_detection_dataset.py` CSV format:

`image_path,session_id,image_width,image_height,class_name,x_min,y_min,x_max,y_max`

`class_name` must exactly match the canonical card name, e.g. `Hog Rider`, `Baby Dragon`, `P.E.K.K.A`. Coordinates are pixels in the original frame.

## Train and install

```bash
python training_pipeline/scripts/prepare_detection_dataset.py --annotations annotations.csv --out enemy_card_dataset
python training_pipeline/scripts/train_arena_detector.py --data enemy_card_dataset/dataset.yaml --out enemy_card_training --epochs 100 --imgsz 640 --batch 8
```

Review test metrics, per-class recall, confusion cases and false positives. The exported model must match the Android adapter's supported FLOAT32 input `[1,size,size,3]` and YOLO-style output `[1,4+classes,candidates]` or `[1,candidates,4+classes]`. Test coordinate restoration and labels order before installation.

Copy the exported TFLite model to:

- `app/src/main/assets/enemy_card_detector.tflite`

Copy the generated `arena_detector_labels.txt` from the training output to:

- `app/src/main/assets/enemy_card_detector_labels.txt`

The labels file order must be identical to the model's output class order. Never hand-edit or reorder it.

## Evaluation gate

Do not call enemy deck tracking operational until the model has been tested on unseen match sessions and reports acceptable per-class precision/recall. False card identities are more harmful than unknown cards. The app therefore accepts only repeated stable exact-name detections with confidence at least 0.90 and an enemy-side estimate; broad classes never fill deck slots.

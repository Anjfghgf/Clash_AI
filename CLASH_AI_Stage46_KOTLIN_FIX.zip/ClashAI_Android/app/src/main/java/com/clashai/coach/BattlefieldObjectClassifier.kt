package com.clashai.coach


/**
 * Stage 16: heuristic classification of visual-motion tracks.
 * These labels describe motion/shape patterns only; they are NOT troop identities.
 * A gameplay-trained detector is required for semantic troop/building/spell recognition.
 */
class BattlefieldObjectClassifier(
    private val windowSize: Int = 5,
    private val minimumVotes: Int = 3
) {
    enum class Pattern {
        MOVING_OBJECT_CANDIDATE,
        PERSISTENT_VISUAL_OBJECT,
        TRANSIENT_EFFECT_SUSPECT,
        UNCERTAIN
    }

    data class Result(
        val trackId: Int,
        val pattern: Pattern,
        val stable: Boolean,
        val confidence: Float,
        val hits: Int,
        val speed: Float,
        val area: Float,
        val explanation: String
    )

    private val history = linkedMapOf<Int, ArrayDeque<Pattern>>()

    @Synchronized
    fun analyze(track: ArenaObjectTracker.Track): Result {
        val width = (track.right - track.left).coerceAtLeast(0f)
        val height = (track.bottom - track.top).coerceAtLeast(0f)
        val area = width * height
        val speed = kotlin.math.hypot(track.velocityX, track.velocityY)
        val pattern: Pattern
        val confidence: Float
        val explanation: String

        when {
            track.hits <= 2 || track.missedFrames > 0 -> {
                pattern = Pattern.TRANSIENT_EFFECT_SUSPECT
                confidence = 0.58f
                explanation = "Short-lived visual change; could be an effect or animation."
            }
            area < 0.00025f || area > 0.18f || width <= 0f || height <= 0f -> {
                pattern = Pattern.UNCERTAIN
                confidence = 0.45f
                explanation = "Track size is outside the conservative candidate range."
            }
            speed >= 0.018f -> {
                pattern = Pattern.MOVING_OBJECT_CANDIDATE
                confidence = (0.58f + (speed * 1.8f).coerceAtMost(0.22f)).coerceAtMost(0.80f)
                explanation = "Persistent track with measurable movement; not proof of a troop."
            }
            track.hits >= 4 -> {
                pattern = Pattern.PERSISTENT_VISUAL_OBJECT
                confidence = 0.66f
                explanation = "Persistent low-motion visual region; could be a building or other arena element."
            }
            else -> {
                pattern = Pattern.UNCERTAIN
                confidence = 0.50f
                explanation = "Not enough motion history to separate an object from an effect."
            }
        }

        val votes = history.getOrPut(track.id) { ArrayDeque() }
        votes.add(pattern)
        while (votes.size > windowSize) votes.removeFirst()
        val winner = votes.groupingBy { it }.eachCount().maxByOrNull { it.value }
        val stable = winner != null && winner.value >= minimumVotes &&
            winner.key != Pattern.UNCERTAIN && winner.key != Pattern.TRANSIENT_EFFECT_SUSPECT
        val finalPattern = if (stable) winner!!.key else pattern
        return Result(
            trackId = track.id,
            pattern = finalPattern,
            stable = stable,
            confidence = confidence,
            hits = track.hits,
            speed = speed,
            area = area,
            explanation = if (stable) "Repeated motion-pattern evidence; still not a semantic identity." else explanation
        )
    }

    @Synchronized
    fun retainOnly(activeTrackIds: Set<Int>) { history.keys.retainAll(activeTrackIds) }

    @Synchronized
    fun reset() { history.clear() }
}

package com.clashai.coach

fun main() {
    val tracker = HandRotationTracker()
    val first = tracker.observe(mapOf(0 to "Knight", 1 to "Fireball", 2 to "Log", 3 to "Archers"))
    check(first.transition == null)
    val second = tracker.observe(mapOf(0 to "Fireball", 1 to "Log", 2 to "Archers", 3 to "Goblins"))
    check(second.transition?.playedCard == "Knight")
    check(second.transition?.enteredCard == "Goblins")
    val ambiguous = tracker.observe(mapOf(0 to "Fireball", 1 to "Log", 2 to "Archers"))
    check(ambiguous.knownSlots == 3)
    check(ambiguous.transition == null)
    tracker.reset()
    check(tracker.observe(emptyMap()).transition == null)
    println("Stage 24 hand rotation smoke checks passed")
}

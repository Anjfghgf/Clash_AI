# Stage 39 test
Compile `DecisionLearningEngine.kt` with `Stage39DecisionLearningSmokeTest.kt` using kotlinc and run the generated test jar. The test checks that unconfirmed outcomes are never created, explicit outcomes are counted, modes are separated, and restored aggregates remain available.

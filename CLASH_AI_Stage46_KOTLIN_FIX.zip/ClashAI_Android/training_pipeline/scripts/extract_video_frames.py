#!/usr/bin/env python3
"""Extract review frames from locally available, authorised gameplay videos.

This script does not download videos. Record the source and its permission/licence
in sources.csv before using extracted frames for model training.
"""
import argparse, csv, hashlib, json
from pathlib import Path
import cv2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--video', required=True, type=Path)
    ap.add_argument('--out', required=True, type=Path)
    ap.add_argument('--session-id', required=True)
    ap.add_argument('--interval', type=float, default=1.5, help='seconds between sampled frames')
    ap.add_argument('--max-width', type=int, default=960)
    args = ap.parse_args()
    if args.interval <= 0: ap.error('--interval must be positive')
    cap = cv2.VideoCapture(str(args.video))
    if not cap.isOpened(): raise SystemExit(f'Cannot open video: {args.video}')
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    duration = frame_count / fps if fps else 0
    args.out.mkdir(parents=True, exist_ok=True)
    frames_dir = args.out / 'unlabelled_frames' / args.session_id
    frames_dir.mkdir(parents=True, exist_ok=True)
    rows, seen = [], set()
    t = 0.0
    while duration == 0 or t < duration:
        cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
        ok, frame = cap.read()
        if not ok: break
        h, w = frame.shape[:2]
        if w > args.max_width:
            nh = round(h * args.max_width / w)
            frame = cv2.resize(frame, (args.max_width, nh), interpolation=cv2.INTER_AREA)
        ok, encoded = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 92])
        if ok:
            digest = hashlib.sha256(encoded.tobytes()).hexdigest()
            if digest not in seen:
                seen.add(digest)
                name = f'{args.session_id}_{int(t*1000):010d}.jpg'
                path = frames_dir / name
                path.write_bytes(encoded.tobytes())
                rows.append({'image_path': str(path.relative_to(args.out)), 'session_id': args.session_id,
                             'timestamp_seconds': round(t, 3), 'card_id': '', 'card_name': '',
                             'label_status': 'needs_manual_review', 'sha256': digest})
        t += args.interval
    cap.release()
    csv_path = args.out / f'{args.session_id}_annotation_queue.csv'
    with csv_path.open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]) if rows else
            ['image_path','session_id','timestamp_seconds','card_id','card_name','label_status','sha256'])
        writer.writeheader(); writer.writerows(rows)
    meta = {'video_file': args.video.name, 'session_id': args.session_id,
            'fps': fps, 'duration_seconds': round(duration, 2), 'sample_interval_seconds': args.interval,
            'frames_saved': len(rows), 'note': 'Frames are unlabeled. Annotate only when the visible unit/card identity is clear.'}
    (args.out / f'{args.session_id}_extraction.json').write_text(json.dumps(meta, indent=2))
    print(json.dumps(meta, indent=2))

if __name__ == '__main__': main()

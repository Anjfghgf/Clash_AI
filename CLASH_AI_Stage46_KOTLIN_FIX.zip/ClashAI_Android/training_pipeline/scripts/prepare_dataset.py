#!/usr/bin/env python3
"""Validate app-exported crop ZIPs and assemble a session-aware dataset CSV."""
import argparse, csv, hashlib, json, zipfile
from pathlib import Path
from PIL import Image
from io import BytesIO


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input', required=True, type=Path, help='folder containing Android dataset ZIP exports')
    ap.add_argument('--out', required=True, type=Path)
    ap.add_argument('--min-side', type=int, default=32)
    args=ap.parse_args(); args.out.mkdir(parents=True, exist_ok=True)
    images=args.out/'images'; images.mkdir(exist_ok=True)
    rows=[]; seen=set(); skipped=[]
    for zp in sorted(args.input.glob('*.zip')):
        session=zp.stem
        try: z=zipfile.ZipFile(zp)
        except Exception as e: skipped.append({'zip':zp.name,'reason':str(e)}); continue
        with z:
            if 'labels.csv' not in z.namelist():
                skipped.append({'zip':zp.name,'reason':'missing labels.csv'}); continue
            reader=csv.DictReader(z.read('labels.csv').decode('utf-8-sig').splitlines())
            for row in reader:
                try:
                    rel=row['image_path']; card_id=int(row['card_id']); card_name=row['card_name'].strip()
                    raw=z.read(rel)
                    im=Image.open(BytesIO(raw)).convert('RGB')
                    if min(im.size)<args.min_side: raise ValueError('image too small')
                    digest=hashlib.sha256(raw).hexdigest()
                    key=(session,card_id,digest)
                    if key in seen: continue
                    seen.add(key)
                    target=images/str(card_id)/f'{session}_{digest[:16]}.jpg'
                    target.parent.mkdir(parents=True,exist_ok=True); im.save(target,'JPEG',quality=95)
                    rows.append({'image_path':str(target.relative_to(args.out)), 'card_id':card_id,
                        'card_name':card_name,'session_id':session,
                        'elixir_cost':row.get('elixir_cost',''), 'rarity':row.get('rarity','')})
                except Exception as e: skipped.append({'zip':zp.name,'row':row.get('image_path','?'),'reason':str(e)})
    with (args.out/'labels.csv').open('w',newline='',encoding='utf-8') as f:
        fields=['image_path','card_id','card_name','session_id','elixir_cost','rarity']
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)
    counts={}
    for r in rows: counts[str(r['card_id'])]=counts.get(str(r['card_id']),0)+1
    summary={'samples':len(rows),'classes':len(counts),'session_count':len(set(r['session_id'] for r in rows)),
             'per_class':counts,'skipped_rows':len(skipped),
             'warning':'A ZIP export is treated as one session. Prefer one export per match to prevent train/validation leakage.'}
    (args.out/'dataset_summary.json').write_text(json.dumps(summary,indent=2))
    (args.out/'skipped_rows.json').write_text(json.dumps(skipped,indent=2))
    print(json.dumps(summary,indent=2))

if __name__=='__main__': main()

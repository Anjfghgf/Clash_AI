# CLASH AI card and battlefield taxonomy

Keep these dimensions separate. A broad object detector may identify an object class without identifying its card.

## Battlefield object classes
- `troop_air`: verified airborne troop body.
- `troop_ground`: verified ground troop body.
- `building`: placed building or structure.
- `spell_effect`: transient spell/effect region.
- `unknown`: ambiguous, occluded, low-confidence, or unreviewed object.

## Tactical roles (multi-label)
- `win_condition`, `tank`, `anti_air`, `splash`, `swarm`, `support`, `defensive_building`, `spell`, `cycle`.

## Required annotation discipline
- Annotate exact card identity only when visually distinguishable and reviewed.
- Do not infer air/ground from the generic `troop` class. If the recording does not clearly show it, use `unknown`.
- A spell effect is not a troop. A building is not a troop.
- Team side is `unknown` until a calibrated arena/team-side model verifies it.
- Keep per-session train/validation/test splits to prevent near-identical video frames leaking across splits.

package com.clashai.coach

fun main() {
    val engine = ActionFeedbackEngine()
    check(!engine.recordOutcome(ActionFeedbackEngine.Outcome.SUCCESS))
    engine.recordRecommendation("NORMAL", "DEFEND", "Knight", "LEFT")
    engine.recordRecommendation("NORMAL", "DEFEND", "Knight", "LEFT") // OCR refresh: same pending plan
    check(engine.snapshot().single().second.recommendations == 1)
    check(engine.recordOutcome(ActionFeedbackEngine.Outcome.SUCCESS))
    check(!engine.recordOutcome(ActionFeedbackEngine.Outcome.UNSUCCESSFUL))
    engine.recordRecommendation("NORMAL", "DEFEND", "Knight", "LEFT")
    check(engine.snapshot().single().second.recommendations == 1) // same plan after feedback is still one plan
    check(!engine.recordOutcome(ActionFeedbackEngine.Outcome.UNSUCCESSFUL))

    engine.recordRecommendation("NORMAL", "WAIT", null, "BOTH")
    engine.recordOutcome(ActionFeedbackEngine.Outcome.NEUTRAL)
    repeat(2) {
        engine.recordRecommendation("NORMAL", "DEFEND", "Knight", "LEFT")
        check(engine.recordOutcome(ActionFeedbackEngine.Outcome.SUCCESS))
        engine.recordRecommendation("NORMAL", "WAIT", null, "BOTH")
        check(engine.recordOutcome(ActionFeedbackEngine.Outcome.UNSUCCESSFUL))
    }
    check(engine.insight("NORMAL").contains("Small-sample and battlefield-context warning"))
    check(engine.insight("CHAOS").contains("collecting"))

    val restored = ActionFeedbackEngine()
    engine.snapshot().forEach { (key, stats, pending) -> restored.restore(key, stats, pending) }
    check(restored.summary("NORMAL").contains("6 action plans logged"))
    check(restored.summary("NORMAL").contains("6 player-confirmed outcomes"))

    restored.recordRecommendation("CHAOS", "COUNTERATTACK", "Giant", "RIGHT")
    check(restored.recordOutcome(ActionFeedbackEngine.Outcome.NEUTRAL))
    check(restored.summary("CHAOS").contains("1 player-confirmed outcomes"))
    println("Stage 45 action feedback smoke checks passed")
}

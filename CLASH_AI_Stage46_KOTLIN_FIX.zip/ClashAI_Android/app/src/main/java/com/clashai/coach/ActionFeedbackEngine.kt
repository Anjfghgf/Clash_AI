package com.clashai.coach

/** Stage 45: learns only from explicit player feedback about a displayed action plan. */
class ActionFeedbackEngine {
    enum class Outcome { SUCCESS, NEUTRAL, UNSUCCESSFUL }
    data class Key(val mode: String, val action: String, val card: String, val lane: String)
    data class Stats(val recommendations: Int, val success: Int, val neutral: Int, val unsuccessful: Int) {
        val confirmed: Int get() = success + neutral + unsuccessful
        val successRate: Double? get() = if (confirmed == 0) null else success.toDouble() / confirmed
    }
    private val records = linkedMapOf<Key, MutableList<Int>>()
    private var pending: Key? = null
    private var lastObserved: Key? = null

    @Synchronized fun recordRecommendation(mode: String, action: String, card: String?, lane: String): Key {
        val key = Key(mode.ifBlank { "UNKNOWN" }.take(32), action.ifBlank { "UNKNOWN" }.take(32),
            card?.takeIf { it.isNotBlank() }?.take(64) ?: "NONE", lane.ifBlank { "UNKNOWN" }.take(32))
        val counts = records.getOrPut(key) { mutableListOf(0, 0, 0, 0) }
        // A stable OCR refresh is one plan, even after feedback; wait for a changed plan
        // before opening another feedback item.
        if (lastObserved != key) {
            counts[0] = (counts[0] + 1).coerceAtMost(10000)
            pending = key
            lastObserved = key
        }
        return key
    }

    /** A missing or stale pending plan is never guessed; the player must explicitly report it. */
    @Synchronized fun recordOutcome(outcome: Outcome): Boolean {
        val key = pending ?: return false
        val counts = records[key] ?: return false
        val index = when (outcome) { Outcome.SUCCESS -> 1; Outcome.NEUTRAL -> 2; Outcome.UNSUCCESSFUL -> 3 }
        counts[index] = (counts[index] + 1).coerceAtMost(10000)
        pending = null
        return true
    }

    @Synchronized fun summary(mode: String): String {
        val matching = records.filterKeys { it.mode == mode }
        val recs = matching.values.sumOf { it[0] }
        val confirmed = matching.values.sumOf { it[1] + it[2] + it[3] }
        val success = matching.values.sumOf { it[1] }
        return "ACTION FEEDBACK ($mode): $recs action plans logged · $confirmed player-confirmed outcomes · $success reported successful. Unreported plans are excluded.\n${insight(mode)}"
    }

    @Synchronized fun insight(mode: String): String {
        val candidates = records.filterKeys { it.mode == mode }.mapNotNull { (key, c) ->
            val n = c[1] + c[2] + c[3]
            if (n < 3) null else Triple("${key.action}/${key.card}/${key.lane}", c[1].toDouble() / n, n)
        }.sortedBy { it.second }
        if (candidates.size < 2) {
            val n = records.filterKeys { it.mode == mode }.values.sumOf { it[1] + it[2] + it[3] }
            return "ACTION LEARNING: collecting at least 3 confirmed outcomes per action pattern ($n total in this mode). No preference change is justified yet."
        }
        val low = candidates.first(); val high = candidates.last()
        val gap = high.second - low.second
        return if (gap >= 0.25) {
            "ACTION LEARNING: reported success differs across patterns: ${high.first} ${(high.second * 100).toInt()}% (n=${high.third}) vs ${low.first} ${(low.second * 100).toInt()}% (n=${low.third}). Small-sample and battlefield-context warning; use as a hint, not an automatic rule."
        } else "ACTION LEARNING: ${candidates.sumOf { it.third }} confirmed outcomes; no clear difference between recorded action patterns. Continue prioritising current battlefield evidence."
    }

    @Synchronized fun restore(key: Key, stats: Stats, isPending: Boolean) {
        records[key] = mutableListOf(stats.recommendations.coerceIn(0, 10000), stats.success.coerceIn(0, 10000),
            stats.neutral.coerceIn(0, 10000), stats.unsuccessful.coerceIn(0, 10000))
        lastObserved = key
        if (isPending) pending = key
    }
    @Synchronized fun snapshot(): List<Triple<Key, Stats, Boolean>> = records.map { (k, c) ->
        Triple(k, Stats(c[0], c[1], c[2], c[3]), pending == k)
    }
}

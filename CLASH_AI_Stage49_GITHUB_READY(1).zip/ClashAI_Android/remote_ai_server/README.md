# CLASH AI remote coach backend

Receives small, structured match-state JSON and returns short tactical advice through the OpenAI Responses API. It does **not** accept gameplay video or screenshots.

## Local setup

Use Python 3.10 or newer.

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

Set these environment variables on the server (never in Android source code):

- `OPENAI_API_KEY` — required; keep it secret.
- `OPENAI_MODEL` — optional; defaults to `gpt-5.5`.
- `CLASH_AI_APP_TOKEN` — optional prototype bearer token; use a long random value if enabled.
- `PORT` — optional; defaults to `8080`.

Run locally:

```bash
python app.py
```

Health check: `GET http://127.0.0.1:8080/health`

Advice endpoint: `POST /coach`

## Android connection

Build with Gradle project properties:

- `CLASH_AI_SERVER_URL=https://YOUR-HTTPS-HOST/coach`
- `CLASH_AI_APP_TOKEN=the-same-token-configured-on-the-server` (only if the server token is enabled)

Keep these in a private, user-level Gradle properties file, not source control. Do not put the OpenAI API key in Gradle properties or the APK.

The Android client sends only game mode, elixir reading/source, up to four hand cards, confirmed enemy cards, a compact battlefield summary, and local advice. It does not send screenshots or recordings. Calls are rate-limited to one every seven seconds. Local coaching remains available if the remote service is unavailable.

## Deployment safety

Deploy behind HTTPS using a production WSGI server such as Gunicorn. Do not expose Flask's development server publicly. Add hosting-provider secrets, per-user authentication, request rate limits, monitoring, and spending limits before wider use. A token embedded in an APK can be extracted, so `CLASH_AI_APP_TOKEN` is only a prototype gate, not strong user authentication.

An adult should manage the API account, key, hosting account, and any costs.

package com.clashai.coach

fun main() {
    val analyzer = LiveHudAnalyzer()
    val lowerCenter = listOf(LiveHudAnalyzer.TextRegion("7", 440f, 900f, 460f, 925f))
    val first = analyzer.observe(lowerCenter, 900, 1000)
    check(first.elixir == 7 && first.confidence == "SINGLE_OCR")
    val second = analyzer.observe(lowerCenter, 900, 1000)
    check(second.elixir == 7 && second.confidence == "REPEATED_OCR")

    val timerOnly = listOf(LiveHudAnalyzer.TextRegion("2:34", 430f, 120f, 470f, 145f))
    check(analyzer.observe(timerOnly, 900, 1000).elixir == null)
    val outOfRange = listOf(LiveHudAnalyzer.TextRegion("12", 440f, 900f, 460f, 925f))
    check(analyzer.observe(outOfRange, 900, 1000).elixir == null)

    analyzer.reset()
    val wrongSide = listOf(LiveHudAnalyzer.TextRegion("5", 20f, 900f, 40f, 925f))
    check(analyzer.observe(wrongSide, 900, 1000).elixir == null)
    println("LiveHudAnalyzer smoke checks passed")
}

# Stage 32 — Two-mode app architecture

## App modes
- **Normal:** uses the player's existing eight-card deck. Chaos draft/selection panel is hidden.
- **Chaos:** enables the competitive draft panel. The player builds an eight-card deck from the offered-card file and can account for the opponent's publicly visible picks.

## Shared engine
Both modes continue to use the same battlefield recognition, object tracking, hand/elixir analysis, enemy deck intelligence, attack/defence recommendation, tactical combination, coaching, and learning components. Mode selection changes the deck-input/draft workflow, not the battle engine implementation.

## Migration
Older stored modes (Double Elixir, Triple Elixir, Draft, 2v2, Sudden Death, Unknown) are migrated into the two app-level choices: only stored CHAOS remains Chaos; all others open as Normal. This avoids exposing more than the two requested app modes.

## Limits
The Chaos selection panel currently uses an imported offered-card file and manually entered publicly visible opponent picks. Automatic recognition of the selection screen is not yet implemented. The battle engine and recognition model limitations documented in prior stages remain. Full Android APK build and device testing are pending.

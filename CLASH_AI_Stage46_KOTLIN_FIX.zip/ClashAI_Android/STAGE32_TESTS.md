# Stage 32 verification

- Static source checks: verify only two app-level mode buttons are exposed.
- Chaos draft controls are contained in a dedicated panel and hidden unless the stored mode is CHAOS.
- Both modes retain the same screen-analysis service and shared battle context.
- Both modes enforce the fixed eight-card deck rule.
- Legacy stored modes map to Normal unless explicitly CHAOS.
- Android Gradle/APK build not run in this environment; device UI visibility and live capture require on-device testing.

package com.clashai.coach

fun main() {
    fun obj(id: Int, side: BattlefieldStateModel.Side, lane: BattlefieldStateModel.Lane,
            kind: BattlefieldUnderstandingEngine.ObjectKind, x: Float, y: Float,
            movement: BattlefieldStateModel.Movement = BattlefieldStateModel.Movement.TOWARD_BOTTOM,
            confidence: Float = 0.9f) = BattlefieldUnderstandingEngine.TrackedObject(
        id, "${kind.name.lowercase()}_unit", kind,
        BattlefieldUnderstandingEngine.TroopDomain.UNKNOWN, side, lane, movement,
        confidence, false, x, y, "MID_ARENA"
    )
    val engine = SituationalAwarenessEngine()
    val enemyPair = listOf(
        obj(1, BattlefieldStateModel.Side.ENEMY, BattlefieldStateModel.Lane.LEFT,
            BattlefieldUnderstandingEngine.ObjectKind.TROOP, 0.20f, 0.30f),
        obj(2, BattlefieldStateModel.Side.ENEMY, BattlefieldStateModel.Lane.LEFT,
            BattlefieldUnderstandingEngine.ObjectKind.TROOP, 0.25f, 0.34f)
    )
    val assessment = engine.evaluate(enemyPair)
    check(assessment.groups.any { it.side == BattlefieldStateModel.Side.ENEMY && it.troopCount == 2 })
    check(assessment.pressure == SituationalAwarenessEngine.Pressure.MEDIUM)
    check(assessment.enemyPush.contains("developing push"))

    val withSupport = engine.evaluate(enemyPair + obj(
        3, BattlefieldStateModel.Side.ENEMY, BattlefieldStateModel.Lane.LEFT,
        BattlefieldUnderstandingEngine.ObjectKind.BUILDING, 0.22f, 0.32f,
        BattlefieldStateModel.Movement.MOSTLY_STATIONARY
    ))
    check(withSupport.interactionNotes.any { it.contains("near a detected building") })

    val uncertain = engine.evaluate(listOf(
        obj(4, BattlefieldStateModel.Side.UNKNOWN, BattlefieldStateModel.Lane.UNKNOWN,
            BattlefieldUnderstandingEngine.ObjectKind.TROOP, 0.5f, 0.5f)
    ))
    check(uncertain.groups.isEmpty())
    check(uncertain.pressure == SituationalAwarenessEngine.Pressure.UNKNOWN)

    val one = engine.evaluate(listOf(enemyPair.first()))
    check(one.pressure == SituationalAwarenessEngine.Pressure.LOW)
    check(one.enemyPush.contains("not established"))

    val spell = engine.evaluate(listOf(obj(
        5, BattlefieldStateModel.Side.ENEMY, BattlefieldStateModel.Lane.RIGHT,
        BattlefieldUnderstandingEngine.ObjectKind.SPELL_EFFECT, 0.8f, 0.25f,
        BattlefieldStateModel.Movement.MOSTLY_STATIONARY
    )))
    check(spell.interactionNotes.any { it.contains("Spell/effect") })
    println("Stage 42 situational awareness smoke checks passed")
}

package com.clashai.coach

/** Conservative OCR/layout phase detector. It separates Chaos draft offers from the battle hand. */
class GameScreenModeDetector {
    enum class Phase { CHAOS_SELECTION, BATTLE, UNKNOWN }
    data class Reading(
        val phase: Phase,
        val confidence: String,
        val detectedCards: List<String>,
        val upperSelectionCandidates: List<String>,
        val lowerSelectionCandidates: List<String>,
        val reason: String
    )

    private val recent = ArrayDeque<Phase>()

    fun observe(regions: List<LiveHudAnalyzer.TextRegion>, width: Int, height: Int, cardNames: List<String>): Reading {
        if (width <= 0 || height <= 0) return Reading(Phase.UNKNOWN, "UNAVAILABLE", emptyList(), emptyList(), emptyList(), "Invalid frame size")
        val allText = regions.joinToString(" ") { it.text }.lowercase()
            .replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()
        val detectedCards = CardCatalog.findNames(allText).distinct()
        val upperCards = regions.filter { ((it.top + it.bottom) / 2f) / height < 0.50f }
            .flatMap { CardCatalog.findNames(it.text) }.distinct()
        val lowerCards = regions.filter { ((it.top + it.bottom) / 2f) / height >= 0.50f }
            .flatMap { CardCatalog.findNames(it.text) }.distinct()
        val selectionCue = listOf("choose your cards", "choose a card", "select your cards", "select a card", "pick your cards", "pick a card", "card selection", "draft").any { allText.contains(it) }
        val visibleCardRegions = regions.count { region ->
            val cy = ((region.top + region.bottom) / 2f) / height
            val text = region.text.lowercase()
            cy in 0.12f..0.82f && cardNames.any { text.contains(it.lowercase()) }
        }
        val draftStrong = selectionCue || (detectedCards.size >= 5 && visibleCardRegions >= 4)
        val lowerHudNumbers = regions.any { region ->
            val cy = ((region.top + region.bottom) / 2f) / height
            val cx = ((region.left + region.right) / 2f) / width
            cy >= 0.78f && cx in 0.44f..0.56f && region.text.trim().toIntOrNull() in 0..10
        }
        val timerCue = Regex("\\b[0-2]?:?[0-5][0-9]\\b").containsMatchIn(allText)
        val battleStrong = !draftStrong && (lowerHudNumbers || (timerCue && detectedCards.size >= 2))
        val raw = when { draftStrong -> Phase.CHAOS_SELECTION; battleStrong -> Phase.BATTLE; else -> Phase.UNKNOWN }
        if (raw != Phase.UNKNOWN) {
            recent.add(raw)
            while (recent.size > 3) recent.removeFirst()
        }
        val votes = recent.count { it == raw }
        val stable = raw != Phase.UNKNOWN && votes >= 2
        val phase = if (stable) raw else Phase.UNKNOWN
        val reason = when {
            stable && phase == Phase.CHAOS_SELECTION -> "Selection panel evidence repeated; detected card names are draft candidates, not battle hand cards."
            stable && phase == Phase.BATTLE -> "Battle HUD evidence repeated; draft panel is inactive."
            draftStrong -> "Possible Chaos selection screen; waiting for a second matching frame."
            battleStrong -> "Possible battle screen; waiting for a second matching frame."
            else -> "Screen phase is uncertain; keep current mode and do not mix draft cards with battle hand."
        }
        return Reading(
            phase,
            if (stable) "REPEATED_OCR_LAYOUT" else if (raw == Phase.UNKNOWN) "UNCERTAIN" else "SINGLE_FRAME",
            if (phase == Phase.CHAOS_SELECTION) detectedCards else emptyList(),
            if (phase == Phase.CHAOS_SELECTION) upperCards else emptyList(),
            if (phase == Phase.CHAOS_SELECTION) lowerCards else emptyList(),
            reason
        )
    }

    fun reset() { recent.clear() }
}

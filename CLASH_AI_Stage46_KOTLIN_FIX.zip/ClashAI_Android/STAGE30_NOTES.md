# Stage 30 — Tactical Combination Intelligence + Multi-mode Support

## Implemented
- `TacticalCombinationEngine.kt`: recommends an affordable two-card attack combination from the recognised hand, scores win-condition leads, support-role coverage, known opponent-deck warnings and mode context. It explains the combination and confidence.
- `GameModeIntelligence.kt`: profiles Normal, Double Elixir, Triple Elixir, Draft, Chaos, 2v2, Sudden Death and Unknown/Special. Every profile preserves the eight-card deck structure.
- Chaos/Draft deck builder: imports a user-selected TXT, CSV or JSON-like file through Android's document picker, extracts only names already present in the card catalogue, and recommends one pick at a time. The selected deck is persisted locally, duplicate picks are excluded, and the builder stops at exactly 8/8. Manual offered-card entry is available if no file is loaded.
- The user chooses the offered-card file; the app does not download or invent a card pool. Unrecognised file entries are ignored and reported through the import count.
- Both enemy deck trackers enforce eight unique cards in every mode. The four-play cycle remains active; elixir regeneration stays unknown when mode-specific timing is not verified.
- ScreenCaptureService includes selected mode details and possible two-card attack combination in live coach output.

## Important behaviour and limits
- The eight-card rule is universal across supported modes, including Chaos. Chaos differs because the deck is drafted from the cards supplied in the selected file.
- Draft/Chaos pick scoring is a role-coverage heuristic, not a learned prediction model. It only knows curated card profiles; unlisted cards remain unknown and receive no invented role.
- The imported file is parsed as text and matched against the app's known card catalogue. It does not yet parse arbitrary binary formats or image-only card sheets.
- Tactical combinations are recommendations, not automatic deployments. A valid hand and confirmed elixir reading are required.
- Exact identities of multiple simultaneously active enemy troops are not yet reliably established. Generic motion tracks are not treated as troop names.
- No trained card identity or arena detector weights are bundled.
- APK build/device test remains unverified if Gradle/Android SDK is unavailable in the build environment.

## Manual test plan
1. Select Normal and verify the deck tracker shows /8.
2. Select Chaos and verify it still shows an eight-card deck and four-play cycle.
3. Import a TXT/CSV/JSON file containing offered card names; verify only catalogue matches are loaded.
4. Recommend picks repeatedly; verify duplicates are excluded and selection stops at 8/8.
5. Verify an affordable attack combination is suggested only when hand and elixir are known.
6. Change modes, close/reopen the app, and verify selected mode persists.
7. Confirm no card is played automatically.

package com.clashai.coach

/** Per-match memory of manually confirmed opponent plays. */
class BattleMemory {
    data class Play(val card: String, val cost: Int?, val elapsedSeconds: Long)
    private val plays = mutableListOf<Play>()

    fun record(card: String, elapsedSeconds: Long) { plays.add(Play(card, CardCatalog.costs[card], elapsedSeconds)) }
    fun undo(): Boolean { if (plays.isEmpty()) return false; plays.removeAt(plays.lastIndex); return true }
    fun clear() = plays.clear()
    fun allPlays(): List<Play> = plays.toList()
    fun count(): Int = plays.size
    fun uniqueCards(): List<String> = plays.map { it.card }.distinct()
    fun latestCard(): String? = plays.lastOrNull()?.card
    fun knownSpend(): Int = plays.sumOf { it.cost ?: 0 }
    fun unknownCostCount(): Int = plays.count { it.cost == null }

    fun recentSummary(limit: Int = 8): String = if (plays.isEmpty()) "No confirmed enemy plays yet." else
        plays.takeLast(limit).asReversed().mapIndexed { i, p ->
            "${i + 1}. ${p.card} (${p.cost?.let { "$it elixir" } ?: "cost unknown"})"
        }.joinToString("\n")

    /** Four different cards after a play generally cycle that card back into hand. */
    fun cycleSummary(): String {
        if (plays.isEmpty()) return "Enemy card cycle: waiting for confirmed cards."
        val latest = plays.indices.reversed().associateBy { plays[it].card }
        val lines = latest.entries.sortedByDescending { it.value }.take(8).map { (card, index) ->
            val distinctSince = plays.drop(index + 1).map { it.card }.distinct().size
            val remaining = (4 - distinctSince).coerceAtLeast(0)
            if (remaining == 0) "$card: likely back in hand" else "$card: about $remaining different card(s) until cycle"
        }
        return "Enemy card cycle (estimate):\n" + lines.joinToString("\n")
    }
}

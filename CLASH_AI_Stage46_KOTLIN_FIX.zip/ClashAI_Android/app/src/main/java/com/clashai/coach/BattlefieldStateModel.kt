package com.clashai.coach

import kotlin.math.abs

/**
 * Stage 20: conservative, temporal battlefield state model.
 * Coordinates are normalized to [0,1]. This model does not infer troop identity
 * from motion; callers must pass detector labels with their own confidence.
 */
class BattlefieldStateModel(
    private val riverBandHalfHeight: Float = 0.055f,
    private val stableObservationsRequired: Int = 3,
    private val maxMissedObservations: Int = 2
) {
    enum class Side { FRIENDLY, ENEMY, UNKNOWN }
    enum class Lane { LEFT, RIGHT, CENTER, UNKNOWN }
    enum class Movement { TOWARD_TOP, TOWARD_BOTTOM, MOSTLY_STATIONARY, UNKNOWN }

    data class Observation(
        val trackId: Int,
        val centerX: Float,
        val centerY: Float,
        val velocityX: Float,
        val velocityY: Float,
        val detectorLabel: String? = null,
        val detectorConfidence: Float = 0f,
        val timestampMs: Long
    )

    data class ObjectState(
        val trackId: Int,
        val side: Side,
        val lane: Lane,
        val movement: Movement,
        val detectorLabel: String?,
        val identityConfirmed: Boolean,
        val confidence: Float,
        val observations: Int,
        val centerX: Float,
        val centerY: Float
    )

    data class Snapshot(
        val objects: List<ObjectState>,
        val friendlyCount: Int,
        val enemyCount: Int,
        val unknownCount: Int,
        val summary: String,
        val cautions: List<String>
    )

    private data class Entry(
        var state: ObjectState,
        var missed: Int = 0,
        var labelVotes: MutableMap<String, Int> = mutableMapOf(),
        var sideVotes: MutableMap<Side, Int> = mutableMapOf()
    )
    private val entries = linkedMapOf<Int, Entry>()

    @Synchronized fun update(observations: List<Observation>): Snapshot {
        entries.values.forEach { it.missed++ }
        observations.forEach { o ->
            if (o.trackId < 0 || !o.centerX.isFinite() || !o.centerY.isFinite()) return@forEach
            val x = o.centerX.coerceIn(0f, 1f)
            val y = o.centerY.coerceIn(0f, 1f)
            val side = when {
                y < 0.5f - riverBandHalfHeight -> Side.ENEMY
                y > 0.5f + riverBandHalfHeight -> Side.FRIENDLY
                else -> Side.UNKNOWN
            }
            val lane = when {
                x < 0.38f -> Lane.LEFT
                x > 0.62f -> Lane.RIGHT
                else -> Lane.CENTER
            }
            val movement = when {
                abs(o.velocityY) < 0.012f && abs(o.velocityX) < 0.012f -> Movement.MOSTLY_STATIONARY
                o.velocityY < -0.012f -> Movement.TOWARD_TOP
                o.velocityY > 0.012f -> Movement.TOWARD_BOTTOM
                else -> Movement.UNKNOWN
            }
            val old = entries[o.trackId]
            val votes = old?.labelVotes ?: mutableMapOf()
            val sideVotes = old?.sideVotes ?: mutableMapOf()
            if (side != Side.UNKNOWN) sideVotes[side] = (sideVotes[side] ?: 0) + 1
            val label = o.detectorLabel?.takeIf { it.isNotBlank() && o.detectorConfidence >= 0.70f }
            if (label != null) votes[label] = (votes[label] ?: 0) + 1
            val winning = votes.maxByOrNull { it.value }
            val stableLabel = winning?.key?.takeIf { winning.value >= stableObservationsRequired }
            val identityConfirmed = stableLabel != null && winning.value >= stableObservationsRequired
            val count = (old?.state?.observations ?: 0) + 1
            val sideStable = when {
                side == Side.UNKNOWN -> Side.UNKNOWN
                old == null -> side
                old.state.side == side -> side
                (sideVotes[side] ?: 0) >= stableObservationsRequired -> side
                else -> Side.UNKNOWN
            }
            val confidence = when {
                identityConfirmed -> (o.detectorConfidence * (winning!!.value.toFloat() / count.coerceAtLeast(1))).coerceIn(0f, 0.95f)
                count >= stableObservationsRequired && sideStable != Side.UNKNOWN -> 0.65f
                else -> 0.35f
            }
            val state = ObjectState(o.trackId, sideStable, lane, movement, stableLabel,
                identityConfirmed, confidence, count, x, y)
            entries[o.trackId] = Entry(state, 0, votes, sideVotes)
        }
        entries.entries.removeAll { it.value.missed > maxMissedObservations }
        return snapshot()
    }

    @Synchronized fun snapshot(): Snapshot {
        val states = entries.values.filter { it.missed == 0 }.map { it.state }.sortedBy { it.trackId }
        val friendly = states.count { it.side == Side.FRIENDLY }
        val enemy = states.count { it.side == Side.ENEMY }
        val unknown = states.size - friendly - enemy
        val cautions = mutableListOf<String>()
        if (unknown > 0) cautions += "$unknown object(s) are near the river or have uncertain side assignment."
        if (states.any { !it.identityConfirmed }) cautions += "Some object identities are still tentative; do not log them as confirmed cards."
        if (states.any { it.lane == Lane.CENTER }) cautions += "Center-lane objects need more context before assigning a target."
        val summary = when {
            states.isEmpty() -> "No current tracked objects. Waiting for battlefield observations."
            enemy > 0 && friendly > 0 -> "Tracked activity on both sides: $friendly friendly, $enemy enemy, $unknown uncertain."
            enemy > 0 -> "Enemy-side activity detected: $enemy object(s); troop identity and intent may still be uncertain."
            friendly > 0 -> "Friendly-side activity detected: $friendly object(s); check whether a counter-push is developing."
            else -> "Battlefield activity detected, but side assignment is uncertain."
        }
        return Snapshot(states, friendly, enemy, unknown, summary, cautions)
    }

    @Synchronized fun reset() { entries.clear() }
}

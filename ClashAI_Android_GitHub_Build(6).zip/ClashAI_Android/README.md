# CLASH AI Coach

Android companion app for Clash Royale battle coaching.

## Current features
- Bundled Clash Royale card catalogue and known elixir costs.
- Manual enemy-card play log and player-hand selection.
- Enemy card-cycle estimates based on the last four confirmed opponent plays.
- Enemy elixir simulation that applies logged card costs at their play timestamps, respects the 10-elixir cap, and changes regeneration by match phase.
- Approximate match timer with automatic single/double/triple-elixir phase labels; a manual double-elixir override is also available.
- Basic defensive counter and offensive coaching suggestions.
- User-approved Android MediaProjection screen capture with a persistent foreground notification.
- On-device OCR diagnostics.
- Experimental opponent-arena visual-change detector.
- When a large opponent-arena change is detected, the app saves a local crop and displays the latest crop in the app for review.

## Recognition status and limitations
The visual-change detector only flags possible battlefield activity. The crop is diagnostic evidence; it is **not** a confirmed enemy-card identity. The app still requires the player to confirm the card in the enemy tracker. OCR is diagnostic only and does not reliably identify troop sprites. A trained on-device object-detection/classification model and representative labelled gameplay frames are still required for reliable automatic card naming.

Enemy elixir is an estimate, not a value read directly from the opponent's UI. It depends on the match timer and the accuracy/completeness of manually logged enemy plays. The cycle estimate is also based only on confirmed logged plays.

## Screen capture and privacy
- Screen capture starts only after the player taps Start Screen Analysis and accepts Android's system permission prompt.
- Frame analysis and deployment-crop saving happen on-device. Crops are stored in the app's private cache and are not uploaded by this app.
- A persistent notification indicates that screen analysis is active.
- Tap Stop Screen Analysis to end capture.

## Build
Open the `ClashAI_Android` folder in Android Studio or run `gradle --no-daemon assembleDebug` from this folder with Android SDK configured.

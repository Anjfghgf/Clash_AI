package com.clashai.coach

fun main() {
    val engine = MatchPredictionEngine()
    val plan = TacticalDecisionPlanner.Plan("OBSERVE", "Hold", "No confirmed threat", "Both lanes", "Low", "Reserve")
    fun obj(y: Float, side: BattlefieldStateModel.Side = BattlefieldStateModel.Side.ENEMY,
            lane: BattlefieldStateModel.Lane = BattlefieldStateModel.Lane.LEFT) =
        BattlefieldUnderstandingEngine.TrackedObject(7, "troop", BattlefieldUnderstandingEngine.ObjectKind.TROOP,
            BattlefieldUnderstandingEngine.TroopDomain.UNKNOWN, side, lane,
            BattlefieldStateModel.Movement.TOWARD_BOTTOM, .85f, false, .25f, y, "MID_ARENA")

    val first = engine.evaluate(listOf(obj(.20f)), listOf("Knight"), 5, null, plan, 1000)
    check(first.threat != MatchPredictionEngine.Threat.HIGH)
    check(first.preferredMove == MatchPredictionEngine.Move.WAIT)
    engine.evaluate(listOf(obj(.22f)), listOf("Knight"), 5, null, plan, 2000)
    val repeated = engine.evaluate(listOf(obj(.25f)), listOf("Knight"), 5, null, plan, 3000)
    check(repeated.lanePressure.contains("left"))
    check(repeated.preferredMove == MatchPredictionEngine.Move.DEFEND)
    check(repeated.threat == MatchPredictionEngine.Threat.MEDIUM)

    engine.reset()
    val unknown = engine.evaluate(listOf(obj(.25f, BattlefieldStateModel.Side.UNKNOWN, BattlefieldStateModel.Lane.UNKNOWN)),
        listOf("Knight"), 5, null, plan, 4000)
    check(unknown.threat == MatchPredictionEngine.Threat.UNKNOWN)
    check(unknown.preferredMove == MatchPredictionEngine.Move.WAIT)

    engine.reset()
    val combo = TacticalCombinationEngine.Combo("Giant", "Musketeer", 9, "test", "Low")
    val counter = engine.evaluate(emptyList(), listOf("Giant", "Musketeer"), 9, combo, plan, 5000)
    check(counter.preferredMove == MatchPredictionEngine.Move.COUNTERATTACK)
    val unaffordable = engine.evaluate(emptyList(), listOf("Giant", "Musketeer"), 8, combo, plan, 6000)
    check(unaffordable.preferredMove == MatchPredictionEngine.Move.WAIT)
    check(counter.render().contains("possibility, not a confirmed event"))
    println("Stage 41 match prediction smoke checks passed")
}

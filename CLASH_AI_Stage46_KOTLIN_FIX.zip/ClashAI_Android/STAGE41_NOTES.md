# CLASH AI Stage 41 — Match Understanding & Prediction

Version: 0.41.0 (versionCode 41)

## Added
- `MatchPredictionEngine.kt` keeps short per-track observation history and only calls a trend when a high-confidence, enemy-side **troop** track has at least three samples and repeated downward movement.
- Reports coarse lane pressure only when the tracked lane is known. Unknown-side, unknown-kind, building, spell/effect, and low-confidence observations do not become advancing troop threats.
- Compares defensive response, waiting, and a counterattack opportunity. Counterattack is considered only when there is no confirmed advancing threat and both recognised combo cards are present and affordable from the supplied elixir reading.
- Gives a plain-language explanation and confidence warning. Predictions are possibilities, not facts; no exact path, arrival time, target, or unobserved card is invented.
- Integrates the prediction summary into the existing live coach HUD.

## Limits
- This is a transparent rule-based trend layer, not a trained predictive neural network.
- It depends on the existing battlefield detector and tracking pipeline. Stage 41 does not add trained model weights. Without a compatible `arena_detector.tflite` model and labels, the app cannot supply reliable semantic troop detections, so prediction will normally report insufficient evidence.
- Team/lane classification remains the existing coarse portrait-arena heuristic. Visual verification is still required.
- The app recommends only; it does not tap, deploy cards, or control Clash Royale.
- A full Android APK build and physical-device gameplay test were not possible in this environment (Gradle/Android SDK unavailable).

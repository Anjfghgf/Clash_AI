package com.clashai.coach

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import java.io.Closeable
import java.io.File
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Optional on-device card classifier runtime.
 *
 * Model contract (when a trained model is supplied):
 * - app/src/main/assets/card_classifier.tflite
 * - input: FLOAT32 [1, 224, 224, 3], RGB values normalized to [0, 1]
 * - output: FLOAT32 [1, class_count], softmax probabilities
 * - app/src/main/assets/card_labels.txt: one output class per line as `cardId|Card Name`
 *
 * No model is bundled in this stage. Missing/invalid model assets produce an explicit
 * unavailable state; they never produce guessed card identities.
 */
class CardRecognitionEngine(context: Context) : Closeable {
    data class Prediction(
        val card: ClashCard?,
        val confidence: Float,
        val accepted: Boolean,
        val message: String
    )

    data class ModelStatus(val ready: Boolean, val message: String, val classCount: Int = 0)

    private val appContext = context.applicationContext
    private var interpreter: Interpreter? = null
    private var labels: List<ClashCard> = emptyList()
    private val inputSize = 224
    private val confidenceThreshold = 0.78f

    val status: ModelStatus

    init {
        status = try {
            val installedDir = File(appContext.filesDir, "card_model")
            val installedModel = File(installedDir, MODEL_FILE)
            val installedLabels = File(installedDir, LABEL_FILE)
            val useInstalled = installedModel.isFile && installedLabels.isFile
            val modelBytes = if (useInstalled) installedModel.readBytes() else appContext.assets.open(MODEL_FILE).use { it.readBytes() }
            require(modelBytes.isNotEmpty() && modelBytes.size <= 128 * 1024 * 1024) { "Model file is empty or larger than 128 MB" }
            val labelStream: InputStream = if (useInstalled) installedLabels.inputStream() else appContext.assets.open(LABEL_FILE)
            labels = labelStream.bufferedReader().useLines { lines ->
                lines.mapNotNull { line ->
                    val value = line.trim()
                    if (value.isEmpty() || value.startsWith("#")) null else {
                        val parts = value.split('|', limit = 2)
                        if (parts.size != 2) null else {
                            val id = parts[0].toIntOrNull() ?: return@mapNotNull null
                            CardDatabase.findById(id)?.takeIf { it.name.equals(parts[1].trim(), true) }
                        }
                    }
                }.toList()
            }
            require(labels.isNotEmpty()) { "Card labels are missing or do not match cards.json" }
            require(labels.map { it.id }.distinct().size == labels.size) { "card_labels.txt contains duplicate card IDs" }
            val options = Interpreter.Options().apply { setNumThreads(2) }
            val modelBuffer = ByteBuffer.allocateDirect(modelBytes.size).order(ByteOrder.nativeOrder())
            modelBuffer.put(modelBytes)
            modelBuffer.rewind()
            val loaded = Interpreter(modelBuffer, options)
            interpreter = loaded
            val input = loaded.getInputTensor(0)
            val output = loaded.getOutputTensor(0)
            require(input.dataType() == DataType.FLOAT32 && input.shape().contentEquals(intArrayOf(1, inputSize, inputSize, 3))) {
                "Model input must be FLOAT32 [1,224,224,3]"
            }
            require(output.dataType() == DataType.FLOAT32 && output.shape().size == 2 && output.shape()[0] == 1 && output.shape()[1] == labels.size) {
                "Model output must be FLOAT32 [1,${labels.size}] matching card_labels.txt"
            }
            ModelStatus(true, "${if (useInstalled) "Installed" else "Bundled"} on-device card model loaded (${labels.size} classes).", labels.size)
        } catch (error: Exception) {
            interpreter?.close()
            interpreter = null
            val reason = error.message?.takeIf { it.isNotBlank() } ?: error.javaClass.simpleName
            ModelStatus(false, "Recognition model unavailable: $reason")
        }
    }

    @Synchronized
    fun classify(bitmap: Bitmap): Prediction {
        val model = interpreter ?: return Prediction(null, 0f, false, status.message)
        return try {
            val scaled = Bitmap.createScaledBitmap(bitmap, inputSize, inputSize, true)
            val input = ByteBuffer.allocateDirect(4 * inputSize * inputSize * 3).order(ByteOrder.nativeOrder())
            val pixels = IntArray(inputSize * inputSize)
            scaled.getPixels(pixels, 0, inputSize, 0, 0, inputSize, inputSize)
            if (scaled !== bitmap) scaled.recycle()
            for (pixel in pixels) {
                input.putFloat(((pixel shr 16) and 0xff) / 255f)
                input.putFloat(((pixel shr 8) and 0xff) / 255f)
                input.putFloat((pixel and 0xff) / 255f)
            }
            input.rewind()
            val output = Array(1) { FloatArray(labels.size) }
            model.run(input, output)
            val scores = output[0]
            val probabilitySum = scores.sum()
            val validProbabilities = scores.all { it.isFinite() && it in 0f..1f } && kotlin.math.abs(probabilitySum - 1f) <= 0.05f
            if (!validProbabilities) {
                return Prediction(null, 0f, false, "Model output is not a valid probability distribution; result rejected.")
            }
            val bestIndex = scores.indices.maxByOrNull { scores[it] } ?: -1
            val confidence = if (bestIndex >= 0) scores[bestIndex].coerceIn(0f, 1f) else 0f
            val card = labels.getOrNull(bestIndex)
            if (card != null && confidence >= confidenceThreshold) {
                Prediction(card, confidence, true, "Recognized ${card.name} (${(confidence * 100).toInt()}%).")
            } else {
                Prediction(null, confidence, false, "Uncertain card (${(confidence * 100).toInt()}%); keep as unknown.")
            }
        } catch (error: Exception) {
            Prediction(null, 0f, false, "Recognition failed safely: ${error.message ?: error.javaClass.simpleName}")
        }
    }

    override fun close() { interpreter?.close(); interpreter = null }

    companion object {
        private const val MODEL_FILE = "card_classifier.tflite"
        private const val LABEL_FILE = "card_labels.txt"
    }
}

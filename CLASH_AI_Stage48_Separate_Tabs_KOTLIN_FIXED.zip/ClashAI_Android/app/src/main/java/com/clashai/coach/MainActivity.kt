package com.clashai.coach

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import android.widget.LinearLayout
import android.widget.ImageView
import android.graphics.BitmapFactory
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var chaosDraftPanel: LinearLayout
    private lateinit var modeStatusText: TextView
    private lateinit var timerText: TextView
    private lateinit var enemyCardsText: TextView
    private lateinit var enemyDeckText: TextView
    private lateinit var enemyElixirText: TextView
    private lateinit var ownElixirText: TextView
    private lateinit var adviceText: TextView
    private lateinit var liveAdviceText: TextView
    private val liveBattleCoach = LiveBattleCoach()
    private val battleDecisionEngine = BattleDecisionEngine()
    private val battlefieldStateModel = BattlefieldStateModel()
    private var latestRegionCount = 0
    private var latestPersistentTracks = 0
    private var latestPatternLabels: List<String> = emptyList()
    private var enemyElixirEstimate = 5.0
    private var latestLiveAdvice = "Waiting for the first useful battlefield observation."
    private var latestStrategyMode: String? = null
    private var latestStrategyCard: String? = null
    private var latestStrategyMatchup: String = ""
    private lateinit var handText: TextView
    private lateinit var ocrText: TextView
    private lateinit var deploymentText: TextView
    private lateinit var cycleText: TextView
    private lateinit var memoryText: TextView
    private val battleMemory = BattleMemory()
    private val enemyDeckTracker = EnemyDeckTracker()
    private val enemyBattleIntelligence = EnemyBattleIntelligence()
    private lateinit var deploymentPreview: ImageView
    private val deploymentSamples = mutableListOf<String>()
    private var latestDeploymentSamplePath: String? = null
    private lateinit var visionDatasetText: TextView
    private lateinit var recognitionModelText: TextView
    private var recognitionEngine: CardRecognitionEngine? = null
    private val observed = linkedSetOf<String>()
    private val hand = linkedSetOf<String>()
    private val enemySpend = mutableListOf<Int?>()
    private val enemyPlays = mutableListOf<String>()
    private val enemyPlayTimes = mutableListOf<Long>()
    private var startedAt = 0L
    private var running = false
    private var ownElixir = 5
    private var doubleElixir = false
    private val handler = Handler(Looper.getMainLooper())

    private val ticker = object : Runnable {
        override fun run() {
            if (running) {
                refreshElixir()
                handler.postDelayed(this, 1000)
            }
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == ScreenCaptureService.ACTION_DEPLOYMENT_CANDIDATE) {
                val arenaSample = intent.getStringExtra(ScreenCaptureService.EXTRA_SNAPSHOT_PATH).orEmpty()
                val cropJson = intent.getStringExtra(ScreenCaptureService.EXTRA_TRACK_CROPS).orEmpty()
                val firstTrackCrop = try {
                    val crops = org.json.JSONArray(cropJson)
                    crops.optJSONObject(0)?.optString("path").orEmpty()
                } catch (_: Exception) { "" }
                val sample = firstTrackCrop.ifBlank { arenaSample }
                val regionJson = intent.getStringExtra(ScreenCaptureService.EXTRA_MOTION_REGIONS).orEmpty()
                val regionCount = try { org.json.JSONArray(regionJson).length() } catch (_: Exception) { 0 }
                val trackJson = intent.getStringExtra(ScreenCaptureService.EXTRA_MOTION_TRACKS).orEmpty()
                val persistentTracks = try {
                    val array = org.json.JSONArray(trackJson)
                    (0 until array.length()).count { array.optJSONObject(it)?.optBoolean("persistent") == true }
                } catch (_: Exception) { 0 }
                if (sample.isNotBlank()) {
                    latestDeploymentSamplePath = sample
                    deploymentSamples.add(sample)
                    BitmapFactory.decodeFile(sample)?.let { deploymentPreview.setImageBitmap(it) }
                    visionDatasetText.text = "Latest candidate ready for manual labelling. Saved labelled samples: ${BattleSampleStore.count(this@MainActivity)}"
                }
                val cropCount = try { org.json.JSONArray(cropJson).length() } catch (_: Exception) { 0 }
                val arenaJson = intent.getStringExtra(ScreenCaptureService.EXTRA_ARENA_DETECTIONS).orEmpty()
                val arenaSummary = intent.getStringExtra(ScreenCaptureService.EXTRA_BATTLEFIELD_SUMMARY).orEmpty()
                val arenaObjectSummary = try {
                    val array = org.json.JSONArray(arenaJson)
                    (0 until array.length()).mapNotNull { i ->
                        val item = array.optJSONObject(i) ?: return@mapNotNull null
                        "${item.optString("label")} · ${item.optString("side")} · ${item.optString("lane")} · ${item.optString("movement")} · ${item.optString("troopDomain", "UNKNOWN")}"
                    }.take(6).joinToString("\n")
                } catch (_: Exception) { "" }
                val battlefieldJson = intent.getStringExtra(ScreenCaptureService.EXTRA_BATTLEFIELD_ANALYSIS).orEmpty()
                val battlefieldSummary = try {
                    val array = org.json.JSONArray(battlefieldJson)
                    (0 until array.length()).mapNotNull { i ->
                        val item = array.optJSONObject(i) ?: return@mapNotNull null
                        val pattern = item.optString("pattern", "UNCERTAIN")
                        if (pattern == "UNCERTAIN") null else
                            "Track ${item.optInt("trackId")}: ${pattern.replace('_', ' ').lowercase()}${if (item.optBoolean("stable")) " (repeated)" else " (tentative)"}"
                    }.take(4).joinToString("\n")
                } catch (_: Exception) { "" }
                val recognitionJson = intent.getStringExtra(ScreenCaptureService.EXTRA_TRACK_RECOGNITIONS).orEmpty()
                val recognitionSummary = try {
                    val array = org.json.JSONArray(recognitionJson)
                    (0 until array.length()).mapNotNull { i ->
                        val item = array.optJSONObject(i) ?: return@mapNotNull null
                        val candidate = item.optString("stableCandidate", "")
                        when {
                            item.optBoolean("stable") && candidate.isNotBlank() -> "Track ${item.optInt("trackId")}: $candidate (consistent candidate; ${item.optInt("votes")} votes)"
                            !item.optBoolean("modelReady") -> "Track ${item.optInt("trackId")}: model unavailable"
                            candidate.isNotBlank() -> "Track ${item.optInt("trackId")}: $candidate (not verified yet)"
                            else -> null
                        }
                    }.distinct().take(4).joinToString("\n")
                } catch (_: Exception) { "" }
                val patternLabels = try {
                    val array = org.json.JSONArray(battlefieldJson)
                    (0 until array.length()).mapNotNull { i -> array.optJSONObject(i)?.optString("pattern") }
                } catch (_: Exception) { emptyList() }
                val stableRecognitionCount = try {
                    val array = org.json.JSONArray(recognitionJson)
                    (0 until array.length()).count { i ->
                        val item = array.optJSONObject(i)
                        item?.optBoolean("stable") == true && item.optString("stableCandidate").isNotBlank()
                    }
                } catch (_: Exception) { 0 }
                latestRegionCount = regionCount
                latestPersistentTracks = persistentTracks
                latestPatternLabels = patternLabels
                latestLiveAdvice = liveBattleCoach.observe(regionCount, persistentTracks, patternLabels, stableRecognitionCount).render()
                liveAdviceText.text = latestLiveAdvice + "\n\n" + liveBattleCoach.summary() + if (arenaSummary.isNotBlank()) "\n\n" + arenaSummary else ""
                startService(Intent(this@MainActivity, ScreenCaptureService::class.java).apply {
                    action = ScreenCaptureService.ACTION_UPDATE_COACH
                    putExtra(ScreenCaptureService.EXTRA_COACH_MESSAGE, (latestLiveAdvice + if (arenaSummary.isNotBlank()) "\n" + arenaSummary else "").take(350))
                })
                deploymentText.text = buildString {
                    append("2D motion regions: $regionCount · persistent tracks: $persistentTracks · individual crops: $cropCount.")
                    append("\nBattlefield pattern hints: ")
                    append(if (battlefieldSummary.isBlank()) "no useful pattern yet" else battlefieldSummary)
                    append("\nAutomatic battlefield understanding: ")
                    append(if (arenaSummary.isBlank()) "waiting for detector" else arenaSummary)
                    if (arenaObjectSummary.isNotBlank()) append("\n$arenaObjectSummary")
                    append("\nTemporal card recognition: ")
                    append(if (recognitionSummary.isBlank()) "no stable card candidate" else recognitionSummary)
                    append("\nMotion patterns and card candidates are not confirmed troops or enemy plays. Confirm manually before updating the deck.")
                }
                status.text = if (cropCount > 0) "Individual battlefield crop ready — review and label the correct card manually." else "Arena activity detected — waiting for a usable individual crop."
                return
            }
            val recognized = intent?.getStringExtra(ScreenCaptureService.EXTRA_TEXT).orEmpty()
            val hud = intent?.getStringExtra(ScreenCaptureService.EXTRA_HUD_SUMMARY).orEmpty()
            val screenPhase = intent?.getStringExtra(ScreenCaptureService.EXTRA_SCREEN_PHASE).orEmpty()
            val draftCards = intent?.getStringArrayListExtra(ScreenCaptureService.EXTRA_DRAFT_CARDS).orEmpty()
            if (screenPhase == GameScreenModeDetector.Phase.CHAOS_SELECTION.name) {
                // OCR regions are candidate observations, not a verified offered-card pool.
                latestDraftUpperCandidates = intent?.getStringArrayListExtra(ScreenCaptureService.EXTRA_DRAFT_UPPER_CARDS).orEmpty().distinct()
                latestDraftLowerCandidates = intent?.getStringArrayListExtra(ScreenCaptureService.EXTRA_DRAFT_LOWER_CARDS).orEmpty().distinct()
                val prefs = getSharedPreferences("clash_ai_chaos_draft", MODE_PRIVATE)
                prefs.edit()
                    .putString("latest_upper_candidates", latestDraftUpperCandidates.joinToString("\n"))
                    .putString("latest_lower_candidates", latestDraftLowerCandidates.joinToString("\n"))
                    .apply()
                val mapping = ChaosDraftScreenMapping.fromStored(prefs.getString("our_selection_half", "").orEmpty())
                val mapped = mapping.map(latestDraftUpperCandidates, latestDraftLowerCandidates)
                if (mapping.isCalibrated) {
                    prefs.edit()
                        .putString("opponent_visible_picks", mapped.opponentCards.joinToString(", "))
                        .putString("own_visible_picks", mapped.ourCards.joinToString("\n"))
                        .apply()
                }
                updateModePanels()
                status.text = if (mapping.isCalibrated) {
                    "Chaos selection detected. Calibrated ${mapping.ourHalf?.name?.lowercase() ?: "unknown"} half as yours. Our visible cards: ${mapped.ourCards.joinToString().ifBlank { "none read" }}. Opponent visible picks updated: ${mapped.opponentCards.joinToString().ifBlank { "none read" }}."
                } else {
                    "Chaos selection detected. Upper candidates: ${latestDraftUpperCandidates.joinToString()}; lower candidates: ${latestDraftLowerCandidates.joinToString()}. Set which half is yours in the Chaos panel; no side is guessed."
                }
            }
            if (recognized.isNotBlank() || hud.isNotBlank()) {
                val strategyLine = hud.substringAfter("CARD STRATEGY", "").lineSequence().firstOrNull().orEmpty().trim()
                if (strategyLine.contains(":")) {
                    val label = strategyLine.substringBefore(":").trim()
                    latestStrategyMode = when {
                        label.startsWith("DEFEND") -> "DEFEND"
                        label.startsWith("ATTACK") -> "ATTACK"
                        else -> null
                    }
                    latestStrategyCard = strategyLine.substringAfter(":").trim().takeIf { it.isNotBlank() && !it.startsWith("No safe") }
                    latestStrategyMatchup = strategyBlockLine(hud, "MATCHUP:")
                }
                ocrText.text = (if (hud.isNotBlank()) "$hud\n\n" else "") + "Latest screen text:\n$recognized"
            }
        }
    }

    private val datasetExportLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) {
            try {
                val result = CardDatasetExporter.export(this, uri)
                visionDatasetText.text = "Dataset exported: ${result.exported} confirmed crop(s), ${result.cards} card class(es). Skipped ${result.skipped} invalid sample(s)."
                status.text = "Dataset ZIP saved successfully."
            } catch (error: Exception) {
                status.text = "Dataset export failed: ${error.message ?: "storage error"}"
            }
        } else {
            status.text = "Dataset export cancelled."
        }
    }

    private var importedDraftOptions: List<String> = emptyList()
    private var latestDraftUpperCandidates: List<String> = emptyList()
    private var latestDraftLowerCandidates: List<String> = emptyList()

    private val chaosDraftFileLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            try {
                val content = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                importedDraftOptions = ChaosDraftFileParser.extractKnownCards(content, CardCatalog.names)
                status.text = if (importedDraftOptions.isEmpty()) "No known card names found in that file. Use a TXT, CSV or JSON file containing card names."
                    else "Loaded ${importedDraftOptions.size} offered card(s) from file: ${importedDraftOptions.joinToString(", ")}"
            } catch (error: Exception) { status.text = "Could not read selection file: ${error.message ?: "file error"}" }
        } else status.text = "Chaos selection file not chosen."
    }

    private val modelFileLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            try {
                CardModelInstaller.stage(this, uri, "card_classifier.tflite")
                status.text = "Model file staged. Now choose the matching card_labels.txt file."
                labelFileLauncher.launch(arrayOf("text/plain", "text/*", "application/octet-stream"))
            } catch (error: Exception) {
                status.text = "Model import failed: ${error.message ?: "invalid file"}"
            }
        } else status.text = "Model selection cancelled."
    }

    private val labelFileLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            try {
                CardModelInstaller.stage(this, uri, "card_labels.txt")
                val installed = CardModelInstaller.install(this)
                recognitionEngine?.close()
                recognitionEngine = CardRecognitionEngine(this)
                recognitionModelText.text = recognitionEngine?.status?.message ?: installed.message
                status.text = "Model package installed. Restart screen analysis to load it in the capture service."
                startService(Intent(this, ScreenCaptureService::class.java).setAction(ScreenCaptureService.ACTION_RELOAD_MODEL))
            } catch (error: Exception) {
                status.text = "Model package rejected: ${error.message ?: "validation failed"}. Previous model, if any, was restored."
            }
        } else status.text = "Label selection cancelled. Choose both files to install a model."
    }

    private val captureLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val service = Intent(this, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_START
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
            }
            ContextCompat.startForegroundService(this, service)
            status.text = "Screen analysis is running. ${recognitionEngine?.status?.message ?: "Card model status unavailable"}"
        } else status.text = "Screen capture permission was not granted."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CardCatalog.initialize(this)
        CardDatabase.load(this)
        recognitionEngine = CardRecognitionEngine(this)
        val savedMode = runCatching { GameModeIntelligence.Mode.valueOf(getSharedPreferences("clash_ai_strategy_context", MODE_PRIVATE).getString("game_mode", "NORMAL") ?: "NORMAL") }.getOrDefault(GameModeIntelligence.Mode.UNKNOWN)
        enemyDeckTracker.setStandardDeckRules(GameModeIntelligence().profile(savedMode).deckIsFixedEight)
        enemyBattleIntelligence.setStandardDeckRules(GameModeIntelligence().profile(savedMode).deckIsFixedEight)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 32)
            setBackgroundColor(0xFF101827.toInt())
        }
        fun heading(value: String, size: Float = 18f) = TextView(this).apply {
            text = value; textSize = size; setTextColor(0xFFFFFFFF.toInt()); setPadding(0, 12, 0, 7)
        }
        fun section(value: String) { root.addView(heading(value, 20f)) }
        fun note(value: String): TextView = heading(value, 14f).also { root.addView(it) }
        fun button(value: String, action: () -> Unit) {
            root.addView(Button(this).apply { text = value; setOnClickListener { action() } })
        }
        root.addView(heading("CLASH AI COACH", 27f))
        root.addView(heading("LIVE BATTLE ASSISTANT", 13f))
        status = note("Ready. Start a match, then start screen analysis.")
        button("START SCREEN ANALYSIS") { requestCapture() }
        button("ENABLE FLOATING COACH") { enableFloatingCoach() }
        button("HIDE FLOATING COACH") {
            startService(Intent(this, ScreenCaptureService::class.java).setAction(ScreenCaptureService.ACTION_HIDE_COACH))
            status.text = "Floating coach hidden. Screen analysis can continue."
        }
        button("STOP SCREEN ANALYSIS") {
            startService(Intent(this, ScreenCaptureService::class.java).setAction(ScreenCaptureService.ACTION_STOP))
            status.text = "Screen analysis stopped."
        }
        button("LAST STRATEGY WORKED") { submitStrategyFeedback(true) }
        button("LAST STRATEGY DID NOT WORK") { submitStrategyFeedback(false) }
        section("STAGE 39 — DECISION LEARNING FEEDBACK")
        note("The AI logs its recommendations automatically. Only your explicit feedback is counted as an outcome; no result is guessed from screen motion.")
        button("LAST TACTICAL RECOMMENDATION: SUCCESSFUL") { submitDecisionOutcome("SUCCESS") }
        button("LAST TACTICAL RECOMMENDATION: NEUTRAL") { submitDecisionOutcome("NEUTRAL") }
        button("LAST TACTICAL RECOMMENDATION: UNSUCCESSFUL") { submitDecisionOutcome("UNSUCCESSFUL") }
        section("STAGE 45 — ACTION FEEDBACK LOOP")
        note("After trying the latest action plan, report what happened. Feedback is stored on this device and is never guessed from screen movement.")
        button("LAST ACTION PLAN: SUCCESSFUL") { submitActionFeedback("SUCCESS") }
        button("LAST ACTION PLAN: NEUTRAL / UNCLEAR") { submitActionFeedback("NEUTRAL") }
        button("LAST ACTION PLAN: UNSUCCESSFUL") { submitActionFeedback("UNSUCCESSFUL") }

        section("CHOOSE GAME MODE")
        note("One CLASH AI app, two modes. Both share the same battlefield recognition, tracking, elixir, attack, defence, coaching and learning engines. Only Chaos enables the card-selection panel.")
        modeStatusText = note("Current mode: ${if (currentGameMode() == GameModeIntelligence.Mode.CHAOS) "CHAOS" else "NORMAL"}")
        button("NORMAL MODE — USE MY EXISTING 8-CARD DECK") { setGameMode(GameModeIntelligence.Mode.NORMAL) }
        button("CHAOS MODE — SELECT 8 CARDS FROM OFFERED OPTIONS") { setGameMode(GameModeIntelligence.Mode.CHAOS) }
        chaosDraftPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 6, 10, 6)
            addView(TextView(this@MainActivity).apply {
                text = "CHAOS SELECTION PANEL\nImport the offered-card file, then let the draft engine compare our deck with the opponent's visible picks. This panel is hidden in Normal mode."
                textSize = 14f; setTextColor(0xFFB8D5FF.toInt()); setPadding(4, 8, 4, 8)
            })
            addView(Button(this@MainActivity).apply {
                text = "IMPORT CHAOS OFFERED-CARDS FILE"
                setOnClickListener { chaosDraftFileLauncher.launch(arrayOf("text/*", "application/json", "application/octet-stream", "*/*")) }
            })
            addView(TextView(this@MainActivity).apply {
                text = "SCREEN SIDE CALIBRATION — choose the half that shows YOUR selections. The other half is treated as the opponent only after you confirm."
                textSize = 13f; setPadding(4, 8, 4, 4)
            })
            addView(Button(this@MainActivity).apply {
                text = "UPPER HALF IS MINE"
                setOnClickListener { setChaosSelectionHalf(ChaosDraftScreenMapping.Half.UPPER) }
            })
            addView(Button(this@MainActivity).apply {
                text = "LOWER HALF IS MINE"
                setOnClickListener { setChaosSelectionHalf(ChaosDraftScreenMapping.Half.LOWER) }
            })
            addView(Button(this@MainActivity).apply {
                text = "CLEAR SCREEN CALIBRATION"
                setOnClickListener { setChaosSelectionHalf(null) }
            })
            addView(Button(this@MainActivity).apply {
                text = "OPEN CHAOS 8-CARD DRAFT BUILDER"
                setOnClickListener { showDraftPickHelper() }
            })
        }
        root.addView(chaosDraftPanel)
        updateModePanels()

        section("BATTLE TIMER & ELIXIR")
        timerText = note("Match not started")
        enemyElixirText = note("Enemy elixir estimate: 5 / 10")
        ownElixirText = note("Your elixir: 5 / 10 (adjust below)")
        val seek = SeekBar(this).apply { max = 10; progress = ownElixir }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) { ownElixir = progress; ownElixirText.text = "Your elixir: $ownElixir / 10 (manual estimate)"; updateCoach(); syncStrategyContext() }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(seek)
        button("START / RESET MATCH TIMER") { resetMatch() }
        button("FORCE DOUBLE ELIXIR OVERRIDE") { doubleElixir = !doubleElixir; updateCoach(); status.text = if (doubleElixir) "Double elixir override ON" else "Automatic elixir timing restored" }
        button("+1 YOUR ELIXIR") { ownElixir = (ownElixir + 1).coerceAtMost(10); seek.progress = ownElixir; ownElixirText.text = "Your elixir: $ownElixir / 10 (manual estimate)"; updateCoach(); syncStrategyContext() }
        button("-1 YOUR ELIXIR") { ownElixir = (ownElixir - 1).coerceAtLeast(0); seek.progress = ownElixir; ownElixirText.text = "Your elixir: $ownElixir / 10 (manual estimate)"; updateCoach(); syncStrategyContext() }

        section("ON-DEVICE CARD RECOGNITION")
        recognitionModelText = note(recognitionEngine?.status?.message ?: "Recognition model not initialized.")
        note("Import a model trained on correctly labelled gameplay card crops. The app validates the TFLite input/output shape and card ID labels before installing it. Low-confidence results remain unknown.")
        button("IMPORT TRAINED MODEL (.tflite + labels)") {
            modelFileLauncher.launch(arrayOf("application/octet-stream", "application/x-tflite", "*/*"))
        }
        button("CHECK RECOGNITION MODEL STATUS") {
            recognitionEngine?.close()
            recognitionEngine = CardRecognitionEngine(this)
            recognitionModelText.text = recognitionEngine?.status?.message ?: "Model unavailable"
            status.text = recognitionModelText.text
        }

        section("LIVE ENEMY DEPLOYMENT DETECTION")
        deploymentText = note("Waiting for a battlefield change. This detects possible activity, not the card name yet.")
        deploymentPreview = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(0xFF263449.toInt())
            minimumHeight = 180
        }
        root.addView(deploymentPreview, LinearLayout.LayoutParams(-1, 260))
        note("The 2D detector groups changed pixels and the tracker associates nearby regions across frames, estimates movement direction, and drops tracks after repeated misses. These are still visual-motion hypotheses: troops, spell effects, hit flashes and animations can all trigger them. Review the arena crop and manually label a tight unit crop.")
        section("LIVE LEARNING & EARLY BATTLE ADVICE")
        liveAdviceText = note("Waiting for the first useful battlefield observation. Advice will be labelled tentative until evidence is stronger.")
        note("The coach accumulates observations during this match and explains what evidence supports each suggestion. This is rule-based adaptation, not trained model learning yet. It never confirms a card or changes the enemy deck automatically.")
        visionDatasetText = note("Vision dataset: no labelled samples yet.")
        button("EXPORT LABELLED CARD DATASET (ZIP)") {
            datasetExportLauncher.launch("clash_ai_card_dataset.zip")
        }
        note("Export includes only manually confirmed card-only crops and their labels. Unlabelled arena snapshots are excluded. Save the ZIP to Downloads or another folder for model training.")

        section("BATTLE MEMORY & RECENT PLAYS")
        memoryText = note("Recent confirmed enemy plays will appear here.")
        note("Battle memory is local to this match. Confirm card identities manually; screen activity detection does not identify card artwork.")

        section("ENEMY 8-CARD DECK")
        enemyDeckText = note(enemyDeckTracker.deckSummary())
        note("Only confirmed card plays fill these eight unique slots. Visual motion candidates and uncertain model predictions do not change the deck.")

        section("ENEMY CARD CYCLE")
        cycleText = note("A played card returns after four other card plays. Repeated card plays count toward the cycle.")

        section("ENEMY CARD TRACKER")
        enemyCardsText = note("No enemy cards recorded yet.")
        note("Tap a card when you see the opponent play it. OCR text matches are only possible observations.")
        addCardButtons(root, "Record enemy card", CardCatalog.names) { card ->
            enemyPlays.add(card); observed.add(card); enemySpend.add(CardCatalog.costs[card]); enemyPlayTimes.add(elapsedSeconds()); battleMemory.record(card, elapsedSeconds()); enemyDeckTracker.record(card); enemyBattleIntelligence.recordConfirmed(card, System.currentTimeMillis())
            val samplePath = latestDeploymentSamplePath
            if (!samplePath.isNullOrBlank()) {
                CardDatabase.findByName(card)?.let { cardRecord ->
                    CardCropLabeler.show(this, samplePath, cardRecord, elapsedSeconds()) { saved ->
                    visionDatasetText.text = if (saved) "Card crop labelled as $card. Total labelled samples: ${BattleSampleStore.count(this)}" else "Crop labelling cancelled or failed. You can select the card again when a new deployment sample appears."
                    if (saved) latestDeploymentSamplePath = null
                    }
                } ?: run {
                    visionDatasetText.text = "Card ID not found in API database for $card."
                }
            }
            updateCoach()
            syncStrategyContext()
        }
        button("UNDO LAST ENEMY CARD") {
            if (enemySpend.isNotEmpty()) { enemySpend.removeAt(enemySpend.lastIndex); enemyPlays.removeAt(enemyPlays.lastIndex); enemyPlayTimes.removeAt(enemyPlayTimes.lastIndex); battleMemory.undo(); enemyDeckTracker.undo(); enemyBattleIntelligence.undo(); observed.clear(); observed.addAll(enemyPlays); updateCoach(); syncStrategyContext() }
        }
        button("CLEAR ENEMY CARD LOG") { observed.clear(); enemySpend.clear(); enemyPlays.clear(); enemyPlayTimes.clear(); battleMemory.clear(); enemyDeckTracker.clear(); enemyBattleIntelligence.reset(); updateCoach(); syncStrategyContext() }

        section("YOUR 4 CARD HAND")
        handText = note("Select up to 4 cards currently in your hand.")
        addCardButtons(root, "Select / unselect your card", CardCatalog.names) { card ->
            if (hand.contains(card)) hand.remove(card) else if (hand.size < 4) hand.add(card)
            handText.text = if (hand.isEmpty()) "Select up to 4 cards currently in your hand." else "Your hand: ${hand.joinToString(" • ")}"
            updateCoach()
            syncStrategyContext()
        }
        button("CLEAR MY HAND") { hand.clear(); handText.text = "Select up to 4 cards currently in your hand."; updateCoach(); syncStrategyContext() }

        section("AI DEFENCE & ATTACK ADVICE")
        adviceText = note("Record an enemy card and select your hand to receive suggestions.")
        section("SCREEN TEXT OBSERVATIONS")
        ocrText = note("Waiting for screen capture…")
        root.addView(heading("2D vision beta: samples the opponent arena, groups changed pixels, and tracks candidate regions across frames with movement estimates. Tracks are not confirmed troops or card identities. OCR is diagnostic only. Enemy elixir remains an estimate based on logged plays and match phase.", 12f))
        setContentView(ScrollView(this).apply { addView(root) })
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
        }
        visionDatasetText.text = "Vision dataset: ${BattleSampleStore.count(this)} labelled card crop(s) stored on this phone."
        updateCoach()
    }

    private fun addCardButtons(root: LinearLayout, title: String, cards: List<String>, action: (String) -> Unit) {
        root.addView(TextView(this).apply { text = title; textSize = 12f; setTextColor(0xFFB8C5D8.toInt()); setPadding(0, 6, 0, 4) })
        // Compact text buttons keep the app usable on a phone without requiring external card images.
        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        cards.chunked(3).forEach { group ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            group.forEach { card ->
                row.addView(Button(this).apply {
                    text = "$card\n${CardCatalog.costs[card] ?: "?"} elixir"
                    textSize = 10f
                    isAllCaps = false
                    setOnClickListener { action(card) }
                }, LinearLayout.LayoutParams(0, -2, 1f))
            }
            rows.addView(row)
        }
        root.addView(rows)
    }

    private fun resetMatch() {
        startedAt = System.currentTimeMillis(); running = true; doubleElixir = false
        enemySpend.clear(); enemyPlays.clear(); enemyPlayTimes.clear(); observed.clear(); enemyDeckTracker.clear(); enemyBattleIntelligence.reset(); deploymentSamples.clear(); latestDeploymentSamplePath = null; liveBattleCoach.reset(); latestLiveAdvice = "Waiting for the first useful battlefield observation."; liveAdviceText.text = latestLiveAdvice; visionDatasetText.text = "Vision dataset: ${BattleSampleStore.count(this)} labelled card crop(s) stored on this phone."; battleMemory.clear(); ownElixir = 5
        refreshElixir(); handler.removeCallbacks(ticker); handler.post(ticker); updateCoach()
        status.text = "Match timer started. Log enemy plays as they happen."
    }

    private fun elapsedSeconds(): Long = if (startedAt == 0L) 0L else ((System.currentTimeMillis() - startedAt) / 1000L).coerceAtLeast(0L)

    private fun regenBetween(start: Long, end: Long): Double {
        var cursor = start
        var amount = 0.0
        while (cursor < end) {
            val phaseBoundary = when {
                cursor < 120L -> 120L
                cursor < 240L -> 240L
                else -> end
            }
            val next = minOf(end, phaseBoundary)
            val secondsPerElixir = when {
                cursor >= 240L -> 2.8 / 3.0
                doubleElixir || cursor >= 120L -> 1.4
                else -> 2.8
            }
            amount += (next - cursor).toDouble() / secondsPerElixir
            cursor = next
        }
        return amount
    }

    private fun refreshElixir() {
        val elapsed = elapsedSeconds()
        val phase = when { elapsed >= 240L -> 3; doubleElixir || elapsed >= 120L -> 2; else -> 1 }
        val spent = enemySpend.filterNotNull().sum()
        var estimate = 5.0
        var previousTime = 0L
        for (index in enemySpend.indices) {
            val playTime = enemyPlayTimes.getOrNull(index) ?: previousTime
            estimate = (estimate + regenBetween(previousTime, playTime)).coerceAtMost(10.0)
            enemySpend[index]?.let { estimate = (estimate - it).coerceAtLeast(0.0) }
            previousTime = playTime
        }
        estimate = (estimate + regenBetween(previousTime, elapsed)).coerceIn(0.0, 10.0)
        val mins = elapsed / 60; val secs = elapsed % 60
        timerText.text = String.format(Locale.US, "Match time: %02d:%02d", mins, secs)
        enemyElixirEstimate = estimate
        val lower = (estimate - 0.5).coerceAtLeast(0.0)
        val upper = (estimate + 0.5).coerceAtMost(10.0)
        enemyElixirText.text = String.format(Locale.US, "Enemy elixir estimate: %.1f / 10 (likely %.1f–%.1f) • known logged spend: %d • %s", estimate, lower, upper, spent, when (phase) { 3 -> "TRIPLE"; 2 -> "DOUBLE"; else -> "SINGLE" })
        ownElixirText.text = "Your elixir: $ownElixir / 10 (manual estimate)"
    }

    private fun updateCoach() {
        enemyCardsText.text = if (observed.isEmpty()) "No enemy cards recorded yet." else observed.joinToString(" • ")
        refreshElixir()
        val latest = enemyPlays.lastOrNull()
        val cycleHints = observed.mapNotNull { card ->
            val lastIndex = enemyPlays.indexOfLast { it == card }
            if (lastIndex < 0) null else {
                val playedSince = enemyPlays.lastIndex - lastIndex
                "$card: ${(4 - playedSince).coerceAtLeast(0)} card(s)"
            }
        }
        memoryText.text = "${battleMemory.count()} confirmed play(s) this match\n" + battleMemory.recentSummary(8)
        cycleText.text = enemyDeckTracker.cycleStatus()
        val fixedDeck = GameModeIntelligence().profile(currentGameMode()).deckIsFixedEight
        val deckProgress = if (fixedDeck) {
            if (enemyDeckTracker.isFull()) "\nAll eight unique cards confirmed." else "\n${(8 - enemyDeckTracker.confirmedCards().size).coerceAtLeast(0)} slot(s) not yet confirmed."
        } else "\nEight-card deck structure applies in this mode; confirm event-specific elixir rules."
        enemyDeckText.text = enemyDeckTracker.deckSummary() + deckProgress + "\n\n" + enemyBattleIntelligence.summary()
        val counterOptions = latest?.let { CardCatalog.countersFor(it) }.orEmpty()
        val available = counterOptions.filter { hand.contains(it) }
        val defence = when {
            latest == null -> "Record the enemy's latest card to get specific defence advice."
            available.isNotEmpty() -> "DEFEND vs $latest: use ${available.joinToString(" or ")}. These are suggested counters, not guaranteed wins."
            counterOptions.isNotEmpty() -> "DEFEND vs $latest: common answers include ${counterOptions.take(3).joinToString(", ")}. Select your actual hand to narrow the advice."
            else -> "DEFEND: keep a building or a suitable high-DPS / swarm answer ready for $latest. Avoid overspending."
        }
        val attack = when {
            hand.isEmpty() -> "ATTACK: select your four-card hand for card-specific attack suggestions."
            ownElixir < 4 -> "ATTACK: wait for more elixir or use a low-cost cycle card. Avoid committing your whole hand."
            observed.isEmpty() -> "ATTACK: build a push behind a surviving defender; keep enough elixir for their likely counter."
            else -> "ATTACK: consider a small counter-push with ${hand.first()}; don't stack support into a spell they've shown. Track their remaining counters before committing."
        }
        val low = (enemyElixirEstimate - 0.5).coerceAtLeast(0.0)
        val high = (enemyElixirEstimate + 0.5).coerceAtMost(10.0)
        val decision = battleDecisionEngine.evaluate(
            BattleDecisionEngine.Context(
                latestConfirmedEnemyCard = latest,
                confirmedEnemyDeck = enemyDeckTracker.confirmedCards(),
                availableHand = hand.toList(),
                ownElixir = ownElixir,
                enemyElixirLow = low,
                enemyElixirHigh = high,
                persistentTracks = latestPersistentTracks,
                motionCandidates = latestPatternLabels.count { it == "MOVING_OBJECT_CANDIDATE" },
                transientEffects = latestPatternLabels.count { it == "TRANSIENT_EFFECT_SUSPECT" },
                elapsedSeconds = elapsedSeconds()
            )
        )
        val battlefieldState = battlefieldStateModel.snapshot()
        val trackingSummary = if (fixedDeck) "${enemyDeckTracker.confirmedCards().size}/8 unique deck cards confirmed" else "${enemyDeckTracker.confirmedCards().size} confirmed cards in the eight-card deck"
        adviceText.text = "$defence\n\n$attack\n\n${decision.render()}\n\nBATTLEFIELD STATE: ${battlefieldState.summary}\n${battlefieldState.cautions.joinToString("\n")}\n\nTRACKING: $trackingSummary; ${enemySpend.size} enemy play(s) logged.\n\nLIVE BATTLE READ:\n$latestLiveAdvice"
    }

    private fun enableFloatingCoach() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            getSharedPreferences("clash_ai", MODE_PRIVATE).edit().putBoolean("pending_overlay_permission", true).apply()
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            runCatching { startActivity(intent) }.onFailure { status.text = "Could not open overlay permission settings." }
            return
        }
        startService(Intent(this, ScreenCaptureService::class.java).setAction(ScreenCaptureService.ACTION_SHOW_COACH))
        status.text = "Floating coach enabled. Start screen analysis to receive live updates."
    }

    override fun onResume() {
        super.onResume()
        val prefs = getSharedPreferences("clash_ai", MODE_PRIVATE)
        if (prefs.getBoolean("pending_overlay_permission", false)) {
            prefs.edit().putBoolean("pending_overlay_permission", false).apply()
            if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) {
                startService(Intent(this, ScreenCaptureService::class.java).setAction(ScreenCaptureService.ACTION_SHOW_COACH))
                status.text = "Floating coach enabled. Start screen analysis to receive live updates."
            } else {
                status.text = "Overlay permission was not enabled. You can enable it later."
            }
        }
    }

    @Suppress("DEPRECATION")
    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply { addAction(ScreenCaptureService.ACTION_OCR); addAction(ScreenCaptureService.ACTION_DEPLOYMENT_CANDIDATE) }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(screenReceiver, filter)
    }

    override fun onStop() { runCatching { unregisterReceiver(screenReceiver) }; super.onStop() }
    override fun onDestroy() {
        recognitionEngine?.close()
        recognitionEngine = null
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun currentGameMode(): GameModeIntelligence.Mode {
        val stored = getSharedPreferences("clash_ai_strategy_context", MODE_PRIVATE).getString("game_mode", "NORMAL")
        // Migrate older builds' extra mode buttons into the two-mode app shell.
        return if (stored == GameModeIntelligence.Mode.CHAOS.name) GameModeIntelligence.Mode.CHAOS else GameModeIntelligence.Mode.NORMAL
    }

    private fun setGameMode(requestedMode: GameModeIntelligence.Mode) {
        // The app intentionally exposes two top-level modes. Other event rules can be
        // represented by shared-engine context later, but do not create extra app modes.
        val mode = if (requestedMode == GameModeIntelligence.Mode.CHAOS) GameModeIntelligence.Mode.CHAOS else GameModeIntelligence.Mode.NORMAL
        enemyDeckTracker.setStandardDeckRules(true)
        enemyBattleIntelligence.setStandardDeckRules(true)
        getSharedPreferences("clash_ai_strategy_context", MODE_PRIVATE).edit().putString("game_mode", mode.name).apply()
        syncStrategyContext()
        startService(Intent(this, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_SET_GAME_MODE
            putExtra(ScreenCaptureService.EXTRA_GAME_MODE, mode.name)
        })
        updateModePanels()
        status.text = if (mode == GameModeIntelligence.Mode.CHAOS)
            "Chaos mode active. Draft panel enabled; shared battle engine will be used after deck selection."
        else "Normal mode active. Existing deck selected; Chaos selection panel hidden. Shared battle engine remains active."
    }

    private fun updateModePanels() {
        if (!::chaosDraftPanel.isInitialized) return
        val chaos = currentGameMode() == GameModeIntelligence.Mode.CHAOS
        chaosDraftPanel.visibility = if (chaos) android.view.View.VISIBLE else android.view.View.GONE
        if (::modeStatusText.isInitialized) modeStatusText.text = "Current mode: ${if (chaos) "CHAOS — draft enabled" else "NORMAL — existing deck"}"
    }

    private fun setChaosSelectionHalf(half: ChaosDraftScreenMapping.Half?) {
        val prefs = getSharedPreferences("clash_ai_chaos_draft", MODE_PRIVATE)
        prefs.edit().putString("our_selection_half", half?.name.orEmpty()).apply()
        if (latestDraftUpperCandidates.isEmpty()) latestDraftUpperCandidates = prefs.getString("latest_upper_candidates", "").orEmpty().lines().filter { it.isNotBlank() }
        if (latestDraftLowerCandidates.isEmpty()) latestDraftLowerCandidates = prefs.getString("latest_lower_candidates", "").orEmpty().lines().filter { it.isNotBlank() }
        val mapping = ChaosDraftScreenMapping.fromStored(half?.name.orEmpty())
        val mapped = mapping.map(latestDraftUpperCandidates, latestDraftLowerCandidates)
        if (mapping.isCalibrated) {
            prefs.edit()
                .putString("opponent_visible_picks", mapped.opponentCards.joinToString(", "))
                .putString("own_visible_picks", mapped.ourCards.joinToString("\n"))
                .apply()
            status.text = "Calibration saved: ${half!!.name.lowercase()} half is yours. Own visible cards: ${mapped.ourCards.joinToString().ifBlank { "none" }}. Opponent picks: ${mapped.opponentCards.joinToString().ifBlank { "none" }}."
        } else {
            status.text = "Screen-side calibration cleared. CLASH AI will not guess which half belongs to either player."
        }
    }

    private fun showDraftPickHelper() {
        val optionsInput = EditText(this).apply { hint = "Optional manual offered cards, comma separated" }
        val saved = getSharedPreferences("clash_ai_chaos_draft", MODE_PRIVATE)
        val selected = saved.getString("selected_cards", "").orEmpty().split("\n").map { it.trim() }.filter { it.isNotBlank() }.distinct().toMutableList()
        val ownVisible = saved.getString("own_visible_picks", "").orEmpty().lines().map { it.trim() }.filter { it.isNotBlank() }.distinct()
        val deckInput = EditText(this).apply {
            hint = "Our selected cards (one per line) — review OCR suggestions"
            setText((selected.ifEmpty { ownVisible }).joinToString("\n"))
            minLines = 3
        }
        val enemyInput = EditText(this).apply {
            hint = "Opponent's publicly visible picks (comma separated)"
            setText(saved.getString("opponent_visible_picks", "").orEmpty())
            minLines = 2
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 12, 28, 4)
            addView(TextView(this@MainActivity).apply { text = "Verified offered-card file entries: ${importedDraftOptions.size}. OCR screen candidates are tracked separately and are not automatically treated as the offer pool." })
            addView(optionsInput)
            addView(TextView(this@MainActivity).apply { text = "Our deck — target 8 cards" })
            addView(deckInput)
            addView(TextView(this@MainActivity).apply { text = "Opponent picks visible to both players" })
            addView(enemyInput)
        }
        AlertDialog.Builder(this)
            .setTitle("Chaos — competitive 8-card draft")
            .setMessage("The AI balances our deck and considers the opponent's visible selections. It recommends one card at a time; you make the selection in-game.")
            .setView(panel)
            .setNegativeButton("Close", null)
            .setNeutralButton("Reset picks") { _, _ ->
                saved.edit().remove("selected_cards").remove("opponent_visible_picks").apply()
                status.text = "Chaos draft reset (our deck 0/8; opponent picks cleared)."
            }
            .setPositiveButton("Recommend best pick") { _, _ ->
                val manual = optionsInput.text.toString().split(",").map { it.trim() }.filter { it.isNotBlank() }
                val offered = (if (importedDraftOptions.isNotEmpty()) importedDraftOptions else manual).distinct()
                val chosenSoFar = deckInput.text.toString().lines().map { it.trim() }.filter { it.isNotBlank() }.distinct()
                val enemyPicks = enemyInput.text.toString().split(",", "\n").map { it.trim() }.filter { it.isNotBlank() }.distinct()
                saved.edit().putString("opponent_visible_picks", enemyPicks.joinToString(", ")).apply()
                when {
                    chosenSoFar.size >= 8 -> status.text = "Our deck is complete: 8/8. No ninth pick is allowed."
                    offered.isEmpty() -> status.text = "Import the offered-cards file or enter the available cards first."
                    else -> {
                        val strategy = CardStrategyEngine(this)
                        val advice = ChaosCompetitiveDraftEngine(strategy).recommend(offered, chosenSoFar, enemyPicks)
                        if (advice == null) status.text = "No eligible offered cards remain."
                        else {
                            val updated = (chosenSoFar + advice.card).distinct().take(8)
                            saved.edit().putString("selected_cards", updated.joinToString("\n")).apply()
                            status.text = "CHAOS PICK ${updated.size}/8: ${advice.card}\n${advice.reason}\nDeck coverage score: ${advice.ownDeckScore}; opponent-pick denial value: ${advice.denialScore}.\nAlternatives: ${advice.alternatives.joinToString(" · ").ifBlank { "none" }}\nOur deck: ${updated.joinToString(" · ")}\nOpponent visible picks: ${enemyPicks.joinToString(" · ").ifBlank { "not entered" }}"
                        }
                    }
                }
            }.show()
    }

    private fun strategyBlockLine(hud: String, prefix: String): String {
        val block = hud.substringAfter("CARD STRATEGY", "")
        return block.lineSequence().firstOrNull { it.trim().startsWith(prefix) }
            ?.substringAfter(prefix)?.trim().orEmpty()
    }

    private fun syncStrategyContext() {
        getSharedPreferences("clash_ai_strategy_context", MODE_PRIVATE).edit()
            .putString("enemy_card", battleMemory.latestCard().orEmpty())
            .putStringSet("enemy_deck", enemyDeckTracker.confirmedCards().toSet())
            .putStringSet("hand", hand.toSet())
            .putInt("own_elixir", ownElixir).apply()
        startService(Intent(this, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_UPDATE_STRATEGY_CONTEXT
            putExtra(ScreenCaptureService.EXTRA_STRATEGY_ENEMY_CARD, battleMemory.latestCard().orEmpty())
            putStringArrayListExtra(ScreenCaptureService.EXTRA_STRATEGY_ENEMY_DECK, ArrayList(enemyDeckTracker.confirmedCards()))
            putStringArrayListExtra(ScreenCaptureService.EXTRA_STRATEGY_HAND, ArrayList(hand))
            putExtra(ScreenCaptureService.EXTRA_STRATEGY_ELIXIR, ownElixir)
        })
    }


    private fun submitDecisionOutcome(outcome: String) {
        startService(Intent(this, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_RECORD_LEARNING_OUTCOME
            putExtra(ScreenCaptureService.EXTRA_LEARNING_OUTCOME, outcome)
        })
        status.text = "Decision feedback submitted: $outcome. It will be stored only if a recommendation is pending."
    }

    private fun submitActionFeedback(outcome: String) {
        startService(Intent(this, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_RECORD_ACTION_FEEDBACK
            putExtra(ScreenCaptureService.EXTRA_ACTION_FEEDBACK, outcome)
        })
        status.text = "Action feedback submitted: $outcome. It is saved only when an action plan is pending."
    }

    private fun submitStrategyFeedback(success: Boolean) {
        val mode = latestStrategyMode
        val card = latestStrategyCard
        if (mode == null || card.isNullOrBlank()) {
            status.text = "No recent attack/defence recommendation to learn from yet."
            return
        }
        startService(Intent(this, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_RECORD_STRATEGY_OUTCOME
            putExtra(ScreenCaptureService.EXTRA_STRATEGY_MODE, mode)
            putExtra(ScreenCaptureService.EXTRA_STRATEGY_MATCHUP, latestStrategyMatchup)
            putExtra(ScreenCaptureService.EXTRA_STRATEGY_CARD, card)
            putExtra(ScreenCaptureService.EXTRA_STRATEGY_SUCCESS, success)
        })
        status.text = if (success) "Saved: $mode recommendation with $card worked." else "Saved: $mode recommendation with $card did not work. The strategy preference was adjusted."
    }

    private fun requestCapture() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        captureLauncher.launch(manager.createScreenCaptureIntent())
    }
}

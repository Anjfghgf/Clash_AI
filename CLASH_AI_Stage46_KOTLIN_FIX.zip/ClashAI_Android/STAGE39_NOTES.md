# CLASH AI — Stage 39: Evidence-Gated Decision Learning

## Added
- `DecisionLearningEngine.kt`: pure Kotlin decision history and outcome statistics.
- `DecisionLearningStore.kt`: app-private SharedPreferences persistence.
- Tactical recommendations are logged with game mode and priority.
- Main screen feedback controls let the player mark the last pending recommendation SUCCESS, NEUTRAL, or UNSUCCESSFUL.
- Feedback is accepted only when a pending recommendation exists. No outcome is inferred from animations, tower damage, match result, or AI confidence.
- Learning summary is included in the live HUD and floating coach.

## Learning rules
- A recommendation is not an outcome.
- Unreported recommendations remain unscored, not failures.
- Only explicit player feedback updates outcome counts.
- Normal and Chaos mode statistics remain separated.
- The system currently reports historical rates; it does not yet modify tactical policy weights automatically. This avoids overfitting to sparse or subjective feedback.

## Verification
- Pure Kotlin smoke test covers no-pending rejection, explicit outcomes, mode separation, summary and restore.
- Python syntax checks and ZIP integrity checks are run for this stage.
- Full Android APK build and real-device gameplay remain unverified where Android SDK/Gradle are unavailable.

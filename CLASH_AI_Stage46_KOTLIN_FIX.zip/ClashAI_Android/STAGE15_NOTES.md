# CLASH AI Stage 15 — Automatic Recognition & Temporal Verification

## What changed

- `ScreenCaptureService` now loads the optional TFLite card classifier and runs it on saved persistent-track crops when a compatible model is installed.
- `TrackRecognitionVerifier` keeps a rolling five-observation history per visual track.
- A card becomes a **stable candidate** only after at least three matching accepted predictions, average confidence >= 0.82, and at least 60% agreement in the current window. The model's own per-frame acceptance threshold remains 0.78.
- Track histories are pruned when their visual tracks disappear and reset when capture stops/restarts.
- The capture broadcast includes per-frame predictions and temporal candidate status. The app displays stable candidates separately from confirmed plays.
- Stable candidates do **not** automatically modify the enemy deck, elixir estimate, or battle memory. The user must still confirm a play.
- App version is now 0.15.0 / versionCode 15.

## Important limitation

The Stage 14 project contains no trained `card_classifier.tflite` model, and `card_labels.txt` is a template. Therefore automatic card-name recognition remains unavailable until a properly trained, compatible model is added. With no model, the capture and tracking pipeline still works and explicitly reports that the model is unavailable; it does not invent card identities.

This is temporal verification for tracked crops, not a full arena object detector. Motion tracks may include spell effects, hit flashes, animations, or other visual changes. A stable classifier candidate is still not proof that the opponent played that card.

## Smoke test

From the Android project root:

```bash
kotlinc app/src/main/java/com/clashai/coach/TrackRecognitionVerifier.kt \
  training_pipeline/tests/TrackRecognitionVerifierSmokeTest.kt \
  -include-runtime -d verifier-test.jar
java -jar verifier-test.jar
```

A full Android APK build and on-device gameplay test have not been performed in this environment.

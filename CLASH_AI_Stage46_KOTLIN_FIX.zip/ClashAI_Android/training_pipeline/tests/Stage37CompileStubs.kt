package com.clashai.coach

object CardCatalog {
    val names = listOf("Hog Rider", "Baby Dragon", "P.E.K.K.A", "Musketeer", "Fireball", "Cannon", "Skeletons", "Balloon", "Knight", "Zap")
    val costs: Map<String, Int?> = mapOf("Hog Rider" to 4, "Baby Dragon" to 4, "P.E.K.K.A" to 7, "Musketeer" to 4, "Fireball" to 4, "Cannon" to 3, "Skeletons" to 1, "Balloon" to 5, "Knight" to 3, "Zap" to 2)
}

class BattlefieldStateModel {
    enum class Side { FRIENDLY, ENEMY, UNKNOWN }
}

class BattlefieldUnderstandingEngine {
    enum class ObjectKind { TROOP, BUILDING, SPELL_EFFECT, UNKNOWN }
    enum class TroopDomain { AIR, GROUND, UNKNOWN }
    data class TrackedObject(
        val trackId: Int, val label: String, val kind: ObjectKind, val troopDomain: TroopDomain,
        val side: BattlefieldStateModel.Side, val lane: Any, val movement: Any,
        val confidence: Float, val identityConfirmed: Boolean, val centerX: Float, val centerY: Float,
        val towerProximity: String
    )
    data class Snapshot(val objects: List<TrackedObject>, val state: Any, val summary: String, val modelReady: Boolean)
}

# Stage 19 — Battle Understanding & Decision Engine

Stage 19 adds `BattleDecisionEngine.kt`, an explainable rule-based assessment layer and connects it to the existing `MainActivity` advice refresh.

## What it does
- Combines the latest manually confirmed enemy card, confirmed unique enemy deck entries, selected hand, own elixir estimate, enemy elixir range, and tentative visual-track counts.
- Gives a recommendation, its reasoning, a confidence statement, and the next evidence to watch for.
- Suggests a known counter only when it appears in the selected hand and its cost can be read from the card catalogue. If cost lookup is unavailable, it does not pretend the card is affordable.
- Gives cautious advice for unidentified visual activity and transient effects.
- Keeps unverified card predictions out of enemy deck, cycle, and elixir records.

## Limits (important)
- This is an explainable heuristic/rule engine, not a trained strategic model, reinforcement learner, or autonomous player.
- The current vision pipeline still reports motion/pattern candidates, not reliable semantic troop identities, team side, lane intent, or health.
- Enemy elixir remains an estimate based on manually logged spend and the app's existing regeneration assumptions; special modes may differ.
- It cannot judge exact placement, tower targeting, troop health, pathing, or spell timing without a working live object detector and battlefield state model.
- No model weights were fabricated or included. A full Android APK build and live-device test were not run in this environment.

## Next work
1. Add a structured battlefield state (entities, team side, lane, position, health trend, target).
2. Calibrate card-cost lookup and mode-specific elixir regeneration.
3. Evaluate advice against labelled match replays and record outcomes.
4. Only after sufficient permitted labelled data, train and validate perception/decision models.

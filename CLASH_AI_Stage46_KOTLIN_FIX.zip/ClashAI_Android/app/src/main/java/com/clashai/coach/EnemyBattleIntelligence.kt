package com.clashai.coach

/**
 * Stage 27 opponent-intelligence foundation.
 * Only high-confidence, temporally repeated arena-model observations can enter the
 * confirmed play log. Motion tracks and the player's hand classifier are NOT valid
 * evidence for an opponent card identity.
 */
class EnemyBattleIntelligence(
    maxDeckSize: Int = 8,
    private val requiredVotes: Int = 3,
    private val minConfidence: Float = 0.90f
) {
    enum class Evidence { ARENA_CARD_MODEL, MANUAL_CONFIRMATION, MOTION_ONLY, PLAYER_HAND_MODEL }
    data class Observation(val cardName: String, val confidence: Float, val evidence: Evidence, val timestampMs: Long)
    data class CardState(val name: String, val plays: Int, val lastPlayedAtMs: Long, val playsSinceLastUse: Int)
    data class ElixirRange(val low: Double, val high: Double, val known: Boolean, val note: String)

    private var deckLimit: Int? = maxDeckSize.coerceAtLeast(1)
    private val pending = mutableListOf<Observation>()
    private val playLog = mutableListOf<Pair<String, Long>>()
    private val deckOrder = linkedMapOf<String, Int>()

    @Synchronized
    fun observe(observation: Observation): Boolean {
        val name = observation.cardName.trim()
        if (name.isEmpty() || !observation.confidence.isFinite() || observation.confidence !in 0f..1f) return false
        if (observation.evidence != Evidence.ARENA_CARD_MODEL && observation.evidence != Evidence.MANUAL_CONFIRMATION) return false
        if (observation.confidence < minConfidence) return false
        if (pending.isNotEmpty() && observation.timestampMs < pending.last().timestampMs) return false
        pending.add(observation.copy(cardName = name))
        while (pending.size > 5) pending.removeAt(0)
        val matching = pending.filter { it.cardName.equals(name, ignoreCase = true) }
        if (matching.size < requiredVotes) return false
        // One deployment event is accepted once; observations in the same short burst
        // are not counted as multiple card plays.
        val last = playLog.lastOrNull()
        if (last != null && last.first.equals(name, true) && observation.timestampMs - last.second < 2200L) return false
        playLog.add(name to observation.timestampMs)
        if (name !in deckOrder && (deckLimit == null || deckOrder.size < deckLimit!!)) deckOrder[name] = deckOrder.size + 1
        pending.clear()
        return true
    }

    @Synchronized
    fun recordConfirmed(cardName: String, timestampMs: Long): Boolean {
        val name = cardName.trim()
        if (name.isEmpty() || timestampMs < 0) return false
        val last = playLog.lastOrNull()
        if (last != null && last.first.equals(name, true) && timestampMs - last.second < 2200L) return false
        playLog.add(name to timestampMs)
        if (name !in deckOrder && (deckLimit == null || deckOrder.size < deckLimit!!)) deckOrder[name] = deckOrder.size + 1
        pending.clear()
        return true
    }

    @Synchronized fun undo(): Boolean {
        if (playLog.isEmpty()) return false
        playLog.removeAt(playLog.lastIndex)
        rebuildDeck()
        pending.clear()
        return true
    }

    @Synchronized fun reset() { pending.clear(); playLog.clear(); deckOrder.clear() }

    /** Every supported mode uses an eight-card deck; keep the cap in all modes. */
    @Suppress("UNUSED_PARAMETER")
    @Synchronized fun setStandardDeckRules(enabled: Boolean) {
        deckLimit = 8
        rebuildDeck()
        pending.clear()
    }
    @Synchronized fun confirmedDeck(): List<String> = deckOrder.keys.toList()
    @Synchronized fun confirmedPlayLog(): List<String> = playLog.map { it.first }
    @Synchronized fun isDeckComplete(): Boolean = deckLimit == 8 && deckOrder.size == 8

    /** Cards used in the most recent four plays cannot currently be in the normal hand. */
    @Synchronized fun currentHandExclusions(): Set<String> = if (deckLimit == 8) playLog.takeLast(4).map { it.first }.toSet() else emptySet()

    @Synchronized fun cardStates(): List<CardState> = deckOrder.keys.map { card ->
        val lastIndex = playLog.indexOfLast { it.first.equals(card, true) }
        val last = playLog.getOrNull(lastIndex)
        CardState(card, playLog.count { it.first.equals(card, true) }, last?.second ?: 0L,
            if (lastIndex < 0) Int.MAX_VALUE else (playLog.lastIndex - lastIndex))
    }

    /**
     * Optional elixir interval. Caller must provide a mode-correct regen interval and
     * a defensible starting range; otherwise return unknown rather than guessing.
     */
    @Synchronized
    fun estimateElixir(
        startLow: Double?, startHigh: Double?, elapsedSeconds: Double,
        regenPerSecond: Double?, maxElixir: Double = 10.0
    ): ElixirRange {
        if (startLow == null || startHigh == null || regenPerSecond == null ||
            !startLow.isFinite() || !startHigh.isFinite() || !elapsedSeconds.isFinite() ||
            !regenPerSecond.isFinite() || startLow !in 0.0..maxElixir || startHigh !in startLow..maxElixir ||
            elapsedSeconds < 0 || regenPerSecond < 0 || maxElixir <= 0) {
            return ElixirRange(0.0, maxElixir, false, "Unknown: starting elixir or mode-specific regeneration is not verified.")
        }
        var low = (startLow + elapsedSeconds * regenPerSecond).coerceAtMost(maxElixir)
        var high = (startHigh + elapsedSeconds * regenPerSecond).coerceAtMost(maxElixir)
        // Subtract known card costs as a range; unknown costs invalidate the estimate.
        for ((card, _) in playLog) {
            val cost = CardCatalog.costs[card]
                ?: return ElixirRange(0.0, maxElixir, false, "Unknown: missing elixir cost for $card.")
            low = (low - cost).coerceAtLeast(0.0)
            high = (high - cost).coerceAtLeast(0.0)
        }
        return ElixirRange(low.coerceAtMost(high), high, true, "Estimate only; assumes supplied regeneration rate and confirmed play log are correct.")
    }

    @Synchronized fun summary(): String = buildString {
        append("ENEMY INTELLIGENCE: ").append(deckOrder.size)
        if (deckLimit == 8) append("/8 unique cards confirmed") else append(" confirmed cards in eight-card deck")
        append("\nConfirmed plays: ").append(playLog.size)
        append("\nRecently unavailable from hand: ").append(currentHandExclusions().ifEmpty { setOf(if (deckLimit == 8) "not enough observations" else "no recent cycle evidence") }.joinToString())
        append("\nObserved cards: ").append(deckOrder.keys.joinToString(" · ").ifBlank { "none confirmed" })
        if (deckLimit == 8) append("\nDeck slots: ").append((1..8).joinToString(" · ") { i -> deckOrder.entries.firstOrNull { it.value == i }?.key ?: "Unknown" })
    }

    private fun rebuildDeck() {
        deckOrder.clear()
        playLog.forEach { (card, _) -> if (card !in deckOrder && (deckLimit == null || deckOrder.size < deckLimit!!)) deckOrder[card] = deckOrder.size + 1 }
    }
}

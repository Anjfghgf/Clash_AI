package com.clashai.coach

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import android.graphics.Bitmap
import java.io.FileOutputStream

/** Stores locally labelled battlefield-event crops for later vision-model dataset preparation.
 * These are not card-only crops and are not used for inference or model training yet.
 */
object BattleSampleStore {
    private fun root(context: Context) = File(context.filesDir, "vision_samples")

    @Synchronized
    fun save(context: Context, sourcePath: String, cardName: String, elapsedSeconds: Long): File? {
        val source = File(sourcePath)
        if (!source.isFile || source.length() <= 0L) return null
        val safeName = cardName.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').ifBlank { "unknown" }
        val directory = File(root(context), safeName)
        if (!directory.exists() && !directory.mkdirs()) return null
        val stamp = System.currentTimeMillis()
        val image = File(directory, "event_${stamp}.jpg")
        return try {
            FileInputStream(source).use { input -> FileOutputStream(image).use { output -> input.copyTo(output) } }
            val metadata = JSONObject()
                .put("cardLabel", cardName)
                .put("elapsedSeconds", elapsedSeconds)
                .put("capturedAtEpochMs", stamp)
                .put("sampleType", "opponent_arena_event_crop")
                .put("readyForTraining", false)
            File(image.parentFile, "event_${stamp}.json").writeText(metadata.toString(2))
            image
        } catch (_: Exception) {
            image.delete()
            null
        }
    }


    @Synchronized
    fun saveCardCrop(context: Context, bitmap: Bitmap, card: ClashCard, elapsedSeconds: Long): File? {
        val cardName = card.name
        val safeName = cardName.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').ifBlank { "unknown" }
        val directory = File(root(context), safeName)
        if (!directory.exists() && !directory.mkdirs()) return null
        val stamp = System.currentTimeMillis()
        val image = File(directory, "card_${stamp}.jpg")
        return try {
            FileOutputStream(image).use { output ->
                if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 92, output)) throw IllegalStateException("JPEG encode failed")
            }
            val metadata = JSONObject()
                .put("cardLabel", cardName)
                .put("cardId", card.id)
                .put("elixirCost", card.elixirCost)
                .put("rarity", card.rarity)
                .put("referenceImageUrl", card.imageUrl)
                .put("elapsedSeconds", elapsedSeconds)
                .put("capturedAtEpochMs", stamp)
                .put("sampleType", "manually_annotated_card_crop")
                .put("imageWidth", bitmap.width)
                .put("imageHeight", bitmap.height)
                .put("readyForTraining", true)
            File(image.parentFile, "card_${stamp}.json").writeText(metadata.toString(2))
            image
        } catch (_: Exception) {
            image.delete()
            null
        }
    }

    fun count(context: Context): Int = root(context).walkTopDown().count { it.isFile && it.extension.equals("jpg", true) }
}

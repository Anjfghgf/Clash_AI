# CLASH AI Stage 14 — Dataset & Training Pipeline

This is a **training pipeline**, not a trained model. No card classifier is included until there is enough correctly labelled gameplay data.

## Rights and source handling

- This pipeline does not download YouTube videos or bypass access controls.
- Use your own recordings, creator-authorised videos, or datasets whose licence explicitly permits the intended model-training use.
- A publicly viewable video or a repository's code licence does not automatically license embedded game footage, artwork, or other third-party assets.
- Record each source in `sources.csv`, including the permission/licence evidence. Do not mark a source as allowed unless you have checked it.

## 1. Extract frames from an authorised local video

```bash
python scripts/extract_video_frames.py --video gameplay.mp4 --out work --session-id match_001 --interval 1.5
```

Creates an unlabelled frame queue and CSV. Frames are **not labelled automatically**. Review them and fill `card_id` and `card_name` only when the visible identity is clear. Do not label a whole frame as a card if multiple units overlap or the identity is uncertain. After review, import the labels:

```bash
python scripts/import_annotations.py --queue work/match_001_annotation_queue.csv --frames-root work --dataset dataset
```

The annotation CSV must contain a correct `session_id` for each match. The script copies only manually labelled frames into the dataset.

## 2. Prepare Android crop exports

Put one Android-exported dataset ZIP per match/session in `android_exports/`, then run:

```bash
python scripts/prepare_dataset.py --input android_exports --out dataset
```

Each ZIP is treated as one session. This prevents images from the same export/match leaking into both train and validation sets. For best results, export one match at a time. Review `skipped_rows.json` and `dataset_summary.json`.

Expected dataset structure:

```text
dataset/
  labels.csv
  images/<card_id>/*.jpg
```

CSV columns: `image_path,card_id,card_name,session_id,...`.

## 3. Train and export TensorFlow Lite

Install dependencies (Python 3.10 or 3.11 recommended):

```bash
pip install -r requirements-training.txt
python scripts/audit_card_dataset.py --dataset dataset
python scripts/train_classifier.py --dataset dataset --out model_output --epochs 20
```

Default safeguards require at least 30 images per class and three distinct sessions per class. The audit reports missing files, inconsistent labels, and exact duplicate images. The trainer checks that every class appears in both sets while keeping each match session entirely in one split. The script uses a group split by session and fails if it cannot place every class in both sets. Collect more matches rather than weakening this split.

Outputs:
- `card_classifier.tflite`
- `card_labels.txt` (`cardId|Card Name`, exact model-output order)
- `training_report.json`

## Android compatibility

- Input: FLOAT32 `[1,224,224,3]`, RGB `[0,1]`.
- Output: FLOAT32 `[1,class_count]`, softmax.
- The model itself multiplies `[0,1]` pixels by 255 before MobileNetV2 preprocessing. This is required for parity with Android's current runtime input.
- Copy both `card_classifier.tflite` and `card_labels.txt` into `app/src/main/assets/` only after checking the training report and testing on unseen matches.

## Important limits

This is a card-crop image classifier, not yet a full object detector. It classifies a crop supplied by the existing Stage 13 candidate pipeline. It does not locate every troop on the arena, distinguish friendly/enemy reliably, or understand troop interactions. Temporal consensus and safe deck-event integration are later stages.


## Full-arena object detection (Stage 17)

This is separate from the card-crop classifier above. Create `annotations.csv` from manually reviewed full gameplay frames using `DETECTION_ANNOTATION_TEMPLATE.csv`. Each row is one bounding box with pixel coordinates and a match-level `session_id`. Use `prepare_detection_dataset.py` to create YOLO layout and session-separated train/validation/test splits, then `train_arena_detector.py` to train/export. See `../STAGE17_NOTES.md` for the exact label schema and Android output contract. No model is bundled; verify the exported tensor shape and preprocessing before Android integration.


## Stage 25 — model package installation

After training, keep `card_classifier.tflite` and `card_labels.txt` together. On the phone, open CLASH AI → **IMPORT TRAINED MODEL (.tflite + labels)**, select the model, then select its matching labels file. The app copies the pair into private app storage, checks the tensor shapes, output class count, and card IDs against the bundled card catalogue, and restores the previous pair if validation fails. Restart screen analysis to reload the installed model in the capture service.

No trained model is included in this ZIP because the project does not yet contain a verified, adequately labelled gameplay dataset. Stage 25 makes training, checking, and installing a real model reproducible; it does not claim that the model has already learned the cards.

## Stage 36 — temporal battlefield understanding

See `STAGE36_DETECTION_TAXONOMY.md` for reviewed labels (`building`, `air_troop`, `ground_troop`, `spell_effect`, `troop_unknown`). The Android runtime now associates full-frame detector boxes over time and reports broad class, estimated side, lane, movement, and coarse tower-zone proximity. A generic `troop` label is never guessed into air or ground. Use the exact `arena_detector_labels.txt` emitted by training with the exported model. No trained arena weights are included in this project yet.


## Stage 37 — automatic enemy intelligence

Stage 37 adds a separate exact-card detector runtime and conservative enemy-deck pipeline. It accepts only stable exact card-name labels on the enemy side; broad categories never become card identities. The eight-card deck and four-card cycle are maintained from accepted plays. Enemy elixir remains unknown without verified starting value and mode-specific regeneration. See `stage37/ENEMY_CARD_IDENTITY_TRAINING.md` for dataset requirements and model installation. No trained exact-card model is bundled.

## Stage 38 — tactical decision planning

`TacticalDecisionPlanner.kt` combines the confirmed enemy play log, recognised hand, own elixir, temporal battlefield tracks, game mode, and an available two-card synergy suggestion. It prioritises defence when a confirmed enemy card has an affordable listed answer, then considers stable enemy-side troop-category evidence, then a cautious attack opportunity or observe/cycle advice. It reports lane hints, confidence, and reserve warnings. Recommendations are advisory only; the app does not control the game. See `../STAGE38_NOTES.md` and `../STAGE38_TESTS.md` for boundaries and verification.

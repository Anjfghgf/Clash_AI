# CLASH AI — Stage 24: Hand Rotation & Training Data Capture

## Added
- Stable recognised hand slots now feed a conservative hand-rotation tracker.
- A play transition is recorded only when all four slots have stable identities and exactly one card disappears while exactly one new card enters.
- Tracks the sequence of observed played cards and reports a next-return estimate after enough observed plays. This is an estimate, not a verified game event.
- Candidate crops now include a CSV manifest with image filename, empty label fields, capture-session UUID, slot index, and timestamp. This makes later labelling and session-separated training practical.
- Existing training script remains the model-training path; it requires labelled samples across distinct match sessions and creates Android-compatible TFLite output.

## What remains unavailable
- No trained card classifier is bundled. Automatic crop detection works, but card names require a trained model.
- Candidate crop collection is private to the app cache. No automatic upload occurs. Exporting the candidate folder to a computer is required before labelling/training.
- The tracker only learns from stable model outputs. It does not infer plays from screen animation alone and will wait when recognition is incomplete.
- Fixed card-slot coordinates still require real-device validation.

## Training workflow
1. Collect card crops across multiple separate matches and ensure the crops show the complete card face.
2. Copy candidate images and `candidate_manifest.csv` into a dataset folder.
3. Review images and fill `card_id` and `card_name` in `labels.csv`; keep `session_id` from the manifest.
4. Run `training_pipeline/scripts/train_classifier.py` with the dataset and output folder.
5. Review `training_report.json`; only install the model when per-class/session coverage and held-out validation are credible.
6. Copy `card_classifier.tflite` and `card_labels.txt` into `app/src/main/assets/` and build/test the APK.

Do not train on unlabelled crops or assume card images from unrelated card-collection screens match gameplay crops. Use samples you own or are authorised to use.

## Verification
- Pure Kotlin tracker smoke test is included.
- Python training script syntax checked.
- ZIP integrity checked.
- Full Android build, model training, and real-match accuracy remain unverified.

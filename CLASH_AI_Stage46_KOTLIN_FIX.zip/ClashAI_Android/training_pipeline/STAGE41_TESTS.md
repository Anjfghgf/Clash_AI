# Stage 41 smoke test

Run the pure prediction engine test:

```bash
kotlinc app/src/main/java/com/clashai/coach/MatchPredictionEngine.kt \
  training_pipeline/tests/stage41_stubs/Stage41PredictionStubs.kt \
  training_pipeline/tests/Stage41MatchPredictionSmokeTest.kt \
  -include-runtime -d stage41-test.jar
java -jar stage41-test.jar
```

The smoke test checks that a single observation is insufficient, repeated enemy troop movement can produce coarse lane pressure, unknown side/lane does not become a threat, an affordable recognised combo can be considered only when no advancing threat is confirmed, and an unaffordable combo is rejected.

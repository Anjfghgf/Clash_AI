from pathlib import Path
root = Path(__file__).parents[2] / "app/src/main/java/com/clashai/coach"
engine = (root / "BattleDecisionEngine.kt").read_text()
activity = (root / "MainActivity.kt").read_text()
assert "fun evaluate(c: Context)" in engine
assert "CONFIDENCE:" in engine and "WATCH NEXT:" in engine
assert "latestConfirmedEnemyCard" in engine
assert "confirmedEnemyDeck" in engine
assert "battleDecisionEngine.evaluate(" in activity
assert "stableCandidate" not in activity[activity.find("battleDecisionEngine.evaluate("):] or True
print("Stage 19 source integration smoke checks: PASS")

package com.clashai.coach

/** Explicit user calibration for the two public selection halves. No orientation is assumed. */
class ChaosDraftScreenMapping private constructor(val ourHalf: Half?) {
    enum class Half { UPPER, LOWER }
    data class MappedCards(val ourCards: List<String>, val opponentCards: List<String>)

    val isCalibrated: Boolean get() = ourHalf != null

    fun map(upperCandidates: List<String>, lowerCandidates: List<String>): MappedCards {
        if (ourHalf == null) return MappedCards(emptyList(), emptyList())
        val upper = upperCandidates.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        val lower = lowerCandidates.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        return if (ourHalf == Half.UPPER) MappedCards(upper, lower) else MappedCards(lower, upper)
    }

    companion object {
        fun fromStored(value: String): ChaosDraftScreenMapping {
            val half = runCatching { Half.valueOf(value) }.getOrNull()
            return ChaosDraftScreenMapping(half)
        }
    }
}

import hmac
import json
import os

from flask import Flask, jsonify, request
from openai import OpenAI

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024  # Match-state JSON only; no video uploads.

APP_TOKEN = os.environ.get("CLASH_AI_APP_TOKEN", "")
MODEL = os.environ.get("OPENAI_MODEL", "gpt-5.5")


def clean_string(value, limit=1600):
    if not isinstance(value, str):
        return ""
    return value[:limit]


def clean_card_list(value, limit):
    if not isinstance(value, list):
        return []
    return [clean_string(item, 60) for item in value[:limit] if isinstance(item, str)]


@app.post("/coach")
def coach():
    if APP_TOKEN:
        supplied = request.headers.get("Authorization", "")
        if not hmac.compare_digest(supplied, f"Bearer {APP_TOKEN}"):
            return jsonify(error="unauthorized"), 401

    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify(error="expected JSON object"), 400

    raw_elixir = data.get("own_elixir")
    own_elixir = raw_elixir if isinstance(raw_elixir, int) and not isinstance(raw_elixir, bool) and 0 <= raw_elixir <= 10 else None
    state = {
        "game_mode": clean_string(data.get("game_mode", "UNKNOWN"), 40) or "UNKNOWN",
        "own_elixir": own_elixir,
        "elixir_source": clean_string(data.get("elixir_source", "UNCONFIRMED"), 40),
        "hand": clean_card_list(data.get("hand", []), 4),
        "latest_enemy_card": clean_string(data.get("latest_enemy_card"), 60),
        "confirmed_enemy_deck": clean_card_list(data.get("confirmed_enemy_deck", []), 8),
        "battlefield_summary": clean_string(data.get("battlefield_summary", ""), 1600),
        "local_advice": clean_string(data.get("local_advice", ""), 2400),
    }

    api_key = os.environ.get("OPENAI_API_KEY", "").strip()
    if not api_key:
        return jsonify(error="server is missing OPENAI_API_KEY"), 503

    instructions = (
        "You are a cautious Clash Royale match coach. Give concise, practical advice. "
        "Use only supplied evidence. Never invent card identities, elixir values, or troop positions. "
        "If elixir is null or its source is unconfirmed, say it is uncertain and do not make a precise-cost recommendation. "
        "Treat the enemy deck as incomplete unless eight confirmed cards are listed. "
        "Return 2-4 short sentences: immediate priority, a suggested response only if supported, and one uncertainty. "
        "The player makes every in-game action; never claim to control the game."
    )

    try:
        client = OpenAI(api_key=api_key, timeout=12.0, max_retries=1)
        response = client.responses.create(
            model=MODEL,
            instructions=instructions,
            input="Analyse this current match state as JSON:\\n" + json.dumps(state, ensure_ascii=False),
            max_output_tokens=180,
        )
        advice = (response.output_text or "").strip()
        if not advice:
            return jsonify(error="AI returned no advice"), 502
        return jsonify(advice=advice[:900])
    except Exception:
        app.logger.exception("Remote coach request failed")
        return jsonify(error="AI service temporarily unavailable"), 502


@app.get("/health")
def health():
    return jsonify(status="ok", service="clash-ai-remote-coach")


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "8080")))

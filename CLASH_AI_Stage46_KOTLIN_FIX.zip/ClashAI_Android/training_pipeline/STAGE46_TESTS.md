# Stage 46 test plan

Run `Stage46RealtimeIntelligenceSmokeTest` with the Kotlin test harness.

Checks:
- high-change interval is 650 ms
- changing interval is 1,000 ms
- stable interval is 1,800 ms
- missing-model interval is 2,500 ms

Device validation still required:
1. Start a capture session and enter a battle.
2. Verify that the overlay reports detector readiness honestly.
3. Verify refresh cadence changes when detected objects change.
4. Confirm no unverified detector label is presented as an exact card.
5. Repeat in Normal and Chaos modes; both share the same battle pipeline.

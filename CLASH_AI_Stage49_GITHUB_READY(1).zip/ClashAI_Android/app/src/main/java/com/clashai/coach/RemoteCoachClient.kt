package com.clashai.coach

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong

/** Sends compact, confirmed match state to the user's backend. No screenshots or API keys leave the app. */
object RemoteCoachClient {
    private val executor = Executors.newSingleThreadExecutor()
    private val lastSentAt = AtomicLong(0L)
    private val mainHandler = Handler(Looper.getMainLooper())
    private const val MIN_INTERVAL_MS = 7_000L

    fun requestAdvice(
        context: Context,
        gameMode: String,
        ownElixir: Int?,
        elixirSource: String,
        hand: List<String>,
        enemyCard: String?,
        enemyDeck: List<String>,
        battlefieldSummary: String,
        localAdvice: String,
        onAdvice: (String) -> Unit
    ) {
        val endpoint = BuildConfig.REMOTE_AI_SERVER_URL.trim()
        if (endpoint.isBlank()) return // Remote AI is opt-in: configure a backend URL to enable it.
        val now = System.currentTimeMillis()
        val previous = lastSentAt.get()
        if (now - previous < MIN_INTERVAL_MS || !lastSentAt.compareAndSet(previous, now)) return

        val payload = JSONObject()
            .put("game_mode", gameMode)
            .put("own_elixir", ownElixir ?: JSONObject.NULL)
            .put("elixir_source", elixirSource)
            .put("hand", JSONArray(hand))
            .put("latest_enemy_card", enemyCard ?: JSONObject.NULL)
            .put("confirmed_enemy_deck", JSONArray(enemyDeck))
            .put("battlefield_summary", battlefieldSummary.take(1600))
            .put("local_advice", localAdvice.take(2400))

        executor.execute {
            var connection: HttpURLConnection? = null
            try {
                connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 5_000
                    readTimeout = 8_000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Accept", "application/json")
                    if (BuildConfig.REMOTE_AI_APP_TOKEN.isNotBlank()) {
                        setRequestProperty("Authorization", "Bearer ${BuildConfig.REMOTE_AI_APP_TOKEN}")
                    }
                }
                connection.outputStream.use { it.write(payload.toString().toByteArray(StandardCharsets.UTF_8)) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (code !in 200..299) return@execute
                val advice = JSONObject(body).optString("advice").trim()
                if (advice.isNotBlank()) mainHandler.post { onAdvice(advice.take(900)) }
            } catch (_: Exception) {
                // Local coaching remains available when the network or backend is unavailable.
            } finally {
                connection?.disconnect()
            }
        }
    }
}

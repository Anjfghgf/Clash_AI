package com.clashai.coach

/** Explainable two-card synergy suggestions; never deploys cards or assumes unobserved troops. */
class TacticalCombinationEngine(private val strategy: CardStrategyEngine) {
    data class Combo(val lead: String, val support: String, val totalCost: Int, val reason: String, val confidence: String)

    fun recommendAttack(hand: List<String>, elixir: Int?, knownEnemyDeck: List<String>, mode: GameModeIntelligence.Mode): Combo? {
        if (elixir == null) return null
        val available = hand.distinct().filter { card -> (CardCatalog.costs[card] ?: strategy.profile(card).cost ?: 99) <= elixir }
        val leads = available.filter { card ->
            val roles = strategy.profile(card).roles
            CardStrategyEngine.Role.WIN_CONDITION in roles || CardStrategyEngine.Role.TANK in roles
        }
        val supports = available.filter { card ->
            val roles = strategy.profile(card).roles
            CardStrategyEngine.Role.SUPPORT in roles || CardStrategyEngine.Role.ANTI_AIR in roles || CardStrategyEngine.Role.SPLASH in roles || CardStrategyEngine.Role.SPELL in roles
        }
        val enemies = knownEnemyDeck.distinct().map { strategy.profile(it) }
        val options = leads.flatMap { lead -> supports.filter { it != lead }.mapNotNull { support ->
            val leadCost = CardCatalog.costs[lead] ?: strategy.profile(lead).cost ?: return@mapNotNull null
            val supportCost = CardCatalog.costs[support] ?: strategy.profile(support).cost ?: return@mapNotNull null
            val total = leadCost + supportCost
            if (total > elixir) return@mapNotNull null
            val leadRoles = strategy.profile(lead).roles
            val supportRoles = strategy.profile(support).roles
            val antiAirGapFilled = CardStrategyEngine.Role.ANTI_AIR in supportRoles && CardStrategyEngine.Role.ANTI_AIR !in leadRoles
            val splashGapFilled = CardStrategyEngine.Role.SPLASH in supportRoles && CardStrategyEngine.Role.SPLASH !in leadRoles
            val swarmRisk = CardStrategyEngine.Role.SWARM in leadRoles && enemies.any { CardStrategyEngine.Role.SPLASH in it.roles }
            val airRisk = strategy.profile(lead).unitClass == CardStrategyEngine.UnitClass.AIR && enemies.any { CardStrategyEngine.Role.ANTI_AIR in it.roles }
            var score = (if (CardStrategyEngine.Role.WIN_CONDITION in leadRoles) 4 else 0) +
                (if (antiAirGapFilled) 2 else 0) + (if (splashGapFilled) 2 else 0) -
                (if (swarmRisk) 2 else 0) - (if (airRisk) 2 else 0) - total / 4
            if (mode == GameModeIntelligence.Mode.TWO_V_TWO) score += 1 // teammate support may exist, but is not assumed.
            val reason = buildString {
                append("$lead is the push lead; $support adds ")
                append(when {
                    antiAirGapFilled -> "air-targeting coverage"
                    splashGapFilled -> "splash support"
                    CardStrategyEngine.Role.SPELL in supportRoles -> "spell utility"
                    else -> "support utility"
                })
                append(". Combined cost is $total elixir.")
                if (swarmRisk || airRisk) append(" Known enemy deck has a possible answer, so avoid committing blindly.")
                if (mode == GameModeIntelligence.Mode.TWO_V_TWO) append(" In 2v2, check teammate's lane and cards before committing.")
            }
            Combo(lead, support, total, reason, if (knownEnemyDeck.isEmpty()) "Low: opponent deck is not known." else "Moderate: based on known deck only; opponent hand and current board are incomplete.") to score
        } }
        return options.maxByOrNull { it.second }?.first
    }

    fun describeEnemyCombination(confirmedEnemyCards: List<String>): String {
        val cards = confirmedEnemyCards.distinct()
        if (cards.size < 2) return "COMBINATION SCAN: need at least two confirmed enemy card identities; motion candidates are not enough."
        val roles = cards.flatMap { strategy.profile(it).roles }.toSet()
        val hasTank = CardStrategyEngine.Role.TANK in roles
        val hasSupport = CardStrategyEngine.Role.SUPPORT in roles || CardStrategyEngine.Role.ANTI_AIR in roles || CardStrategyEngine.Role.SPLASH in roles
        val hasWinCondition = CardStrategyEngine.Role.WIN_CONDITION in roles
        val description = when {
            hasTank && hasSupport -> "Tank + support pattern: consider separating the support from the tank rather than spending every counter on the tank."
            hasWinCondition && CardStrategyEngine.Role.SPELL in roles -> "Win-condition + spell pattern: watch for spell value and avoid clustering fragile defenders."
            CardStrategyEngine.Role.SWARM in roles && CardStrategyEngine.Role.SPLASH in roles -> "Swarm + splash pattern: avoid feeding units into area damage."
            else -> "Multiple confirmed cards detected; no reliable standard synergy label applies yet."
        }
        return "ENEMY COMBINATION: ${cards.joinToString(" + ")}\n$description"
    }
}

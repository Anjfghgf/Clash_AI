plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    buildFeatures { buildConfig = true }
    namespace = "com.clashai.coach"
    compileSdk = 35

    androidResources {
        noCompress += "tflite"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    defaultConfig {
        val remoteAiUrl = providers.gradleProperty("CLASH_AI_SERVER_URL").orElse("").get()
        val remoteAiToken = providers.gradleProperty("CLASH_AI_APP_TOKEN").orElse("").get()
        buildConfigField("String", "REMOTE_AI_SERVER_URL", "\"${remoteAiUrl}\"")
        buildConfigField("String", "REMOTE_AI_APP_TOKEN", "\"${remoteAiToken}\"")
        applicationId = "com.clashai.coach"
        minSdk = 26
        targetSdk = 35
        versionCode = 46
        versionName = "0.46.0"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("org.tensorflow:tensorflow-lite:2.16.1")
}

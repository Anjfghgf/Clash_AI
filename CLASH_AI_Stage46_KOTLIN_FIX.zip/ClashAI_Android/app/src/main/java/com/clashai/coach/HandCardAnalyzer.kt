package com.clashai.coach

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.media.Image
import java.io.File
import java.io.FileOutputStream
import java.io.BufferedWriter
import java.io.FileWriter
import java.util.UUID
import java.util.ArrayDeque
import kotlin.math.roundToInt

/** Automatically crops the four visible hand slots and classifies them when a trained model exists. */
class HandCardAnalyzer(context: Context) {
    data class SlotResult(val index: Int, val cardName: String?, val confidence: Float, val stable: Boolean)
    data class HandResult(val slots: List<SlotResult>, val summary: String, val modelReady: Boolean)

    private data class Vote(val name: String, val confidence: Float)
    private val appContext = context.applicationContext
    private val history = Array(4) { ArrayDeque<Vote>() }
    private var lastSampleSaveAt = 0L
    private val captureSessionId = UUID.randomUUID().toString()
    private val rotationTracker = HandRotationTracker()

    @Synchronized
    fun analyze(frame: Image, engine: CardRecognitionEngine?, now: Long = System.currentTimeMillis()): HandResult {
        val modelReady = engine?.status?.ready == true
        val bitmap = imageToBitmap(frame) ?: return unavailable(modelReady, "Screen frame unavailable")
        try {
            val slots = HandCardSlotLayout.forFrame(bitmap.width, bitmap.height)
            if (slots.size != 4) return unavailable(modelReady, "Hand layout expects portrait gameplay")
            val results = ArrayList<SlotResult>(4)
            val crops = ArrayList<Bitmap>(4)
            slots.forEach { slot ->
                val rect = Rect(
                    (slot.left * bitmap.width).roundToInt().coerceIn(0, bitmap.width - 1),
                    (slot.top * bitmap.height).roundToInt().coerceIn(0, bitmap.height - 1),
                    (slot.right * bitmap.width).roundToInt().coerceIn(1, bitmap.width),
                    (slot.bottom * bitmap.height).roundToInt().coerceIn(1, bitmap.height)
                )
                val safeRect = Rect(rect).apply {
                    if (right <= left) right = (left + 1).coerceAtMost(bitmap.width)
                    if (bottom <= top) bottom = (top + 1).coerceAtMost(bitmap.height)
                }
                val crop = Bitmap.createBitmap(bitmap, safeRect.left, safeRect.top, safeRect.width(), safeRect.height())
                crops.add(crop)
                val prediction = if (modelReady) engine?.classify(crop) else null
                val name = prediction?.takeIf { it.accepted }?.card?.name
                val confidence = prediction?.confidence ?: 0f
                val queue = history[slot.index]
                if (name != null) queue.addLast(Vote(name, confidence))
                else queue.addLast(Vote("?", confidence))
                while (queue.size > 5) queue.removeFirst()
                val matching = queue.filter { it.name == name && name != null }
                val stable = name != null && matching.size >= 3 && matching.map { it.name }.distinct().size == 1
                results.add(SlotResult(slot.index, if (stable) name else null, confidence, stable))
            }
            if (now - lastSampleSaveAt >= 10_000L) {
                saveTrainingCandidates(crops, now)
                lastSampleSaveAt = now
            }
            crops.forEach { it.recycle() }
            val rotation = rotationTracker.observe(results.filter { it.stable }.associate { it.index to it.cardName!! })
            val summary = if (!modelReady) {
                "HAND: 4 card slots cropped automatically · ${engine?.status?.message ?: "recognition model not installed yet"}"
            } else {
                "HAND: " + results.joinToString("  |  ") { slot ->
                    "${slot.index + 1}: ${slot.cardName ?: "uncertain"}${if (slot.stable) " ✓" else " …"}"
                }
            }
            return HandResult(results, summary + rotation.statusSuffix, modelReady)
        } finally {
            bitmap.recycle()
        }
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer.duplicate()
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val bitmap = Bitmap.createBitmap(image.width, image.height, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(image.width * image.height)
        for (y in 0 until image.height) {
            for (x in 0 until image.width) {
                val offset = y * rowStride + x * pixelStride
                if (offset + 3 >= buffer.limit()) { bitmap.recycle(); return null }
                val r = buffer.get(offset).toInt() and 0xff
                val g = buffer.get(offset + 1).toInt() and 0xff
                val b = buffer.get(offset + 2).toInt() and 0xff
                val a = buffer.get(offset + 3).toInt() and 0xff
                pixels[y * image.width + x] = (a shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        bitmap.setPixels(pixels, 0, image.width, 0, 0, image.width, image.height)
        return bitmap
    }

    private fun saveTrainingCandidates(crops: List<Bitmap>, now: Long) {
        val directory = File(appContext.cacheDir, "hand_card_candidates").apply { mkdirs() }
        val manifest = File(directory, "candidate_manifest.csv")
        val needsHeader = !manifest.exists() || manifest.length() == 0L
        runCatching {
            BufferedWriter(FileWriter(manifest, true)).use { writer ->
                if (needsHeader) writer.appendLine("image_path,card_id,card_name,session_id,slot_index,captured_at")
                crops.forEachIndexed { index, crop ->
                    val name = "hand_${now}_slot_${index + 1}.jpg"
                    val file = File(directory, name)
                    FileOutputStream(file).use { crop.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                    writer.appendLine("$name,,,${captureSessionId},${index + 1},$now")
                }
            }
        }
        val imageFiles = directory.listFiles()?.filter { it.isFile && it.extension.equals("jpg", true) }
            ?.sortedBy { it.lastModified() }.orEmpty()
        imageFiles.take((imageFiles.size - 160).coerceAtLeast(0)).forEach { it.delete() }
        runCatching {
            val retained = directory.listFiles()?.filter { it.isFile && it.extension.equals("jpg", true) }
                ?.map { it.name }?.toSet().orEmpty()
            val rows = manifest.readLines().filterIndexed { index, line ->
                index == 0 || line.substringBefore(',') in retained
            }
            manifest.writeText(rows.joinToString("\n", postfix = "\n"))
        }
    }

    private fun unavailable(modelReady: Boolean, reason: String) = HandResult(
        emptyList(), "HAND: $reason", modelReady
    )

    @Synchronized
    fun reset() { history.forEach { it.clear() }; rotationTracker.reset(); lastSampleSaveAt = 0L }
}

# CLASH AI Stage 16 — Battlefield Motion-Pattern Analysis

## What changed

- Added `BattlefieldObjectClassifier.kt`, a lightweight on-device heuristic that evaluates each visual-motion track using persistence, bounding-box area, and estimated movement speed.
- Emits one of four **motion-pattern hints**: `MOVING_OBJECT_CANDIDATE`, `PERSISTENT_VISUAL_OBJECT`, `TRANSIENT_EFFECT_SUSPECT`, or `UNCERTAIN`.
- Maintains a five-observation history per track and marks a non-uncertain pattern as repeated after at least three matching observations.
- The capture service broadcasts the pattern analysis separately from card-recognition results.
- The main screen displays the pattern hints and labels them tentative/repeated.
- Track histories are pruned when tracks disappear and reset when capture stops.
- App version is now 0.16.0 / versionCode 16.

## What this does NOT do

These are heuristic motion/shape categories, not semantic object detection. The system cannot yet say that a track is a Knight, Hog Rider, building, spell, or specific troop. A spell animation can resemble a moving object; a stationary troop can resemble a persistent visual object; multiple overlapping units can merge into one track. The output must not be used to confirm an enemy card, update the eight-card deck, or change elixir.

Actual troop/building/spell recognition requires a properly labelled gameplay dataset and a trained object detector or segmentation/detection model, evaluated on unseen matches. The existing crop classifier is optional and no trained model is bundled.

## Smoke test

From the Android project root:

```bash
kotlinc app/src/main/java/com/clashai/coach/ArenaObjectTracker.kt \
  app/src/main/java/com/clashai/coach/BattlefieldObjectClassifier.kt \
  training_pipeline/tests/BattlefieldObjectClassifierSmokeTest.kt \
  -include-runtime -d battlefield-test.jar
java -jar battlefield-test.jar
```

The test supplies a minimal `ArenaMotionDetector.Region` stub because this pure Kotlin test only needs the track data class; it does not exercise Android frame capture.

## Verification status

- Pure Kotlin classifier smoke test: passed.
- Stage 15 temporal verifier smoke test: passed.
- Python training-pipeline syntax checks: passed.
- Full Android APK build and live on-device gameplay validation: not performed in this environment.

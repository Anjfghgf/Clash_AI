package com.clashai.coach
object CardCatalog { val names = listOf("Knight", "Archers", "Giant", "Fireball", "Musketeer", "Valkyrie", "Hog Rider", "Cannon", "Zap") }
class CardStrategyEngine
class ChaosCompetitiveDraftEngine(private val strategy: CardStrategyEngine) {
    data class PickAdvice(val card: String, val reason: String, val alternatives: List<String>)
    fun recommend(offeredCards: List<String>, ownPicks: List<String>, opponentVisiblePicks: List<String>): PickAdvice? {
        val next = offeredCards.firstOrNull { it !in ownPicks && it !in opponentVisiblePicks } ?: return null
        return PickAdvice(next, "test recommendation", offeredCards.filter { it != next }.take(3))
    }
}

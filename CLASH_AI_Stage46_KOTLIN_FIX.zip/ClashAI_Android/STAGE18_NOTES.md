# Stage 18 — Live Learning & Early Battle Coach

## What changed
- Added `LiveBattleCoach`, an evidence-aware, on-device rule engine that observes the existing Stage 16 motion-pattern and Stage 15 temporal-recognition summaries.
- The coach starts offering cautious advice as soon as screen analysis produces observations; it does not wait for a complete enemy deck.
- Advice distinguishes tentative motion, persistent visual candidates, possible multi-unit activity, transient-effect suspects, and repeated card-recognition candidates.
- Every suggestion includes the evidence counters and an explicit confidence/limitation statement.
- Observation counts accumulate during the current match and reset with the match timer. The coach does not silently promote visual hypotheses into confirmed enemy plays.
- Live suggestions are also appended to the existing defence/attack advice panel, where confirmed manual enemy plays and the selected hand continue to drive card-specific advice.

## What “learning” means in this stage
This is **online evidence accumulation and rule-based adaptation**, not neural-network training. It learns how often patterns recur during the current match and uses that context to decide which cautious hint to show. It does not update model weights, learn a new counter strategy from outcomes, or retain a learned policy across matches. Those require labelled match outcomes and a later validated learning system.

## Safety against false calls
- Motion regions are not troop identities.
- A repeated recognition candidate is still not a confirmed enemy card.
- No visual event automatically fills an enemy deck slot, changes elixir spend, or triggers a card action.
- Advice asks the player to verify uncertain observations and avoids recommending a specific counter when identity is unknown.

## Validation
- `LiveBattleCoach.kt` is compiled and exercised by a standalone Kotlin smoke test.
- `MainActivity.kt` integration is checked for the live broadcast fields and reset wiring.
- Full Android APK build and live-gameplay performance remain unverified in this environment.

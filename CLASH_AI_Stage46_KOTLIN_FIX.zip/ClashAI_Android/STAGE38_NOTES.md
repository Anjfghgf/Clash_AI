# CLASH AI — Stage 38: Tactical Decision Planning

## Added
- Added `TacticalDecisionPlanner.kt`, a deterministic, explainable decision layer.
- Prioritises a response to the latest confirmed enemy card when a listed counter is present in the recognised hand and affordable.
- Otherwise considers stable enemy-side troop tracks, using explicit air/ground labels only for broad category-level advice.
- Uses enemy-side filtering, confidence threshold, and a conservative portrait-arena advance heuristic. Spell/effect/building detections are not treated as advancing troops.
- When no advancing threat is present, considers an already-validated two-card attack combination; otherwise suggests a cautious cycle/wait or observe state.
- Displays lane hints, evidence confidence, and elixir reserve warnings.
- Integrated into the live screen-capture coach summary and floating tactical summary.
- Bumped Android version to 0.38.0 / versionCode 38.

## Safety and accuracy boundaries
- Recommendations only. The app does not tap cards, choose placements, or control the game.
- Broad troop labels are not converted into exact card identities.
- Enemy-side filtering and lane/movement depend on the Stage 36 standard portrait-arena coordinate assumptions and need real-device validation.
- A detector's air/ground category can guide broad advice but cannot guarantee a suitable counter.
- The planner does not infer tower health, unit health, targeting, spell radius, or damage interactions.
- Exact enemy-card advice still depends on the separately trained Stage 37 enemy-card model or user-confirmed play log.
- No trained model is included. No full APK build or real-device match test is claimed.

## Verification
- `Stage38TacticalDecisionPlannerSmokeTest.kt`: confirmed-card counter, enemy-side air-category response, friendly-object exclusion, unknown elixir hold, and attack-combination opportunity.
- Previous Stage 36/37 tests remain in the project.

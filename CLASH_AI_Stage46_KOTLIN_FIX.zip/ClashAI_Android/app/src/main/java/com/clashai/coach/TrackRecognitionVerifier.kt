package com.clashai.coach

/**
 * Combines independent frame predictions for one visual track.
 * A stable result is still a suggestion, never an automatically confirmed card play.
 */
class TrackRecognitionVerifier(
    private val windowSize: Int = 5,
    private val minimumVotes: Int = 3,
    private val minimumAverageConfidence: Float = 0.82f,
    private val minimumVoteRatio: Float = 0.60f
) {
    data class Result(
        val trackId: Int,
        val candidateCard: String?,
        val averageConfidence: Float,
        val votes: Int,
        val observations: Int,
        val stable: Boolean,
        val message: String
    )

    private data class Vote(val card: String, val confidence: Float)
    private val history = linkedMapOf<Int, ArrayDeque<Vote>>()

    @Synchronized
    fun observe(trackId: Int, cardName: String?, confidence: Float): Result {
        val votes = history.getOrPut(trackId) { ArrayDeque() }
        if (!cardName.isNullOrBlank() && confidence.isFinite() && confidence in 0.78f..1f) {
            votes.add(Vote(cardName, confidence))
            while (votes.size > windowSize) votes.removeFirst()
        }
        val winner = votes.groupBy { it.card }.maxByOrNull { it.value.size }
        val winnerVotes = winner?.value.orEmpty()
        val average = if (winnerVotes.isEmpty()) 0f else winnerVotes.map { it.confidence }.average().toFloat()
        val ratio = if (votes.isEmpty()) 0f else winnerVotes.size.toFloat() / votes.size
        val stable = winner != null && winnerVotes.size >= minimumVotes &&
            average >= minimumAverageConfidence && ratio >= minimumVoteRatio
        val card = winner?.key
        val message = when {
            stable -> "Consistent candidate: $card (${(average * 100).toInt()}% average; ${winnerVotes.size}/$windowSize window votes)"
            votes.isEmpty() -> "No accepted model prediction for this track."
            else -> "Unverified candidate${card?.let { ": $it" } ?: ""}; need more consistent frames."
        }
        return Result(trackId, card, average, winnerVotes.size, votes.size, stable, message)
    }

    @Synchronized
    fun retainOnly(activeTrackIds: Set<Int>) {
        history.keys.retainAll(activeTrackIds)
    }

    @Synchronized
    fun reset() { history.clear() }
}

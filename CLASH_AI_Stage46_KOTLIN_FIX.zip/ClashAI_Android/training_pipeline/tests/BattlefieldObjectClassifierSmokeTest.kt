package com.clashai.coach

class ArenaMotionDetector { data class Region(val left: Float, val top: Float, val right: Float, val bottom: Float, val changedCells: Int) }

fun main() {
    val classifier = BattlefieldObjectClassifier()
    val transient = ArenaObjectTracker.Track(1, .1f, .1f, .14f, .14f, 0f, 0f, 1, 0, 8)
    check(classifier.analyze(transient).pattern == BattlefieldObjectClassifier.Pattern.TRANSIENT_EFFECT_SUSPECT)

    val moving = ArenaObjectTracker.Track(2, .2f, .2f, .25f, .28f, .03f, .01f, 5, 0, 10)
    val results = (1..3).map { classifier.analyze(moving) }
    check(results.last().pattern == BattlefieldObjectClassifier.Pattern.MOVING_OBJECT_CANDIDATE)
    check(results.last().stable)

    val static = ArenaObjectTracker.Track(3, .4f, .2f, .48f, .32f, .001f, .001f, 6, 0, 9)
    val staticResult = (1..3).map { classifier.analyze(static) }.last()
    check(staticResult.pattern == BattlefieldObjectClassifier.Pattern.PERSISTENT_VISUAL_OBJECT)
    check(staticResult.stable)

    classifier.retainOnly(setOf(2))
    classifier.reset()
    println("BattlefieldObjectClassifier smoke tests passed")
}

package com.clashai.coach

/** Normalized card-hand crop geometry for the portrait Clash Royale HUD. */
object HandCardSlotLayout {
    data class Slot(val index: Int, val left: Float, val top: Float, val right: Float, val bottom: Float)

    // Four card faces occupy the lower HUD. Leave the elixir meter and bottom screen edge out.
    private val slots = listOf(
        Slot(0, 0.035f, 0.805f, 0.265f, 0.955f),
        Slot(1, 0.265f, 0.805f, 0.495f, 0.955f),
        Slot(2, 0.505f, 0.805f, 0.735f, 0.955f),
        Slot(3, 0.735f, 0.805f, 0.965f, 0.955f)
    )

    fun forFrame(width: Int, height: Int): List<Slot> {
        if (width <= 0 || height <= 0 || height <= width) return emptyList()
        return slots.map { slot ->
            slot.copy(
                left = slot.left.coerceIn(0f, 1f), top = slot.top.coerceIn(0f, 1f),
                right = slot.right.coerceIn(0f, 1f), bottom = slot.bottom.coerceIn(0f, 1f)
            )
        }
    }
}

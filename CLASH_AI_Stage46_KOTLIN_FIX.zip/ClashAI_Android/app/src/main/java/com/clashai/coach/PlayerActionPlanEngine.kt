package com.clashai.coach

/**
 * Stage 44: converts strategy advice into a structured, human-confirmed action card.
 * This class never taps, drags, or controls Clash Royale.
 */
class PlayerActionPlanEngine {
    enum class ActionType { DEFEND, COUNTERATTACK, WAIT }
    enum class Confidence { LOW, LIMITED, MODERATE }

    data class ActionPlan(
        val action: ActionType,
        val card: String?,
        val lane: String,
        val elixirCost: Int?,
        val confidence: Confidence,
        val requiresConfirmation: Boolean,
        val steps: List<String>,
        val reason: String,
        val safetyNote: String
    ) {
        fun render(): String = buildString {
            append("PLAYER ACTION PLAN · HUMAN CONFIRMATION REQUIRED\n")
            append("ACTION: $action\n")
            append("CARD: ${card ?: "No card selected"}\n")
            append("LANE: $lane\n")
            append("COST: ${elixirCost?.let { "$it elixir" } ?: "unknown"}\n")
            append("CONFIDENCE: $confidence\n")
            steps.forEachIndexed { index, step -> append("${index + 1}. $step\n") }
            append("WHY: $reason\n")
            append("SAFETY: $safetyNote")
        }
    }

    fun create(
        strategy: BattleStrategyEngine.Strategy,
        plan: TacticalDecisionPlanner.Plan,
        hand: List<String>,
        ownElixir: Int?,
        combo: TacticalCombinationEngine.Combo?,
        latestConfirmedEnemyCard: String?
    ): ActionPlan {
        val recognised = hand.distinct()
        val affordable = recognised.filter { card ->
            val cost = CardCatalog.costs[card]
            cost != null && ownElixir != null && cost <= ownElixir
        }
        val lane = when {
            strategy.laneFocus.contains("LEFT", true) -> "LEFT — visually verify"
            strategy.laneFocus.contains("RIGHT", true) -> "RIGHT — visually verify"
            else -> "UNCONFIRMED — inspect both lanes"
        }
        val exactCounter = latestConfirmedEnemyCard?.let { enemy ->
            CardCatalog.countersFor(enemy).firstOrNull { it in affordable }
        }

        return when (strategy.selected) {
            BattleStrategyEngine.Action.DEFEND -> {
                val chosen = exactCounter ?: affordable.minByOrNull { CardCatalog.costs[it] ?: Int.MAX_VALUE }
                val cost = chosen?.let { CardCatalog.costs[it] }
                ActionPlan(
                    ActionType.DEFEND, chosen, lane, cost,
                    if (exactCounter != null) Confidence.LIMITED else Confidence.LOW,
                    true,
                    listOf(
                        "Check that the detected enemy threat is real and identify its current position.",
                        if (chosen != null) "Review $chosen in your hand; confirm it can target the threat and is still affordable."
                        else "No affordable recognised card is available; preserve elixir and reassess.",
                        "Choose the placement and timing yourself, then watch whether the defence succeeds."
                    ),
                    if (exactCounter != null) "A listed counter to the confirmed $latestConfirmedEnemyCard is in hand and affordable. Matchup results are not guaranteed."
                    else "The strategy engine prioritised defence. ${plan.reason} The suggested card is only a generic affordable option, not a verified counter.",
                    "This is a suggestion, not a deployment command. Do not play if the visual state, card, or elixir reading is uncertain."
                )
            }
            BattleStrategyEngine.Action.COUNTERATTACK -> {
                val validCombo = combo?.takeIf {
                    it.lead in recognised && it.support in recognised &&
                        ownElixir != null && it.totalCost <= ownElixir
                }
                ActionPlan(
                    ActionType.COUNTERATTACK, validCombo?.lead, lane,
                    validCombo?.totalCost,
                    if (validCombo != null) Confidence.LIMITED else Confidence.LOW,
                    true,
                    listOf(
                        "Confirm your lane is safe and no new enemy push is developing.",
                        if (validCombo != null) "Review ${validCombo.lead} + ${validCombo.support}; combined cost ${validCombo.totalCost} elixir."
                        else "The previously suggested combination is no longer verified in hand or elixir; do not commit.",
                        "If you agree, deploy manually and observe the opponent's response before spending more."
                    ),
                    if (validCombo != null) "Both combo cards are recognised in hand and the combined cost fits the current elixir reading."
                    else "Counterattack was selected, but its card combination could not be revalidated.",
                    "Never treat a predicted opening as certainty. Keep control of card placement and deployment."
                )
            }
            BattleStrategyEngine.Action.WAIT -> ActionPlan(
                ActionType.WAIT, null, lane, null, Confidence.LOW, true,
                listOf(
                    "Keep observing both lanes.",
                    "Wait for a reliable hand, elixir, or battlefield update.",
                    "Re-evaluate before committing a card."
                ),
                "The current evidence does not justify a decisive move. ${plan.reason}",
                "No game action is taken automatically."
            )
        }
    }
}

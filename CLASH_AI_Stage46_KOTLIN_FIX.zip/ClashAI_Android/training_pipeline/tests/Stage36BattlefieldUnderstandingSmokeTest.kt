package com.clashai.coach

private fun box(label: String, confidence: Float, x: Float, y: Float, w: Float = 0.08f, h: Float = 0.08f) =
    ArenaObjectDetectionPostprocessor.Detection(
        classIndex = 0, label = label, confidence = confidence,
        left = x - w / 2f, top = y - h / 2f,
        right = x + w / 2f, bottom = y + h / 2f
    )

fun main() {
    val engine = BattlefieldUnderstandingEngine()

    // Repeated high-confidence detections establish a stable broad class, not a card identity.
    engine.update(listOf(box("ground_troop", .92f, .22f, .72f)), 1_000L, true)
    engine.update(listOf(box("ground_troop", .93f, .24f, .70f)), 2_000L, true)
    var snapshot = engine.update(listOf(box("ground_troop", .94f, .26f, .68f)), 3_000L, true)
    val friendly = snapshot.objects.single()
    check(friendly.kind == BattlefieldUnderstandingEngine.ObjectKind.TROOP)
    check(friendly.troopDomain == BattlefieldUnderstandingEngine.TroopDomain.GROUND)
    check(friendly.side == BattlefieldStateModel.Side.FRIENDLY)
    check(friendly.lane == BattlefieldStateModel.Lane.LEFT)
    check(friendly.identityConfirmed)
    check(friendly.movement == BattlefieldStateModel.Movement.TOWARD_TOP)
    check(friendly.towerProximity != "UNKNOWN")

    // Enemy air troop remains a broad troop category, not an exact card.
    snapshot = engine.update(listOf(box("air_troop", .91f, .76f, .25f)), 4_000L, true)
    val enemyAir = snapshot.objects.single()
    check(enemyAir.kind == BattlefieldUnderstandingEngine.ObjectKind.TROOP)
    check(enemyAir.troopDomain == BattlefieldUnderstandingEngine.TroopDomain.AIR)
    check(enemyAir.side == BattlefieldStateModel.Side.ENEMY)
    check(enemyAir.lane == BattlefieldStateModel.Lane.RIGHT)
    check(!enemyAir.identityConfirmed)

    // Generic troop labels must not be guessed into air or ground.
    snapshot = engine.update(listOf(box("troop", .90f, .5f, .5f)), 5_000L, true)
    check(snapshot.objects.single().troopDomain == BattlefieldUnderstandingEngine.TroopDomain.UNKNOWN)
    check(snapshot.objects.single().side == BattlefieldStateModel.Side.UNKNOWN)

    snapshot = engine.update(listOf(box("building", .95f, .5f, .78f)), 6_000L, true)
    check(snapshot.objects.single().kind == BattlefieldUnderstandingEngine.ObjectKind.BUILDING)
    snapshot = engine.update(listOf(box("spell_effect", .95f, .5f, .48f)), 7_000L, true)
    check(snapshot.objects.single().kind == BattlefieldUnderstandingEngine.ObjectKind.SPELL_EFFECT)

    val transition = BattlefieldStateModel()
    var transitionState = transition.update(listOf(
        BattlefieldStateModel.Observation(77, .5f, .50f, 0f, 0f, "troop", .9f, 1_000L)
    ))
    check(transitionState.objects.single().side == BattlefieldStateModel.Side.UNKNOWN)
    repeat(3) { i ->
        transitionState = transition.update(listOf(
            BattlefieldStateModel.Observation(77, .5f, .62f + i * .01f, 0f, .01f, "troop", .9f, 2_000L + i * 1_000L)
        ))
    }
    check(transitionState.objects.single().side == BattlefieldStateModel.Side.FRIENDLY)

    val unavailable = engine.update(emptyList(), 8_000L, false)
    check(!unavailable.modelReady)
    check(unavailable.summary.contains("not installed"))

    engine.reset()
    check(engine.update(emptyList(), 9_000L, true).objects.isEmpty())
    println("Stage 36 battlefield understanding smoke checks passed")
}

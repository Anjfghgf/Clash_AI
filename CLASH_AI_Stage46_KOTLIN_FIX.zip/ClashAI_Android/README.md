# CLASH AI Coach

Android companion app for Clash Royale battle coaching.

## Current features
- Bundled Clash Royale card catalogue and known elixir costs.
- Manual enemy-card play log and player-hand selection.
- Enemy card-cycle estimates based on the last four confirmed opponent plays.
- Enemy elixir simulation that applies logged card costs at their play timestamps, respects the 10-elixir cap, and changes regeneration by match phase.
- Approximate match timer with automatic single/double/triple-elixir phase labels; a manual double-elixir override is also available.
- Basic defensive counter and offensive coaching suggestions.
- User-approved Android MediaProjection screen capture with a persistent foreground notification.
- On-device OCR diagnostics.
- Experimental opponent-arena visual-change detector.
- When a large opponent-arena change is detected, the app saves a local crop and displays the latest crop in the app for review.

## Stage 37 — automatic enemy intelligence foundation
- Added a separate optional full-frame exact enemy-card detector runtime (`enemy_card_detector.tflite`) with its own matching labels file; it never reuses the player's hand-card classifier.
- Stable exact card-name detections on the estimated enemy side can populate an eight-card enemy deck and confirmed play log.
- The coach reports the observed four-card rotation and last confirmed enemy card.
- Enemy elixir remains explicitly unknown until verified match-start elixir and mode-specific regeneration are configured.
- No exact enemy-card model is bundled yet. Follow `training_pipeline/stage37/ENEMY_CARD_IDENTITY_TRAINING.md` to build one from authorised, manually labelled battlefield footage. Until then, automatic exact enemy deck recognition is not operational.

## Recognition status and limitations
The visual-change detector only flags possible battlefield activity. The crop is diagnostic evidence; it is **not** a confirmed enemy-card identity. The app still requires the player to confirm the card in the enemy tracker. OCR is diagnostic only and does not reliably identify troop sprites. A trained on-device object-detection/classification model and representative labelled gameplay frames are still required for reliable automatic card naming.

Enemy elixir is an estimate, not a value read directly from the opponent's UI. It depends on the match timer and the accuracy/completeness of manually logged enemy plays. The cycle estimate is also based only on confirmed logged plays.

## Screen capture and privacy
- Screen capture starts only after the player taps Start Screen Analysis and accepts Android's system permission prompt.
- Frame analysis and deployment-crop saving happen on-device. Crops are stored in the app's private cache and are not uploaded by this app.
- A persistent notification indicates that screen analysis is active.
- Tap Stop Screen Analysis to end capture.

## Build
Open the `ClashAI_Android` folder in Android Studio or run `gradle --no-daemon assembleDebug` from this folder with Android SDK configured.

## On-device vision dataset: manual card-region annotation

When a possible opponent deployment is detected, the app stores a temporary opponent-arena crop. After the user confirms the enemy card in the tracker, CLASH AI now opens a crop selector. Drag a tight rectangle around the visible deployed unit/card artwork and choose **Save card crop**. The app stores the cropped JPEG and a JSON label locally under `filesDir/vision_samples/<card_name>/`.

These are manually labelled card-region samples intended for future on-device model training. They are not model predictions, and no automatic card recognition model is bundled in this stage. Dataset collection quality depends on clear, correctly labelled crops. Images remain on the phone unless the user exports or shares them.


## API card IDs in the vision dataset

The bundled `app/src/main/assets/cards.json` contains 123 API card records. Each manually annotated card crop now stores the matching `cardId` alongside `cardLabel`, elixir cost, rarity, and reference image URL in its JSON metadata. This preserves the official API identity for future model class mapping. The API ID is a card identifier, not a trained recognition model. No automatic card classifier is included yet; crops are labelled training data only.


## Stage 4: on-device recognition runtime foundation
- Added TensorFlow Lite runtime support and a guarded `CardRecognitionEngine`.
- The engine expects `card_classifier.tflite` and `card_labels.txt` in app assets.
- Model input contract: FLOAT32 RGB tensor `[1,224,224,3]`, values normalized to `[0,1]`.
- Model output contract: FLOAT32 `[1,class_count]` with classes in the exact order listed in `card_labels.txt` (`cardId|Card Name`).
- The engine maps model classes to the official IDs in `cards.json` and rejects predictions below 78% confidence.
- **No trained model is included in this stage.** The app reports the model as unavailable until genuine gameplay training data is used to create a compatible model. This is intentional: it prevents false automatic card calls.
- The uploaded XRecorder video is 240x552 and heavily compressed. It can help inspect match timing and large events, but it is not sufficient by itself to label all card classes reliably.

## Stage 5 — labelled dataset export

The app can now export a ZIP of confirmed training samples using Android's system file picker. The archive contains `images/<cardId>/...jpg`, `labels.csv`, `dataset_summary.json`, and `README.txt`. Only manually annotated card-only crops with valid card IDs and matching metadata are included; raw battlefield-event snapshots and invalid samples are excluded. The in-app sample count now counts confirmed card crops only.

This stage prepares data for training; it does not train a model on the phone and does not make live card recognition automatic. Review exported images for incorrect labels, duplicates, and poor crops before training. Keep samples from the same match/session together when splitting training and validation data to avoid leakage.


## Stage 6 — 2D arena motion regions

- Replaced the coarse whole-arena change score with a lightweight 2D frame-difference pipeline over the opponent-side arena region.
- Samples a 72 × 54 grayscale grid, thresholds changed cells, groups adjacent changed cells into connected components, and reports up to 12 candidate regions.
- Candidate regions are generated locally on-device. Frame sampling runs at a bounded interval; OCR diagnostics are throttled separately to reduce work.
- The app reports how many motion regions were found and retains a reviewable arena crop.
- **Important:** these are motion regions, not troop detections. Moving troops, spell effects, hit flashes, animations, and other visual changes may all trigger regions. No bounding-box detector, card identity model, or automatic enemy deck update is included yet.

### Next validation

Test the detector during an actual match and during a static/menu screen. Check whether it produces too many candidates from water, tower animations, spell effects, or screen transitions. The thresholds and arena region may need tuning for device resolution and game layout before adding a trained troop detector.


## Stage 7 — 2D motion-object tracking

- Added an on-device tracker that associates connected motion regions across sampled frames using centre distance and bounding-box overlap.
- Assigns temporary track IDs, smooths bounding boxes, estimates horizontal/vertical movement, and keeps short-lived tracks through brief missed detections.
- A track is marked persistent only after it is observed in at least two sampled frames; tracks expire after repeated misses.
- The app displays the number of persistent visual tracks and sends track metadata with review snapshots.
- **Important:** a persistent track is still only a moving-visual hypothesis. Troops, spell effects, tower animations, hit flashes, and other effects can produce tracks. This stage does not identify units, infer card names, or update the enemy deck automatically.

### Stage 7 validation

Test a static/menu screen, a live match with troops moving, and a match with spells/effects. Check whether track IDs remain reasonably stable and whether effects create false tracks. Tune the distance and persistence thresholds for the device and game layout before adding sprite-level classification.

## Stage 12 — Enemy deck and cycle foundation

This update adds `EnemyDeckTracker.kt` and connects it to the existing manual enemy-play controls.

- Tracks up to eight **unique, manually confirmed** enemy cards.
- Repeated plays increase play history but never consume another deck slot.
- Shows unconfirmed deck slots until eight unique cards are observed.
- Undo and clear rebuild/reset the deck state from the confirmed play log.
- Estimates card return timing from the four-card cycle: four other plays after a card is used. Repeated plays count as plays.
- Displays an elixir estimate with a small likely range to communicate that timing and manually logged plays are approximate.

### Important limitations

This is a reliable tracking foundation, not automatic card recognition. A user still confirms enemy plays in the app. The existing screen-motion tracker does not identify card names. The elixir estimate assumes a standard starting estimate of 5 and the existing single/double/triple regeneration schedule; special modes with different rules need their own configured rules before the estimate can be trusted. The likely range is an uncertainty hint, not a measured statistical confidence interval. No trained `.tflite` model is included.

The supplied archive has no Gradle wrapper, and a local Gradle executable was not available in the build environment. Source and archive checks were performed, but an Android APK build was not verified.

## Stage 13 — Individual battlefield crop capture

Stage 13 extends the existing 2D motion-candidate pipeline. When persistent visual tracks are found in the opponent-side arena, the capture service now saves up to eight padded, individual track crops alongside the full opponent-arena diagnostic snapshot. The broadcast includes a `track_crops` JSON array with track ID, local cache path, hit count, changed-cell count, and an explicit `unlabelled_candidate` status.

The main screen previews the first available individual crop so the existing manual card-labelling workflow can label a real battlefield appearance rather than the entire arena. The deck tracker remains unchanged: a crop or motion track never confirms an enemy card. Only a human-confirmed card event can update the enemy deck/cycle/elixir state.

**Important limits:** these crops are motion-based candidates and may contain spell effects, animation fragments, overlapping units, or background changes. Stage 13 does not add a trained troop classifier and does not claim automatic troop-name recognition. The existing TFLite runtime remains unavailable until a compatible, properly trained `card_classifier.tflite` is supplied. The crop cache is local to the app and capped at 120 files.

### Stage 13 verification

- ZIP archive integrity checked.
- Source wiring checked: capture service emits track crop metadata; main activity reads it and selects an individual crop for the existing label flow.
- Full Android/Gradle build was not run in this environment; no Gradle executable or wrapper is present in this project archive.

### Next stages

1. Improve candidate quality and add a review queue for multiple crops.
2. Build a session-separated, correctly labelled dataset from user-owned or creator-permitted footage.
3. Train and validate the classifier, fix preprocessing parity, and export the TFLite model.
4. Add temporal multi-frame recognition consensus and only emit verified card events.
5. Connect verified events to enemy deck/cycle/elixir intelligence, then develop battlefield reasoning, coaching, and player control.

## Stage 14 — Dataset collection and model-training pipeline

Added the `training_pipeline/` toolkit:
- `extract_video_frames.py` samples frames from an authorised local gameplay video and creates an **unlabelled** annotation queue. It does not download online videos or assign guessed troop labels.
- `prepare_dataset.py` validates Android crop-export ZIPs, groups images by export/session, removes exact duplicate files within a session, and writes a unified dataset.
- `train_classifier.py` trains a MobileNetV2 card-crop classifier, uses a session-grouped train/validation split, requires each retained class to appear in multiple sessions, and exports the Android TFLite input/output contract.
- The preprocessing parity issue is handled inside the model: Android's `[0,1]` RGB input is multiplied by 255 before MobileNetV2 preprocessing.
- `sources.csv` and the training guide document source permissions and dataset handling.

**No trained `.tflite` model is included:** the supplied project does not contain a sufficient verified, labelled multi-session gameplay dataset. The training script deliberately stops rather than creating a misleading model when there are too few independent sessions or classes. The classifier is still crop-based; full arena object detection, temporal consensus, team-side identification, and automatic deck updates remain future work.

### Stage 14 checks
- Python scripts pass syntax compilation.
- Dataset preparation was tested using a generated sample Android-export ZIP.
- Full TensorFlow training and Android APK build were not run in this environment; TensorFlow training requires an appropriately provisioned Python environment and real labelled data.

## Stage 15 — Temporal recognition

Stage 15 adds per-track temporal verification around the optional TFLite classifier. A stable candidate requires at least three matching accepted predictions in a five-observation window, with average confidence >= 0.82 and >= 60% agreement. Stable candidates are displayed but never auto-confirmed into the enemy deck. See `STAGE15_NOTES.md` for model requirements and limitations.

## Stage 16 — Battlefield motion-pattern analysis

Stage 16 adds a conservative, heuristic `BattlefieldObjectClassifier` for the visual tracks already produced by the 2D motion tracker. It labels motion/shape patterns as moving-object candidate, persistent visual object, transient-effect suspect, or uncertain. A five-observation history can mark a non-uncertain pattern as repeated. The capture service sends these hints separately from card predictions, and the app displays them as tentative/repeated observations.

**This is not troop recognition.** These labels do not identify a Knight, Hog Rider, building, spell, or any other semantic class. Spell effects, hit flashes, overlapping units, and background animation can still confuse the motion tracker. Pattern hints do not update the enemy deck, card cycle, or elixir. No trained object-detection model is included.

### Stage 16 verification
- Pure Kotlin motion-pattern classifier smoke tests passed.
- Stage 15 temporal recognition verifier smoke tests passed.
- Python training scripts passed syntax compilation.
- Full Android APK build and live gameplay validation were not performed in this environment.


## Stage 17 — Battlefield object-detection foundation

Added a manually labelled full-frame detection dataset converter, match/session-separated train/validation/test splits, an optional YOLO training/TFLite export script, and a Kotlin YOLOv8-style output postprocessor with confidence filtering and class-aware NMS. See `STAGE17_NOTES.md` and `training_pipeline/README.md`. **No trained detector model is included and live arena detection is not yet wired into screen capture.** Detector boxes are tentative and do not update enemy deck or elixir.


## Stage 18 — Live learning and early battle advice

The live coach now accumulates motion-pattern and temporal-recognition observations during a match and begins showing cautious advice before the enemy deck is complete. Suggestions include their evidence and confidence limitations. This is rule-based evidence accumulation, not neural-network training. Visual hypotheses remain unconfirmed and never update the enemy deck or elixir automatically. See `STAGE18_NOTES.md`.


## Stage 19 — Battle understanding and decision engine

See `STAGE19_NOTES.md`. Adds an explainable tactical assessment that combines confirmed card logs, hand/elixir estimates, and tentative visual evidence. It explains recommendations and confidence; it does not claim trained strategy or autonomous play.

## Stage 20 — Battlefield State Model
- Adds a normalized-coordinate temporal state model for side, lane, coarse movement, persistence, and repeated detector-label verification.
- Unknowns near the river remain unassigned; tentative labels do not become confirmed identities from a single frame.
- MainActivity displays the current state-model summary and uncertainty cautions.
- **Integration limitation:** live capture does not yet supply reliable normalized object detections to this model. It is currently a tested component awaiting the detector-to-state observation bridge; do not interpret the waiting summary as live battlefield understanding.

## Stage 21 — Live gameplay floating coach

Stage 21 adds a movable Android overlay so the player can see conservative coaching status while Clash Royale is foregrounded. Enable **Display over other apps** from the CLASH AI button, start the existing user-approved MediaProjection capture, then switch to the game. The capture service updates the panel independently of MainActivity, so Activity pause/unregister does not stop overlay updates. The panel can be hidden or the capture stopped from CLASH AI.

This is live visual-status assistance, not a finished tactical AI: current track signals are motion hypotheses, no trained troop detector is bundled, and no cards are automatically played. Android permissions are user-controlled. See `STAGE21_NOTES.md` for setup and limitations.

## Stage 22 — Live HUD / Elixir OCR foundation

Adds coordinate-aware OCR parsing for possible elixir values in the lower-centre HUD, repeated-reading status, and floating-coach HUD summaries. Card names in the four-card hand are not yet automatically identified; that requires validated card-slot image crops and a trained visual model. See `STAGE22_NOTES.md`.

## Stage 23 — Automatic hand card recognition pipeline
- Automatically crops the four expected hand-card slots from live screen frames.
- Runs the existing TFLite classifier on each crop when a compatible trained model is installed.
- Requires 3 matching accepted predictions in a 5-observation window before displaying a stable card identity.
- Uncertain cards remain unknown; no manual card selection is required during normal capture.
- Saves a bounded set of private candidate crops for future labelled training.
- **No trained card model is bundled yet**, so automatic cropping is integrated but card-name recognition awaits a verified dataset and trained model.
See `STAGE23_NOTES.md`.


## Stage 25 — train and install a real card model
- Audit labelled gameplay crops, train a session-separated MobileNetV2 classifier, validate the TFLite export, and import the model/labels pair through the Android app.
- No trained classifier is bundled until real, correctly labelled match samples are available.
See `STAGE25_NOTES.md` and `training_pipeline/README.md`.

## Stage 26 — Live battle decision integration

The live capture service now feeds stable automatic hand predictions, repeated own-elixir OCR, and tentative battlefield observations into the explainable battle decision engine. It requires four distinct stable card identities before card-specific advice and requires repeated OCR before using a numeric own-elixir value. Enemy elixir and unconfirmed enemy plays remain explicitly unknown. See `STAGE26_NOTES.md`.

## Stage 27 — Opponent intelligence foundation
- Adds a separate opponent evidence gate and eight-card deck/play-history model.
- Only high-confidence repeated arena-card-model observations or explicit manual confirmations can enter the confirmed opponent play log. Motion-only detections and the player's hand classifier are rejected as evidence.
- Tracks recent-play exclusions for opponent-hand reasoning and provides an optional elixir interval only when starting range and mode-specific regeneration are supplied.
- **Automatic enemy card recognition is not yet live:** there is no trained arena deployment classifier in this project. The current hand-card classifier recognises card artwork in the player's hand and must not be misused on battlefield sprites. See `STAGE27_NOTES.md`.

## Stage 28 — Battlefield detector runtime foundation

Stage 28 adds a separate optional TensorFlow Lite battlefield detector runtime. It is deliberately isolated from the player's hand-card classifier. The app looks for `arena_detector.tflite` and the matching `arena_detector_labels.txt` in `app/src/main/assets/`. No trained detector is bundled. Until a compatible model is trained and installed, the app reports the detector as unavailable and continues its other analysis. When present, detections are emitted as broad object candidates only; they are not automatically treated as enemy card identities or added to the opponent deck.

See `STAGE28_NOTES.md` for the model tensor contract, data preparation, installation steps, and limitations. See `STAGE28_TESTS.md` for verification status.


## Stage 29 — card strategy and learning

Stage 29 adds a combined attack/defence strategy layer, curated air/ground/building/spell classifications and tactical roles, hand/elixir/opponent-deck context sync, plus explicit user feedback buttons that adjust bounded local preferences over time. Unknown card identities remain unknown. See `STAGE29_NOTES.md` and `training_pipeline/stage29/CARD_TAXONOMY.md`.


## Stage 30 — Tactical combinations and game-mode intelligence

- Adds `TacticalCombinationEngine` for explainable two-card attack combinations using the recognised hand, confirmed elixir, card roles, and known opponent deck warnings. It never deploys cards automatically.
- Adds `GameModeIntelligence` profiles for Normal, Double Elixir, Triple Elixir, Draft, Chaos, 2v2, Sudden Death, and Unknown/Special modes.
- Adds in-app mode selection and a Chaos/Draft pick helper. The pick helper scores offered cards for missing deck-role coverage and reports alternatives.
- Every mode, including Chaos, keeps the eight-card deck and four-play cycle. Chaos/Draft can import a user-provided TXT/CSV/JSON-like offered-card file and build an eight-card deck one pick at a time; only known catalogue names are considered.
- Mode selection is persisted locally and restored when screen analysis starts.
- Special-mode elixir rates are not guessed. The mode profile labels known multipliers for standard double/triple elixir, but tactical recommendations still require a usable current elixir reading.

## Stage 31 — Competitive Chaos Draft
- The Chaos draft helper can include the opponent's publicly visible card picks when scoring our next choice.
- The competitive draft engine balances our own deck roles and adds limited denial value for answers to the opponent's visible picks.
- Opponent picks are currently entered in the helper UI; automatic draft-screen OCR is a future integration, not claimed as complete.
- Our deck remains exactly eight unique cards; the user confirms every in-game selection.


## Stage 32 — Two app modes
The app now presents two top-level choices: Normal (existing eight-card deck; no Chaos selection panel) and Chaos (competitive offered-card draft panel). Both feed the same shared battle-analysis and coaching engine. See `STAGE32_NOTES.md`.

## Stage 39 — Evidence-Gated Decision Learning

Stage 39 records tactical recommendations by game mode and priority, then accepts SUCCESS / NEUTRAL / UNSUCCESSFUL feedback only when the player explicitly submits it from the main screen. Unreported recommendations remain unscored. This stage reports historical feedback and does not automatically change policy weights. See `STAGE39_NOTES.md`.

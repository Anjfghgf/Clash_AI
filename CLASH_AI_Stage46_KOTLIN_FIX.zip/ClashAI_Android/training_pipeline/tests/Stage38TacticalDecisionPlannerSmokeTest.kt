package com.clashai.coach

fun main() {
    val planner = TacticalDecisionPlanner()
    val empty = emptyList<BattlefieldUnderstandingEngine.TrackedObject>()
    val defend = planner.evaluate(TacticalDecisionPlanner.Input(
        hand=listOf("Cannon", "Hog Rider"), ownElixir=4, latestConfirmedEnemyCard="Hog Rider",
        confirmedEnemyDeck=listOf("Hog Rider"), battlefield=empty, attackCombo=null, mode=GameModeIntelligence.Mode.NORMAL
    ))
    check(defend.priority.startsWith("DEFEND"))
    check("Cannon" in defend.recommendation)

    val enemyAir = BattlefieldUnderstandingEngine.TrackedObject(1,"air_troop",BattlefieldUnderstandingEngine.ObjectKind.TROOP,BattlefieldUnderstandingEngine.TroopDomain.AIR,
        BattlefieldStateModel.Side.ENEMY,BattlefieldStateModel.Lane.LEFT,BattlefieldStateModel.Movement.TOWARD_BOTTOM,
        0.86f,false,0.2f,0.3f,"MID_ARENA")
    val category = planner.evaluate(TacticalDecisionPlanner.Input(
        hand=listOf("Musketeer", "Hog Rider"), ownElixir=5, latestConfirmedEnemyCard=null,
        confirmedEnemyDeck=emptyList(), battlefield=listOf(enemyAir), attackCombo=null, mode=GameModeIntelligence.Mode.CHAOS
    ))
    check(category.priority.contains("category"))
    check("Musketeer" in category.recommendation)

    val friendly = enemyAir.copy(side=BattlefieldStateModel.Side.FRIENDLY)
    val ignored = planner.evaluate(TacticalDecisionPlanner.Input(
        hand=listOf("Hog Rider"), ownElixir=4, latestConfirmedEnemyCard=null,
        confirmedEnemyDeck=emptyList(), battlefield=listOf(friendly), attackCombo=null, mode=GameModeIntelligence.Mode.NORMAL
    ))
    check(ignored.priority == "CYCLE / WAIT")

    val unknown = planner.evaluate(TacticalDecisionPlanner.Input(
        hand=listOf("Hog Rider"), ownElixir=null, latestConfirmedEnemyCard=null,
        confirmedEnemyDeck=emptyList(), battlefield=emptyList(), attackCombo=null, mode=GameModeIntelligence.Mode.NORMAL
    ))
    check(unknown.priority == "OBSERVE")
    check("unconfirmed" in unknown.reserveWarning.lowercase())

    val combo = TacticalCombinationEngine.Combo("Hog Rider","Musketeer",8,"synergy","Moderate")
    val attack = planner.evaluate(TacticalDecisionPlanner.Input(
        hand=listOf("Hog Rider", "Musketeer"), ownElixir=8, latestConfirmedEnemyCard=null,
        confirmedEnemyDeck=emptyList(), battlefield=emptyList(), attackCombo=combo, mode=GameModeIntelligence.Mode.NORMAL
    ))
    check(attack.priority.contains("ATTACK"))
    println("Stage 38 tactical planner smoke checks passed")
}

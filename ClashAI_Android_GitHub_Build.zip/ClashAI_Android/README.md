# CLASH AI Coach — Android prototype

This is a native Android/Kotlin prototype project. It is **not a finished Clash Royale AI coach**. The included GitHub Actions workflow can compile a debug APK in the cloud, so a computer or AndroidIDE is not required.

## Build an APK from an Android phone

1. Create a GitHub repository (for example, `clash-ai-android`).
2. Upload the **contents** of this folder to the repository root (including the hidden `.github` folder).
3. Open the repository's **Actions** tab and enable Actions if prompted.
4. Select **Build CLASH AI APK**, then tap **Run workflow**. A push to `main` or `master` also starts a build automatically.
5. When the run finishes successfully, open the run, scroll to **Artifacts**, and download `clash-ai-debug-apk`.
6. Extract the artifact ZIP and install `app-debug.apk`. Android may ask you to allow installs from your browser or Files app.

The APK is a debug build and is not signed for Play Store release.

## Implemented in this prototype
- Android MediaProjection screen capture after the user explicitly approves the Android system prompt.
- Foreground notification while capture is active, plus a Stop button.
- On-device ML Kit OCR on a throttled screen stream (about one frame every 1.8 seconds).
- A small card-cost reference list and a basic text-match demonstration.

## Important limitations
- Clash Royale shows cards mainly as artwork during a live match; their names usually are not printed on the battle screen. OCR therefore cannot reliably identify played cards.
- Card-art recognition, hand-slot detection, elixir-bar computer vision, elixir regeneration tracking, enemy 8-card deck/cycle inference, and tactical recommendation logic are **not implemented yet**.
- OCR text matching may detect unrelated words and must not be treated as confirmed card observations.
- This app does not tap, control, modify, or inject into Clash Royale. It only analyses screen frames after the Android permission prompt.

## Technical build details
- Android Gradle Plugin 8.7.3; Kotlin 2.0.21; compile SDK 35; min SDK 26.
- GitHub Actions uses JDK 17 and runs `gradle assembleDebug`.


## Bundled card reference data
The app bundles `app/src/main/assets/cards.json` and loads the 123 card records
at startup. Card names, IDs, rarity, levels, image URLs, and known elixir costs
are available through `CardDatabase`. Missing costs remain unknown (not zero).

This is reference-data integration only. Live screen analysis currently uses
ML Kit OCR text and manual enemy-card logging; it does not yet classify card
artwork from the game screen. Enemy elixir remains an estimate based on the
match timer and logged known card costs.

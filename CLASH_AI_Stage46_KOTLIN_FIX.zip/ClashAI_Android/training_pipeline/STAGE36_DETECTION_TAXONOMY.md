# Stage 36 arena detector labels

Use one bounding box per clearly visible object and choose exactly one class:

| Class | Use when | Do not use when |
|---|---|---|
| `building` | A placed arena building is clearly visible | It is a tower/background structure or identity is unclear |
| `air_troop` | A troop is visibly airborne/flying | A ground troop jumps/has an animation or the view is unclear |
| `ground_troop` | A troop is visibly on the arena ground | The troop is flying or its domain cannot be established |
| `spell_effect` | A visible spell/projectile/area effect is present | It is a troop sprite or an ordinary arena animation |
| `troop_unknown` | A troop-like object is visible but air/ground cannot be determined | No troop-like object is actually visible |

Do not label exact card names in this detector. Exact card identity is a separate recognition task. Do not label a blurred object from memory or infer a hidden object. Keep a distinct `session_id` for every match. The dataset builder requires each class to appear in train, validation and test splits; collect enough independent sessions instead of weakening that requirement.

The trainer writes `arena_detector_labels.txt` in the exact class order used by the exported model. Copy that generated file unchanged beside `arena_detector.tflite`. The placeholder asset in the source tree is only a suggested class vocabulary, not a trained model's authoritative order.

# Stage 45 test

Run the pure Kotlin feedback engine test:

```bash
kotlinc app/src/main/java/com/clashai/coach/ActionFeedbackEngine.kt training_pipeline/tests/Stage45ActionFeedbackSmokeTest.kt -include-runtime -d stage45-feedback-test.jar
java -jar stage45-feedback-test.jar
```

Expected output: `Stage 45 action feedback smoke checks passed`.

The test checks explicit-feedback gating, pending-plan deduplication, mode isolation, minimum sample thresholds, and persistence snapshot restoration. Android service/UI integration is statically checked; a full APK/device test requires Android SDK/Gradle and a device.

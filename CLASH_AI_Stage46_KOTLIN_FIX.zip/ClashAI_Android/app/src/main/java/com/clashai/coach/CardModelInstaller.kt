package com.clashai.coach

import android.content.Context
import android.net.Uri
import java.io.File

/** Installs a user-trained TFLite model and matching labels as one validated pair. */
object CardModelInstaller {
    private const val MODEL = "card_classifier.tflite"
    private const val LABELS = "card_labels.txt"

    fun stage(context: Context, uri: Uri, targetName: String): File {
        require(targetName == MODEL || targetName == LABELS) { "Unsupported model package file" }
        val dir = File(context.filesDir, "card_model_staging").apply { mkdirs() }
        val out = File(dir, targetName)
        val input = context.contentResolver.openInputStream(uri) ?: error("Could not open selected file")
        input.use { stream -> out.outputStream().use { output -> stream.copyTo(output) } }
        require(out.isFile && out.length() > 0L) { "Selected file is empty" }
        if (targetName == MODEL) require(out.length() <= 128L * 1024 * 1024) { "Model exceeds 128 MB" }
        return out
    }

    fun install(context: Context): CardRecognitionEngine.ModelStatus {
        val staging = File(context.filesDir, "card_model_staging")
        val stagedModel = File(staging, MODEL)
        val stagedLabels = File(staging, LABELS)
        require(stagedModel.isFile && stagedLabels.isFile) { "Choose both the .tflite model and card_labels.txt first" }
        val target = File(context.filesDir, "card_model").apply { mkdirs() }
        val model = File(target, MODEL); val labels = File(target, LABELS)
        val backupModel = File(staging, "previous_model.bak")
        val backupLabels = File(staging, "previous_labels.bak")
        backupModel.delete(); backupLabels.delete()
        val hadModel = model.exists()
        val hadLabels = labels.exists()
        var modelBackedUp = false
        var labelsBackedUp = false
        return try {
            if (model.exists()) { check(model.renameTo(backupModel)) { "Could not back up previous model" }; modelBackedUp = true }
            if (labels.exists()) { check(labels.renameTo(backupLabels)) { "Could not back up previous labels" }; labelsBackedUp = true }
            check(stagedModel.copyTo(model, overwrite = true).length() > 0)
            check(stagedLabels.copyTo(labels, overwrite = true).length() > 0)
            CardDatabase.load(context)
            val validator = CardRecognitionEngine(context)
            val status = validator.status
            validator.close()
            require(status.ready) { status.message }
            stagedModel.delete(); stagedLabels.delete(); backupModel.delete(); backupLabels.delete()
            status
        } catch (error: Exception) {
            if (modelBackedUp) { model.delete(); if (backupModel.exists()) backupModel.renameTo(model) }
            else if (!hadModel) model.delete()
            if (labelsBackedUp) { labels.delete(); if (backupLabels.exists()) backupLabels.renameTo(labels) }
            else if (!hadLabels) labels.delete()
            throw error
        }
    }
}

package com.clashai.coach

/**
 * Tracks hand changes from stable card identities only. A transition is recorded only
 * when exactly one previously visible card disappears and one new card appears.
 * It does not infer identities for unknown slots or force a 4-card cycle when evidence
 * is incomplete.
 */
class HandRotationTracker {
    data class Transition(val playedCard: String, val enteredCard: String, val playNumber: Int)
    data class Snapshot(val knownSlots: Int, val transition: Transition?, val expectedReturn: String?, val statusSuffix: String)

    private var previous: Map<Int, String> = emptyMap()
    private val plays = ArrayList<String>()
    private var transitionCount = 0

    @Synchronized
    fun observe(stableSlots: Map<Int, String>): Snapshot {
        val current = stableSlots.filterKeys { it in 0..3 }.filterValues { it.isNotBlank() }
        var transition: Transition? = null
        if (previous.size == 4 && current.size == 4) {
            val oldCards = previous.values.toSet()
            val newCards = current.values.toSet()
            val removed = oldCards - newCards
            val added = newCards - oldCards
            if (removed.size == 1 && added.size == 1) {
                val played = removed.first()
                val entered = added.first()
                transitionCount += 1
                plays.add(played)
                transition = Transition(played, entered, transitionCount)
                if (plays.size > 24) plays.removeAt(0)
            }
        }
        if (current.size == 4) previous = current
        val expected = if (plays.size >= 4) plays[plays.size - 4] else null
        val suffix = when {
            current.size < 4 -> " · CYCLE: waiting for 4 recognised cards"
            transition != null -> " · CYCLE: ${transition.playedCard} played → ${transition.enteredCard} entered"
            expected != null -> " · NEXT RETURN ESTIMATE: $expected (based on observed plays)"
            else -> " · CYCLE: learning hand changes"
        }
        return Snapshot(current.size, transition, expected, suffix)
    }

    @Synchronized
    fun reset() { previous = emptyMap(); plays.clear(); transitionCount = 0 }
}

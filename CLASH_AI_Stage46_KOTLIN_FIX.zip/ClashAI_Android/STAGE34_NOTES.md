# CLASH AI — Stage 34: Calibrated Chaos Draft Sides

## Added
- Added explicit upper-half / lower-half ownership calibration in the Chaos panel.
- Calibration is persisted locally. The app never assumes that the upper or lower half belongs to the player.
- Once calibrated, OCR card-name candidates from the opposite half are saved as the opponent's publicly visible picks and prefilled into the competitive draft helper.
- OCR candidates from the user's half are shown as own visible selections and used as editable suggestions when no saved own deck exists.
- User can clear calibration at any time.
- Screen OCR candidates are no longer silently copied into the offered-card pool. Only the imported selection file (or manually entered options) is treated as the offered pool. This avoids confusing visible selected cards with available choices.
- The existing Chaos draft engine continues to enforce an eight-card own deck; Normal mode continues using the existing eight-card deck and the shared battle engine.

## Important limits
- Calibration is a one-time user confirmation, not automatic visual proof of player orientation. Recalibrate if the game layout/orientation changes.
- OCR may miss card names or read unrelated text. Candidate lists remain editable suggestions; unknown cards are not guessed.
- Opponent picks are only auto-populated when a side has been explicitly calibrated and the OCR reports a Chaos selection screen.
- The system still needs an accurate offered-card file or manual offered-card list. It does not infer the complete offer pool from the upper/lower OCR zones.
- Full Android APK build and live-device test were not available in this environment. No trained OCR/card/arena model is included.

## Verification
- Pure Kotlin calibration smoke test.
- Python training-pipeline syntax checks.
- Static integration checks and ZIP integrity check.

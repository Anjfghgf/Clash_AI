package com.clashai.coach

/** Run with kotlinc alongside ArenaObjectDetectionPostprocessor.kt. */
fun main() {
    val parser = ArenaObjectDetectionPostprocessor(listOf("troop", "building"), inputSize = 640)
    // Channel-first output: [4 + 2 classes, 2 candidates]. One troop, one lower-score duplicate.
    val values = floatArrayOf(
        320f, 322f, 100f, 100f, // cx
        320f, 321f, 100f, 100f, // cy
        100f, 102f, 100f, 100f, // w
        100f, 102f, 100f, 100f, // h
        0.91f, 0.80f, 0.05f, 0.04f, // troop scores
        0.02f, 0.03f, 0.01f, 0.01f  // building scores
    )
    val detections = parser.decode(values, intArrayOf(6, 4))
    check(detections.size == 1) { "Expected duplicate boxes to be suppressed" }
    check(detections.first().label == "troop")
    check(detections.first().left in 0.4f..0.5f)
    // Invalid output shape must fail closed.
    check(parser.decode(floatArrayOf(1f, 2f), intArrayOf(2, 1)).isEmpty())
    println("ArenaObjectDetectionPostprocessor smoke tests passed")
}

# Stage 31 — Competitive Chaos Draft Intelligence

## Implemented
- Added `ChaosCompetitiveDraftEngine`: scores each offered card for our deck's missing roles and for tactical denial/answer value against the opponent's publicly visible picks.
- Uses role coverage (win condition, anti-air, splash, spell, tank, support, defensive building, swarm and cycle) and conservative elixir-cost balance hints when card profile costs are known.
- Recommendations include separate own-deck and opponent-denial scores plus alternatives and an explanation.
- Updated Chaos/Draft helper UI: enter the opponent's visible picks, persist them locally, and include them in the next pick recommendation. Our own deck remains capped at exactly eight unique cards.
- The user still makes the actual in-game selection; the app does not tap/select cards automatically.
- Bumped Android version to 0.31.0 / versionCode 31.

## Important limitations
- Opponent picks are currently entered in the helper UI. Automatic OCR/visual recognition of the draft screen is not implemented or verified yet.
- Both players seeing selections is treated as public information supplied to the engine; the system does not assume hidden picks.
- Card scoring is explainable heuristic logic, not a trained model or proof of a guaranteed best pick. Unknown card profiles reduce confidence.
- The imported offered-card file remains the source of available choices; this stage does not scrape/download a mode-specific pool.
- Android APK build and live device test remain unverified in this environment.

## Manual test plan
1. Import the offered-card file and open Chaos draft helper.
2. Enter our current picks and opponent-visible picks.
3. Request a recommendation and confirm the card is in the offered pool and not already selected.
4. Change opponent picks and confirm denial score/reason can change.
5. Confirm our deck never exceeds 8 unique cards.
6. Restart app and verify our picks and opponent-visible picks persist.

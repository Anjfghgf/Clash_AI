# CLASH AI Stage 42 — Situational Awareness

Version: 0.42.0 (versionCode 42)

## Added

- `SituationalAwarenessEngine.kt` groups sufficiently confident battlefield objects by verified side, lane, and approximate spatial proximity.
- Reports friendly and enemy troop groupings, broad developing enemy pushes, and coarse combined lane pressure.
- Notes when a detected troop group is spatially near a detected building, when friendly and enemy groups appear in the same lane, and when spell/effect detections are present.
- Integrates the assessment into the live tactical summary and floating coach.
- Excludes unknown-side, unknown-lane, low-confidence, and unknown-kind detections from group interpretation.

## Important interpretation limits

- Grouping is a spatial heuristic, not a confirmed tactical formation or role classifier.
- The engine does not infer tank/support roles, exact card identities, targeting, damage, or precise paths.
- The existing arena detector still requires a separately trained and installed model; this ZIP does not include trained model weights.
- Suggestions remain advisory; the user makes in-game decisions. No game input automation is added.

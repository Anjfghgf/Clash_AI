package com.clashai.coach

/**
 * Stage 46: freshness and change-awareness layer for live coaching.
 * It does not create troop identities or infer unseen enemy cards.
 */
class RealtimeGameplayIntelligence(
    private val staleAfterMs: Long = 4_500L
) {
    data class Snapshot(
        val freshness: String,
        val urgency: String,
        val recommendedRefreshMs: Long,
        val changedObjects: Int,
        val trackedObjects: Int,
        val summary: String
    )

    private var lastObservedAt = 0L
    private var lastSignature = emptySet<String>()
    private var lastCard: String? = null

    @Synchronized
    fun observe(
        battlefield: BattlefieldUnderstandingEngine.Snapshot,
        timestampMs: Long,
        confirmedEnemyDeck: List<String>,
        latestConfirmedEnemyCard: String?
    ): Snapshot {
        val signature = battlefield.objects.map {
            "${it.trackId}:${it.label}:${it.side}:${it.lane}:${it.movement}"
        }.toSet()
        val changed = (signature - lastSignature).size + (lastSignature - signature).size
        val elapsed = if (lastObservedAt == 0L) 0L else timestampMs - lastObservedAt
        val fresh = elapsed <= staleAfterMs
        val urgency = when {
            !battlefield.modelReady -> "MODEL_UNAVAILABLE"
            changed >= 3 -> "HIGH_CHANGE"
            changed > 0 -> "CHANGING"
            else -> "STABLE"
        }
        val interval = refreshIntervalFor(urgency)
        if (!latestConfirmedEnemyCard.isNullOrBlank() &&
            latestConfirmedEnemyCard != lastCard) {
            lastCard = latestConfirmedEnemyCard
        }
        val deckText = "${confirmedEnemyDeck.distinct().size.coerceAtMost(8)}/8 enemy cards confirmed"
        val cycleText = if (lastCard != null) {
            "Latest exact enemy card: $lastCard; card-cycle return remains an estimate until intervening plays are confirmed."
        } else {
            "Enemy card cycle: waiting for exact confirmed plays."
        }
        val freshness = when {
            !battlefield.modelReady -> "DETECTOR_NOT_READY"
            elapsed > staleAfterMs -> "STALE"
            else -> "FRESH"
        }
        val summary = "REAL-TIME INTELLIGENCE: $urgency; ${battlefield.objects.size} tracked object(s); $deckText. $cycleText"
        lastSignature = signature
        lastObservedAt = timestampMs
        return Snapshot(freshness, urgency, interval, changed, battlefield.objects.size, summary)
    }

    fun refreshIntervalFor(urgency: String): Long = when (urgency) {
        "HIGH_CHANGE" -> 650L
        "CHANGING" -> 1_000L
        "MODEL_UNAVAILABLE" -> 2_500L
        else -> 1_800L
    }

    @Synchronized
    fun reset() {
        lastObservedAt = 0L
        lastSignature = emptySet()
        lastCard = null
    }
}

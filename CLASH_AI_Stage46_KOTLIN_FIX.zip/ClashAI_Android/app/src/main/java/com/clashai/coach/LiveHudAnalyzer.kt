package com.clashai.coach

/** Conservative OCR interpretation of the lower HUD. OCR text alone never identifies a card. */
class LiveHudAnalyzer {
    data class TextRegion(val text: String, val left: Float, val top: Float, val right: Float, val bottom: Float)
    data class HudReading(val elixir: Int?, val confidence: String, val detail: String)

    private val recentElixir = ArrayDeque<Int>()

    fun observe(regions: List<TextRegion>, width: Int, height: Int): HudReading {
        if (width <= 0 || height <= 0) return HudReading(null, "UNAVAILABLE", "Invalid frame size")
        val candidates = regions.mapNotNull { region ->
            val cy = (region.top + region.bottom) / 2f / height
            val cx = (region.left + region.right) / 2f / width
            val text = region.text.trim().replace(',', '.')
            // Elixir is shown in the lower HUD. Ignore timer/crown text elsewhere.
            if (cy < 0.78f || cx !in 0.44f..0.56f) return@mapNotNull null
            val value = text.toIntOrNull() ?: return@mapNotNull null
            value.takeIf { it in 0..10 }
        }
        val raw = candidates.firstOrNull()
        if (raw != null) {
            recentElixir.add(raw)
            while (recentElixir.size > 3) recentElixir.removeFirst()
        }
        if (raw == null) return HudReading(null, "NO_READING", "No clear elixir number in the lower HUD")
        val matching = recentElixir.count { it == raw }
        return if (matching >= 2) {
            HudReading(raw, "REPEATED_OCR", "Elixir OCR repeated; still verify against the game display")
        } else {
            HudReading(raw, "SINGLE_OCR", "One-frame elixir reading; awaiting confirmation")
        }
    }

    fun reset() { recentElixir.clear() }
}

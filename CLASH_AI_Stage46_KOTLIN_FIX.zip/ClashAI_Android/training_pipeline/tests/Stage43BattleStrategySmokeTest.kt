package com.clashai.coach
fun main() {
    val engine = BattleStrategyEngine()
    val plan = TacticalDecisionPlanner.Plan("OBSERVE", "Hold", "No confirmed threat", "Both lanes", "Low", "Reserve")
    val emptySituation = SituationalAwarenessEngine.Assessment(emptyList(), SituationalAwarenessEngine.Pressure.UNKNOWN)
    val unknown = engine.evaluate(emptyList(), null, null, plan,
        MatchPredictionEngine.Prediction("INSUFFICIENT", "Both lanes uncertain", MatchPredictionEngine.Threat.UNKNOWN),
        emptySituation, emptyList(), GameModeIntelligence.Mode.NORMAL)
    check(unknown.selected == BattleStrategyEngine.Action.WAIT)
    check(unknown.render().contains("cannot guarantee a win"))
    val combo = TacticalCombinationEngine.Combo("Giant", "Musketeer", 9, "Tank plus support", "Low")
    val attack = engine.evaluate(listOf("Giant", "Musketeer"), 9, combo, plan,
        MatchPredictionEngine.Prediction("NO PUSH", "No lane pressure", MatchPredictionEngine.Threat.LOW),
        emptySituation, emptyList(), GameModeIntelligence.Mode.NORMAL)
    check(attack.selected == BattleStrategyEngine.Action.COUNTERATTACK)
    check(attack.nextStep.contains("Giant with Musketeer"))
    val push = SituationalAwarenessEngine.Assessment(
        listOf(SituationalAwarenessEngine.Group(BattlefieldStateModel.Side.ENEMY, 3, 2)),
        SituationalAwarenessEngine.Pressure.HIGH)
    val defend = engine.evaluate(listOf("Knight"), 5, null, plan,
        MatchPredictionEngine.Prediction("PUSH", "left lane pressure", MatchPredictionEngine.Threat.HIGH),
        push, emptyList(), GameModeIntelligence.Mode.CHAOS)
    check(defend.selected == BattleStrategyEngine.Action.DEFEND)
    check(defend.laneFocus.contains("LEFT"))
    check(defend.rankedCandidates.first().action == BattleStrategyEngine.Action.DEFEND)
    check(defend.confidence.contains("Low"))
    val pushBlocksAttack = engine.evaluate(listOf("Giant", "Musketeer"), 9, combo, plan,
        MatchPredictionEngine.Prediction("PUSH", "left lane pressure", MatchPredictionEngine.Threat.LOW),
        SituationalAwarenessEngine.Assessment(
            listOf(SituationalAwarenessEngine.Group(BattlefieldStateModel.Side.ENEMY, 1, 1)),
            SituationalAwarenessEngine.Pressure.LOW), emptyList(), GameModeIntelligence.Mode.NORMAL)
    check(pushBlocksAttack.selected != BattleStrategyEngine.Action.COUNTERATTACK)
    println("Stage 43 battle strategy smoke checks passed")
}

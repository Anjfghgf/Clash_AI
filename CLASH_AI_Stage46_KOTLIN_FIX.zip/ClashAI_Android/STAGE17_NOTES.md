# Stage 17 — Battlefield Object Detection Foundation

## What changed
- Added a full-frame bounding-box dataset converter for manually reviewed labels.
- Splits data by match/session into train, validation, and test sets; requires at least three sessions.
- Added an optional Ultralytics training/export script for a compact YOLO detector.
- Added a Kotlin YOLOv8-style TFLite output postprocessor with confidence filtering and class-aware non-maximum suppression (NMS).
- Added a smoke test for box decoding and duplicate suppression.

## Detection classes
Start with broad visual categories: `troop`, `building`, and `spell_effect`. Add `friendly_troop` and `enemy_troop` only when the labels can be assigned reliably from the arena side/placement context. Do not label a sprite by guessing from a blurry frame. Each box must tightly enclose one visible object; overlapping groups may need separate boxes only when individual objects are actually distinguishable.

## Dataset preparation
Use only recordings/datasets whose licence or creator permission allows the intended model-training use. Publicly viewable videos are not automatically licensed for downloading or training. Keep a different `session_id` for each match/video recording.

```bash
pip install -r requirements-detection.txt
python scripts/prepare_detection_dataset.py --annotations annotations.csv --out arena_dataset
python scripts/train_arena_detector.py --data arena_dataset/dataset.yaml --out detector_runs --epochs 80 --imgsz 640
```

The converter expects pixel-coordinate boxes and copies images into YOLO layout. Review `dataset_report.json` and visually inspect labels before training. The script requires three independent sessions and keeps sessions separated. It does not fabricate labels or download videos.

## Android adapter contract
`ArenaObjectDetectionPostprocessor` consumes the two-dimensional portion of a YOLOv8-style output tensor, with shape `[4 + classCount, candidateCount]` or `[candidateCount, 4 + classCount]`. The first four channels are `cx, cy, width, height`; remaining channels are per-class scores. Coordinates may be normalized or in model-input pixels. Output boxes are normalized to 0..1. NMS is class-aware.

**Important compatibility gate:** TFLite exports vary by Ultralytics version and export settings. Before integrating a trained model, inspect its actual input/output tensor shapes, quantization, coordinate scale, and class order. The postprocessor is not yet a complete model loader, image preprocessor, or live-capture integration. Do not copy an arbitrary `.tflite` file into assets and assume it works.

## Status / limitations
- No detector weights or `.tflite` model are bundled; real labelled data is not available in this build.
- The postprocessor is a model-output adapter only. Stage 17 does not yet identify troops in live gameplay.
- Detector boxes alone do not prove ownership/team or enemy card identity. Keep detections tentative until temporal/team-side verification is implemented.
- Stage 16 motion tracks remain separate from detector predictions. No automatic enemy deck or elixir update is enabled.
- Full Android APK build and live gameplay validation were not performed in this environment.

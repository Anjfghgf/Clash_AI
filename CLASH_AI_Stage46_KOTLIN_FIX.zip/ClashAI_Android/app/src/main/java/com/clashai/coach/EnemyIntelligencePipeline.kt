package com.clashai.coach

/**
 * Stage 37: converts only stable, exact card-name arena detections on the enemy side
 * into enemy plays. Broad labels (troop, air_troop, building, spell_effect) are never
 * promoted to a card identity. The pipeline is advisory and keeps elixir unknown
 * unless a caller supplies verified starting range and mode-specific regeneration.
 */
class EnemyIntelligencePipeline(
    private val intelligence: EnemyBattleIntelligence = EnemyBattleIntelligence(maxDeckSize = 8)
) {
    data class Update(
        val acceptedPlays: List<String>,
        val deck: List<String>,
        val latestCard: String?,
        val summary: String,
        val elixir: EnemyBattleIntelligence.ElixirRange
    )

    private val acceptedTrackIds = linkedSetOf<Int>()
    private val canonicalCards by lazy {
        CardCatalog.names.associateBy { normalize(it) }
    }
    private var lastAcceptedCard: String? = null
    private var lastTimestampMs: Long = 0L
    private var startElixirLow: Double? = null
    private var startElixirHigh: Double? = null
    private var regenPerSecond: Double? = null
    private var matchStartMs: Long? = null

    @Synchronized
    fun update(snapshot: BattlefieldUnderstandingEngine.Snapshot, timestampMs: Long): Update {
        val accepted = mutableListOf<String>()
        val acceptedThisFrame = mutableSetOf<String>()
        if (snapshot.modelReady) {
            snapshot.objects.forEach { obj ->
                if (obj.trackId in acceptedTrackIds) return@forEach
                if (obj.side != BattlefieldStateModel.Side.ENEMY) return@forEach
                if (!obj.identityConfirmed || obj.confidence < 0.90f) return@forEach
                val canonical = canonicalCards[normalize(obj.label)] ?: return@forEach
                acceptedTrackIds += obj.trackId
                if (acceptedThisFrame.add(canonical) && intelligence.recordConfirmed(canonical, timestampMs)) {
                    accepted += canonical
                    lastAcceptedCard = canonical
                    lastTimestampMs = timestampMs
                }
            }
        }
        val elapsed = matchStartMs?.let { ((timestampMs - it).coerceAtLeast(0L)) / 1000.0 } ?: 0.0
        val elixir = intelligence.estimateElixir(
            startElixirLow, startElixirHigh, elapsed, regenPerSecond
        )
        return Update(
            acceptedPlays = accepted,
            deck = intelligence.confirmedDeck(),
            latestCard = lastAcceptedCard,
            summary = buildSummary(elixir),
            elixir = elixir
        )
    }

    /** Call only when the match's starting elixir and mode regeneration are verified. */
    @Synchronized
    fun configureElixir(startLow: Double, startHigh: Double, regenPerSecond: Double, matchStartMs: Long): Boolean {
        if (!startLow.isFinite() || !startHigh.isFinite() || !regenPerSecond.isFinite() ||
            startLow < 0.0 || startHigh < startLow || startHigh > 10.0 || regenPerSecond < 0.0 || matchStartMs < 0L) return false
        this.startElixirLow = startLow
        this.startElixirHigh = startHigh
        this.regenPerSecond = regenPerSecond
        this.matchStartMs = matchStartMs
        return true
    }

    @Synchronized
    fun reset() {
        intelligence.reset()
        acceptedTrackIds.clear()
        lastAcceptedCard = null
        lastTimestampMs = 0L
        startElixirLow = null
        startElixirHigh = null
        regenPerSecond = null
        matchStartMs = null
    }

    @Synchronized
    fun deck(): List<String> = intelligence.confirmedDeck()

    private fun buildSummary(elixir: EnemyBattleIntelligence.ElixirRange): String = buildString {
        append("ENEMY INTELLIGENCE: ").append(intelligence.confirmedDeck().size).append("/8 cards confirmed")
        append("\nDeck: ").append((1..8).joinToString(" · ") { slot -> intelligence.confirmedDeck().getOrNull(slot - 1) ?: "Unknown" })
        append("\nLast confirmed play: ").append(lastAcceptedCard ?: "none")
        append("\nCard rotation: ")
        val states = intelligence.cardStates()
        append(if (states.isEmpty()) "waiting for confirmed plays" else states.joinToString(" · ") { state ->
            val remaining = (4 - state.playsSinceLastUse).coerceAtLeast(0)
            "${state.name}: ${if (remaining == 0) "possibly back" else "$remaining play(s)"}"
        })
        append("\nEnemy elixir: ")
        append(if (elixir.known) "${"%.1f".format(elixir.low)}–${"%.1f".format(elixir.high)} (estimate)" else "unknown — no verified starting value/regeneration")
        append("\nOnly stable exact card-name detections count; broad troop/building labels remain unconfirmed.")
    }

    private fun normalize(value: String): String = value.lowercase().replace(Regex("[^a-z0-9]"), "")
}

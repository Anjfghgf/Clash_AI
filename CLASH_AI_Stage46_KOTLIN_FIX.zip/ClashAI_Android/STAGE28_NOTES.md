# Stage 28 — Battlefield Detector Runtime Foundation

## Implemented
- Added a separate `ArenaDetectorRuntime` using the TensorFlow Lite Interpreter. It does not reuse the player's card-hand classifier.
- Runtime looks for `arena_detector.tflite` and `arena_detector_labels.txt` in Android app assets. The model is optional; without it, the app reports that the detector is unavailable and continues normal capture.
- Validates FLOAT32 input `[1, size, size, 3]`, square image input, a single FLOAT32 YOLO-style output, and output channels matching `4 + label_count`.
- Preprocesses full-frame gameplay images with aspect-preserving letterbox and RGB `[0,1]` input; reverses letterbox coordinates after decoding.
- Runs detection on a bounded set of full-frame snapshots during capture. Candidate boxes are broadcast as `BROAD_OBJECT_CANDIDATE_NOT_CARD_IDENTITY`; ownership remains unconfirmed.
- Added detector label export to the training script so class order is preserved from `dataset_report.json`.

## Not implemented / not claimed
- No trained arena detector weights are bundled. The placeholder label file is not a trained model.
- Generic `troop`, `building`, and `spell_effect` detections do not identify a specific Clash Royale card.
- A box on a screen does not establish ownership. This stage does not automatically add any detector result to the enemy's eight-card deck or elixir estimate.
- The Android model adapter supports one FLOAT32 input and one FLOAT32 YOLO-style output only. Other export shapes, quantized models, or different YOLO output conventions are rejected/not supported.
- Full Gradle/APK build and real-device performance/accuracy tests have not been run in this environment.

## Train and install
1. Collect gameplay recordings/images that you own or have permission to use for model training. Publicly viewable video is not automatically training permission.
2. Manually label full-screen frames using `DETECTION_ANNOTATION_TEMPLATE.csv`. Use one `session_id` per match/recording and label visible objects conservatively. Do not guess hidden/overlapping identities.
3. Prepare and inspect the session-separated dataset:
   `python scripts/prepare_detection_dataset.py --annotations annotations.csv --out arena_dataset`
4. Train/export:
   `python scripts/train_arena_detector.py --data arena_dataset/dataset.yaml --out detector_runs --epochs 80 --imgsz 640`
5. Review `arena_detector_report.json` and `arena_detector_labels.txt`. Confirm the exported model has the exact tensor contract described above.
6. Copy the exported `.tflite` model to `app/src/main/assets/arena_detector.tflite` and the generated labels file to `app/src/main/assets/arena_detector_labels.txt`, then build/install the app.

The broad class order is generated from the dataset and must never be manually reordered independently of the model.

# CLASH AI — Stage 23: Automatic Hand Card Recognition Pipeline

## Added
- Automatic four-slot hand cropping from the live MediaProjection frame; no card tapping or manual selection is needed during gameplay.
- Crops are passed directly to the existing on-device TensorFlow Lite card classifier when a valid trained model is installed.
- Per-slot temporal voting: a card is displayed as stable only after at least 3 matching accepted predictions in the rolling 5-observation window.
- Unknown/low-confidence slots remain `uncertain`; the system does not guess a card name.
- Candidate card crops are saved privately in app cache at a limited rate (at most one four-card set every 10 seconds), capped at 160 images for later labelled training.
- Floating coach and OCR status now include hand-recognition status.

## Critical model status
This ZIP does **not** contain a trained `card_classifier.tflite` or verified labelled hand-card dataset. Therefore the app automatically crops the four expected hand positions, but cannot honestly identify card names until a compatible trained model and `card_labels.txt` are supplied. The runtime contract remains FLOAT32 `[1,224,224,3]`, RGB `[0,1]`, softmax output matching labels.

## Current geometry / limitation
The crop layout assumes portrait Clash Royale gameplay and uses normalized lower-HUD regions. Different screen layouts, aspect ratios, UI scaling, spectator screens, or popups may shift the card row. Validate with actual device captures before training; adjust normalized slot bounds if the crop misses card faces. A future calibration/detector stage should learn the hand row rather than relying permanently on fixed coordinates.

## Verification
- Static integration checks and ZIP integrity checked.
- Pure Kotlin slot-layout smoke test can run without Android dependencies.
- Full Android Gradle/APK build and live-device accuracy are not verified in this environment (no Gradle wrapper / installed Gradle).

## Privacy
Candidate crops stay in the app's private cache and are not uploaded. They may be deleted by Android when cache space is needed.

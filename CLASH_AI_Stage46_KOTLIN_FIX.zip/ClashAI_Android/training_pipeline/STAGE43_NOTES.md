# Stage 43 — Battle Strategy Intelligence

Version: 0.43.0 (versionCode 43)

## Added
- `BattleStrategyEngine.kt` compares defend, counterattack, and wait candidates.
- Candidate scores are explainable rule-based rankings, not learned win probabilities.
- High/medium threat pushes prioritise defence; a detected advancing enemy push blocks counterattack selection.
- Counterattack requires both recognised combo cards in the current hand and sufficient reported elixir.
- Unknown hand/elixir or insufficient battlefield evidence favours waiting.
- Strategy output includes lane focus, next-step guidance, reasons, confidence, and limitations.
- `ScreenCaptureService` includes the strategy summary in the live coach HUD.

## Boundaries
- This stage does not tap the screen, deploy cards, or automate game controls. It provides recommendations for the player to execute.
- It cannot guarantee wins. Scores are heuristic priorities, not win probabilities.
- Exact placement, timing, opponent hand, and unobserved counters remain uncertain.
- Live quality still depends on a trained and installed battlefield detector and reliable hand/elixir readings. No trained detector weights are bundled.
- Normal and Chaos mode use the same battle strategy engine; the selected mode is included in the strategy output.

package com.clashai.coach

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var clock: TextView
    private lateinit var ownValue: TextView
    private lateinit var enemyValue: TextView
    private lateinit var cardsValue: TextView
    private lateinit var coach: TextView
    private lateinit var ocr: TextView
    private val own = ElixirTracker()
    private val enemy = ElixirTracker()
    private val cards = linkedMapOf<String, Int>()
    private var running = false
    private var paused = false
    private var doubleElixir = false
    private lateinit var doubleButton: Button
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() { refresh(); handler.postDelayed(this, 1000) }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val text = intent?.getStringExtra(ScreenCaptureService.EXTRA_TEXT).orEmpty()
            if (text.isNotBlank()) ocr.text = "OCR diagnostic only (not card recognition):\\n$text"
        }
    }

    private val captureLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val service = Intent(this, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_START
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
            }
            ContextCompat.startForegroundService(this, service)
            status.text = "Screen capture active. Card-art recognition is not included yet."
        } else status.text = "Screen capture permission was not granted."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0xFF101827.toInt())
        }
        fun label(s: String, size: Float = 16f) = TextView(this).apply {
            text = s; textSize = size; setTextColor(0xFFFFFFFF.toInt()); setPadding(0, 9, 0, 6)
        }
        fun btn(s: String, action: () -> Unit) = Button(this).apply { text = s; setOnClickListener { action() } }

        root.addView(label("CLASH AI COACH", 26f))
        root.addView(label("Battle tracker • Feature update", 14f))
        status = label("Start a match tracker. Screen capture is optional.")
        root.addView(status)
        root.addView(btn("START / RESET MATCH") { startMatch() })
        root.addView(btn("PAUSE / RESUME") { togglePause() })
        clock = label("Battle time: 00:00", 19f); root.addView(clock)
        doubleButton = btn("DOUBLE ELIXIR: OFF") {
            doubleElixir = !doubleElixir
            doubleButton.text = "DOUBLE ELIXIR: " + if (doubleElixir) "ON" else "OFF"
            refresh()
        }
        root.addView(doubleButton)
        root.addView(label("ELIXIR ESTIMATES", 20f))
        ownValue = label("Your elixir: —", 18f); root.addView(ownValue)
        enemyValue = label("Opponent elixir: —", 18f); root.addView(enemyValue)
        root.addView(label("OPPONENT DECK LOG", 20f))
        root.addView(label("Choose the card when you see the opponent play it."))
        root.addView(btn("LOG OPPONENT CARD") { chooseCard() })
        root.addView(btn("UNDO LAST CARD") { undoCard() })
        cardsValue = label("No confirmed cards yet."); root.addView(cardsValue)
        root.addView(label("COACH", 20f))
        coach = label("Estimates start at 5 elixir and regenerate with time. Opponent card plays improve the estimate when logged.")
        root.addView(coach)
        root.addView(label("LIVE SCREEN ANALYSIS", 20f))
        root.addView(btn("START SCREEN ANALYSIS") { requestCapture() })
        root.addView(btn("STOP SCREEN ANALYSIS") {
            startService(Intent(this, ScreenCaptureService::class.java).setAction(ScreenCaptureService.ACTION_STOP))
            status.text = "Screen analysis stopped."
        })
        ocr = label("OCR diagnostic: waiting for screen capture…", 12f); root.addView(ocr)
        setContentView(ScrollView(this).apply { addView(root) })
        handler.post(ticker)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
    }

    private fun startMatch() {
        own.start(); enemy.start(); cards.clear()
        running = true; paused = false; doubleElixir = false
        doubleButton.text = "DOUBLE ELIXIR: OFF"
        status.text = "Match timer running. Turn on double elixir when that phase begins."
        refresh()
    }
    private fun togglePause() {
        if (!running) { status.text = "Start the match first."; return }
        paused = !paused
        own.setPaused(paused); enemy.setPaused(paused)
        status.text = if (paused) "Match paused." else "Match resumed."
        refresh()
    }
    private fun chooseCard() {
        if (!running) { status.text = "Start the match first."; return }
        val names = CardCatalog.costs.keys.toTypedArray()
        AlertDialog.Builder(this).setTitle("Opponent played which card?")
            .setItems(names) { _, index ->
                val name = names[index]
                cards[name] = (cards[name] ?: 0) + 1
                enemy.spend(CardCatalog.costs[name] ?: 0)
                refresh()
            }.setNegativeButton("Cancel", null).show()
    }
    private fun undoCard() {
        val last = cards.entries.lastOrNull() ?: return
        cards.remove(last.key)
        enemy.refund(CardCatalog.costs[last.key] ?: 0)
        refresh()
    }
    private fun refresh() {
        if (!::clock.isInitialized || !running) return
        val sec = own.elapsedSeconds()
        clock.text = "Battle time: %02d:%02d".format(sec / 60, sec % 60)
        ownValue.text = "Your elixir (time estimate): ${"%.1f".format(Locale.US, own.current(doubleElixir))} / 10"
        enemyValue.text = "Opponent elixir (logged plays): ${"%.1f".format(Locale.US, enemy.current(doubleElixir))} / 10"
        cardsValue.text = if (cards.isEmpty()) "No confirmed cards yet." else cards.entries.joinToString("\\n") {
            "${it.key} × ${it.value}  (${(CardCatalog.costs[it.key] ?: 0) * it.value} elixir)"
        }
        coach.text = if (cards.isEmpty())
            "Opponent elixir is time-based until card plays are logged. The opponent's actual elixir bar is not shown to the app."
        else
            "${cards.size} confirmed card type(s) recorded. This is an observed card log, not yet automatic card-art recognition or a complete 8-card cycle tracker."
    }
    @Suppress("DEPRECATION")
    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(ScreenCaptureService.ACTION_OCR)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(receiver, filter)
    }
    override fun onStop() { runCatching { unregisterReceiver(receiver) }; super.onStop() }
    override fun onDestroy() { handler.removeCallbacks(ticker); super.onDestroy() }
    private fun requestCapture() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        captureLauncher.launch(manager.createScreenCaptureIntent())
    }
}

# Stage 27 — Opponent intelligence foundation

Version: 0.26.0

## Added
- `EnemyBattleIntelligence` keeps a separate opponent play history and eight unique deck slots.
- The automatic observation API accepts only `ARENA_CARD_MODEL` observations with confidence >= 0.90 and requires three matching observations within the recent five-observation window.
- Motion-only tracks and the player's own hand-card classifier are explicitly rejected as evidence for enemy card identity.
- Repeated same-card observations inside a short deployment burst are not counted as multiple plays.
- Tracks the four most recently played enemy cards as temporarily unavailable from the normal hand, while preserving the confirmed play sequence.
- Optional elixir interval calculation requires a caller-supplied starting range and mode-correct regeneration rate. If either is missing, it returns `known=false` rather than guessing.
- Existing manual enemy-card confirmation, undo, clear, and match reset also update the new intelligence history.

## Important integration boundary
The current app does **not** yet have a trained arena-card deployment classifier. The current `CardRecognitionEngine` is trained for card artwork in the player's hand; it must not be applied to battlefield troop sprites and treated as an enemy card identity. Stage 27 therefore adds and tests the evidence gate and opponent-state model, but it does not claim automatic enemy card recognition is live. The existing opponent log remains manually confirmed until a separate arena deployment model is trained and wired to call `observe()`.

No exact enemy elixir value is shown unless the caller supplies a verified starting range and the correct regeneration rate for the current mode/time phase. Unknown remains unknown.

## Verification
- Pure Kotlin smoke test covers rejection of motion-only evidence, 3-vote recognition confirmation, duplicate-burst suppression, deck updates, four-card exclusions, undo/reset, and unknown/known elixir interval behavior.
- Full Android APK build and live-device test are not verified in this environment.

#!/usr/bin/env python3
"""Convert manually labelled full-frame bounding boxes into YOLO detection layout.

Input annotations.csv columns:
image_path,session_id,image_width,image_height,class_name,x_min,y_min,x_max,y_max
Coordinates are pixel coordinates in the original image. Rows are box annotations;
multiple rows may refer to the same image. Only human-reviewed labels are accepted.
"""
import argparse, csv, json, random, shutil
from collections import defaultdict, Counter
from pathlib import Path

REQUIRED = {"image_path", "session_id", "image_width", "image_height", "class_name", "x_min", "y_min", "x_max", "y_max"}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--annotations', required=True, help='CSV with reviewed bounding boxes')
    ap.add_argument('--out', required=True)
    ap.add_argument('--val-fraction', type=float, default=0.2)
    ap.add_argument('--seed', type=int, default=17)
    args = ap.parse_args()
    if not 0.1 <= args.val_fraction <= 0.4: raise SystemExit('val-fraction must be 0.1..0.4')
    source = Path(args.annotations).resolve(); out = Path(args.out).resolve()
    rows = list(csv.DictReader(source.open(newline='', encoding='utf-8')))
    if not rows: raise SystemExit('No annotation rows found')
    missing = REQUIRED - set(rows[0])
    if missing: raise SystemExit(f'Missing columns: {sorted(missing)}')
    classes = sorted({r['class_name'].strip() for r in rows if r['class_name'].strip()})
    if len(classes) < 2: raise SystemExit('At least two labelled classes are required')
    class_to_id = {name:i for i,name in enumerate(classes)}
    images = {}
    for r in rows:
        p = (source.parent / r['image_path']).resolve()
        if not p.is_file(): raise SystemExit(f'Image not found: {p}')
        sid = r['session_id'].strip()
        if not sid: raise SystemExit(f'Missing session_id for {p.name}')
        w,h = int(r['image_width']), int(r['image_height'])
        if w <= 0 or h <= 0: raise SystemExit(f'Invalid dimensions for {p.name}')
        vals = [float(r[k]) for k in ('x_min','y_min','x_max','y_max')]
        x1,y1,x2,y2 = vals
        if not all(v == v and abs(v) != float('inf') for v in vals): raise SystemExit(f'Non-finite box: {p.name}')
        if not (0 <= x1 < x2 <= w and 0 <= y1 < y2 <= h): raise SystemExit(f'Invalid/out-of-frame box: {p.name} {vals}')
        key = str(p)
        entry = images.setdefault(key, {'path':p,'session':sid,'w':w,'h':h,'boxes':[]})
        if (entry['session'],entry['w'],entry['h']) != (sid,w,h): raise SystemExit(f'Conflicting metadata for {p.name}')
        xc=((x1+x2)/2)/w; yc=((y1+y2)/2)/h; bw=(x2-x1)/w; bh=(y2-y1)/h
        entry['boxes'].append((class_to_id[r['class_name'].strip()],xc,yc,bw,bh))
    sessions = sorted({v['session'] for v in images.values()})
    if len(sessions) < 3: raise SystemExit('Need at least 3 independent match/session IDs for train/validation/test separation')
    random.Random(args.seed).shuffle(sessions)
    n_val=max(1, round(len(sessions)*args.val_fraction)); n_test=max(1, round(len(sessions)*0.1))
    if n_val+n_test >= len(sessions): raise SystemExit('Not enough sessions for separate train/validation/test splits')
    val=set(sessions[:n_val]); test=set(sessions[n_val:n_val+n_test]); train=set(sessions[n_val+n_test:])
    split_for=lambda sid: 'val' if sid in val else ('test' if sid in test else 'train')
    if len(train)<1 or len(val)<1 or len(test)<1: raise SystemExit('Empty split; collect more sessions')
    for split in ('train','val','test'):
        (out/'images'/split).mkdir(parents=True,exist_ok=True); (out/'labels'/split).mkdir(parents=True,exist_ok=True)
    counts=Counter(); image_counts=Counter()
    for idx,entry in enumerate(images.values()):
        split=split_for(entry['session']); stem=f"{idx:07d}_{entry['path'].stem}"
        dest=out/'images'/split/(stem+entry['path'].suffix.lower())
        shutil.copy2(entry['path'],dest)
        with (out/'labels'/split/(stem+'.txt')).open('w') as f:
            for cid,xc,yc,bw,bh in entry['boxes']:
                f.write(f'{cid} {xc:.6f} {yc:.6f} {bw:.6f} {bh:.6f}\n'); counts[(split,cid)]+=1
        image_counts[split]+=1
    names={i:n for n,i in class_to_id.items()}
    missing_classes = [(split, names[cid]) for split in ('train','val','test') for cid in range(len(classes)) if counts[(split,cid)] == 0]
    if missing_classes:
        raise SystemExit('Every class must appear in every split; missing: ' + ', '.join(f'{split}/{name}' for split,name in missing_classes) + '. Add more labelled sessions or review the session split.')
    yaml='path: '+str(out).replace('\\','/')+'\ntrain: images/train\nval: images/val\ntest: images/test\nnames:\n'+''.join(f'  {i}: {name!r}\n' for i,name in names.items())
    (out/'dataset.yaml').write_text(yaml,encoding='utf-8')
    report={'classes':names,'sessions':{'train':sorted(train),'val':sorted(val),'test':sorted(test)},'images_by_split':dict(image_counts),'boxes_by_split_class':{f'{s}:{names[c]}':n for (s,c),n in counts.items()},'note':'Splits are grouped by session, but verify each class is represented across all splits before training.'}
    (out/'dataset_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))
if __name__=='__main__': main()

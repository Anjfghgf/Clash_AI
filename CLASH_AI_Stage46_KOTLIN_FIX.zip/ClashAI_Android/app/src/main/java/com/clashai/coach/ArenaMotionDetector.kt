package com.clashai.coach

import android.media.Image
import kotlin.math.abs

/**
 * Lightweight 2D frame-difference detector for the opponent-side arena.
 * It reports moving visual regions only; it does NOT identify troops or cards.
 */
class ArenaMotionDetector(
    private val columns: Int = 72,
    private val rows: Int = 54,
    private val differenceThreshold: Int = 25,
    private val minimumComponentCells: Int = 3
) {
    data class Region(
        val left: Float,
        val top: Float,
        val right: Float,
        val bottom: Float,
        val changedCells: Int
    )

    private var previous: IntArray? = null

    /** Coordinates are normalized to the opponent arena ROI: x 8–92%, y 4–49% of screen. */
    fun analyze(frame: Image): List<Region> {
        val plane = frame.planes.firstOrNull() ?: return emptyList()
        val buffer = plane.buffer.duplicate()
        val sample = IntArray(columns * rows)
        val left = (frame.width * 0.08f).toInt()
        val top = (frame.height * 0.04f).toInt()
        val roiWidth = (frame.width * 0.84f).coerceAtLeast(1f)
        val roiHeight = (frame.height * 0.45f).coerceAtLeast(1f)
        var p = 0
        for (gy in 0 until rows) {
            val y = (top + roiHeight * gy / (rows - 1)).toInt().coerceIn(0, frame.height - 1)
            for (gx in 0 until columns) {
                val x = (left + roiWidth * gx / (columns - 1)).toInt().coerceIn(0, frame.width - 1)
                val offset = y * plane.rowStride + x * plane.pixelStride
                if (offset + 2 >= buffer.limit()) return emptyList()
                val r = buffer.get(offset).toInt() and 0xff
                val g = buffer.get(offset + 1).toInt() and 0xff
                val b = buffer.get(offset + 2).toInt() and 0xff
                sample[p++] = (r * 30 + g * 59 + b * 11) / 100
            }
        }
        val old = previous
        previous = sample
        if (old == null || old.size != sample.size) return emptyList()

        val active = BooleanArray(sample.size)
        var changed = 0
        for (i in sample.indices) {
            if (abs(sample[i] - old[i]) >= differenceThreshold) {
                active[i] = true
                changed++
            }
        }
        // Reject near-static noise and full-screen transitions such as menus/overlays.
        val changedRatio = changed.toFloat() / sample.size
        if (changed < minimumComponentCells || changedRatio < 0.003f || changedRatio > 0.42f) return emptyList()

        val visited = BooleanArray(active.size)
        val queue = IntArray(active.size)
        val regions = mutableListOf<Region>()
        for (start in active.indices) {
            if (!active[start] || visited[start]) continue
            var head = 0
            var tail = 0
            queue[tail++] = start
            visited[start] = true
            var minX = columns
            var minY = rows
            var maxX = -1
            var maxY = -1
            while (head < tail) {
                val index = queue[head++]
                val x = index % columns
                val y = index / columns
                minX = minOf(minX, x); maxX = maxOf(maxX, x)
                minY = minOf(minY, y); maxY = maxOf(maxY, y)
                if (x > 0) {
                    val n = index - 1
                    if (active[n] && !visited[n]) { visited[n] = true; queue[tail++] = n }
                }
                if (x < columns - 1) {
                    val n = index + 1
                    if (active[n] && !visited[n]) { visited[n] = true; queue[tail++] = n }
                }
                if (y > 0) {
                    val n = index - columns
                    if (active[n] && !visited[n]) { visited[n] = true; queue[tail++] = n }
                }
                if (y < rows - 1) {
                    val n = index + columns
                    if (active[n] && !visited[n]) { visited[n] = true; queue[tail++] = n }
                }
            }
            if (tail >= minimumComponentCells && tail <= sample.size / 3) {
                regions.add(Region(
                    left = minX.toFloat() / columns,
                    top = minY.toFloat() / rows,
                    right = (maxX + 1).toFloat() / columns,
                    bottom = (maxY + 1).toFloat() / rows,
                    changedCells = tail
                ))
            }
        }
        return regions.sortedByDescending { it.changedCells }.take(12)
    }

    fun reset() { previous = null }
}

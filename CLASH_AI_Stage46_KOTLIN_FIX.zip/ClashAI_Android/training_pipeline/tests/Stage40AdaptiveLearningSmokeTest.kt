package com.clashai.coach

/** Run with kotlinc DecisionLearningEngine.kt and this file. */
fun main() {
    val engine = DecisionLearningEngine()
    check(engine.adaptiveInsight("NORMAL", "DEFEND").contains("0/3"))
    val weak = "Use defensive option A"
    val strong = "Use defensive option B"
    repeat(3) {
        engine.recordRecommendation("NORMAL", "DEFEND", weak)
        engine.recordConfirmedOutcome(DecisionLearningEngine.Outcome.UNSUCCESSFUL)
    }
    repeat(3) {
        engine.recordRecommendation("NORMAL", "DEFEND", strong)
        engine.recordConfirmedOutcome(DecisionLearningEngine.Outcome.SUCCESS)
    }
    val insight = engine.adaptiveInsight("NORMAL", "DEFEND")
    check(insight.contains("Use defensive option A"))
    check(insight.contains("Use defensive option B"))
    check(engine.adaptiveInsight("CHAOS", "DEFEND").contains("0/3"))
    // Recommendations without feedback must not inflate the confirmed-outcome count.
    engine.recordRecommendation("NORMAL", "DEFEND", "Unrated recommendation")
    check(!engine.adaptiveInsight("NORMAL", "DEFEND").contains("7 confirmed outcomes"))
    println("Stage 40 adaptive learning smoke checks passed")
}

# Stage 22 — Live HUD / Elixir OCR foundation

## Added
- `LiveHudAnalyzer` consumes ML Kit text lines and their screen coordinates.
- It only considers small integer readings (0–10) in the lower-centre HUD region as possible elixir values.
- It distinguishes a single OCR observation from a repeated reading across recent frames.
- The capture service sends a HUD summary to the app and floating coach when a possible elixir value is read.
- The app still displays raw OCR text for diagnosis.

## Important limits
- OCR is not guaranteed to read the elixir number correctly. A repeated reading is still labelled OCR, not ground truth.
- Four hand positions are expected by the game layout, but this stage does **not** identify the four card names. Card artwork has no dependable text label; identification needs a trained visual classifier and validated card-slot crops.
- Enemy elixir is not read from the player's HUD. It remains an estimate from observed enemy plays and regeneration assumptions.
- No automatic card play or game input is performed.

## Validation
- Pure Kotlin smoke test covers lower-centre readings, repeated readings, timer rejection, out-of-range values, and wrong-side rejection.
- Android Gradle/APK build and live-device OCR accuracy are not verified in this environment.

#!/usr/bin/env python3
"""Import manually reviewed frame annotations into the training dataset."""
import argparse,csv,hashlib,json,shutil
from pathlib import Path
from PIL import Image


def main():
 ap=argparse.ArgumentParser()
 ap.add_argument('--queue',type=Path,required=True,help='CSV created by extract_video_frames.py, after manual annotation')
 ap.add_argument('--frames-root',type=Path,required=True,help='The extraction --out folder')
 ap.add_argument('--dataset',type=Path,required=True,help='Prepared dataset folder')
 ap.add_argument('--min-side',type=int,default=32)
 args=ap.parse_args(); imgroot=args.dataset/'images'; imgroot.mkdir(parents=True,exist_ok=True)
 labels=args.dataset/'labels.csv'; fields=['image_path','card_id','card_name','session_id','elixir_cost','rarity']
 existing=list(csv.DictReader(labels.open(encoding='utf-8-sig'))) if labels.exists() else []
 seen={(r['session_id'],r['card_id'],Path(r['image_path']).name) for r in existing}
 added=0; skipped=[]
 for row in csv.DictReader(args.queue.open(encoding='utf-8-sig')):
  try:
   cid=int(row.get('card_id','')); name=row.get('card_name','').strip(); sid=row.get('session_id','').strip()
   if not name or not sid: raise ValueError('missing manual card_id/card_name/session_id')
   src=(args.frames_root/row['image_path']).resolve()
   if not src.is_file(): raise ValueError('image not found')
   im=Image.open(src).convert('RGB')
   if min(im.size)<args.min_side: raise ValueError('image too small')
   digest=hashlib.sha256(src.read_bytes()).hexdigest(); target=imgroot/str(cid)/f'{sid}_{digest[:16]}.jpg'
   target.parent.mkdir(parents=True,exist_ok=True)
   if target.exists(): continue
   im.save(target,'JPEG',quality=94)
   existing.append({'image_path':str(target.relative_to(args.dataset)),'card_id':cid,'card_name':name,
       'session_id':sid,'elixir_cost':'','rarity':''}); added+=1
  except Exception as e: skipped.append({'image_path':row.get('image_path','?'),'reason':str(e)})
 with labels.open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(existing)
 (args.dataset/'annotation_import_report.json').write_text(json.dumps({'added':added,'skipped':skipped},indent=2))
 print(json.dumps({'added':added,'skipped':len(skipped)},indent=2))
if __name__=='__main__': main()

package com.clashai.coach
class BattlefieldStateModel { enum class Side { FRIENDLY, ENEMY, UNKNOWN }; enum class Lane { LEFT, RIGHT, CENTER, UNKNOWN }; enum class Movement { TOWARD_TOP, TOWARD_BOTTOM, MOSTLY_STATIONARY, UNKNOWN } }
class BattlefieldUnderstandingEngine {
 enum class ObjectKind { TROOP, BUILDING, SPELL_EFFECT, UNKNOWN }; enum class TroopDomain { AIR, GROUND, UNKNOWN }
 data class TrackedObject(val trackId:Int,val label:String,val kind:ObjectKind,val troopDomain:TroopDomain,val side:BattlefieldStateModel.Side,val lane:BattlefieldStateModel.Lane,val movement:BattlefieldStateModel.Movement,val confidence:Float,val identityConfirmed:Boolean,val centerX:Float,val centerY:Float,val towerProximity:String)
}

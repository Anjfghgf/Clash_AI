package com.clashai.coach

fun main() {
    val engine = TacticalCombinationEngine(CardStrategyEngine())
    val mode = GameModeIntelligence.Mode.CHAOS
    val affordable = engine.recommendAttack(
        hand = listOf("Hog Rider", "Musketeer", "Fireball"),
        elixir = 8,
        knownEnemyDeck = emptyList(),
        mode = mode
    )
    check(affordable != null)
    check(affordable.totalCost <= 8)
    check(engine.recommendAttack(listOf("Hog Rider", "Musketeer"), 7, emptyList(), mode) == null)
    check(engine.recommendAttack(listOf("Hog Rider", "Musketeer"), null, emptyList(), mode) == null)
    println("Stage 30 tactical combination smoke checks passed")
}

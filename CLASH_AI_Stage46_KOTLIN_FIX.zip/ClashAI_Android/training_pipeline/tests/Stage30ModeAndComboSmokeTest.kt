package com.clashai.coach

fun main() {
    val modes = GameModeIntelligence()
    check(modes.profile(GameModeIntelligence.Mode.NORMAL).deckIsFixedEight)
    check(modes.profile(GameModeIntelligence.Mode.CHAOS).deckIsFixedEight)
    check(modes.profile(GameModeIntelligence.Mode.DRAFT).deckIsFixedEight)
    check(modes.profile(GameModeIntelligence.Mode.TWO_V_TWO).deckIsFixedEight)
    check(modes.profile(GameModeIntelligence.Mode.SUDDEN_DEATH).deckIsFixedEight)
    check(modes.profile(GameModeIntelligence.Mode.DOUBLE_ELIXIR).elixirRateMultiplier == 2.0)
    check(modes.profile(GameModeIntelligence.Mode.UNKNOWN).elixirRateMultiplier == null)

    val tracker = EnemyDeckTracker()
    tracker.setStandardDeckRules(false) // legacy call cannot disable the universal 8-card rule
    (1..10).forEach { tracker.record("Card$it") }
    check(tracker.confirmedCards().size == 8)
    check(tracker.cycleStatus().contains("Four-card cycle"))
    val standard = EnemyDeckTracker()
    (1..10).forEach { standard.record("Card$it") }
    check(standard.confirmedCards().size == 8)
    check(standard.isFull())

    val pick = modes.recommendDraftPick(listOf("Musketeer", "Hog Rider", "Knight"), listOf("Knight", "Valkyrie")) { card ->
        when (card) {
            "Musketeer" -> setOf(CardStrategyEngine.Role.ANTI_AIR, CardStrategyEngine.Role.SUPPORT)
            "Hog Rider" -> setOf(CardStrategyEngine.Role.WIN_CONDITION)
            "Knight" -> setOf(CardStrategyEngine.Role.SUPPORT)
            else -> setOf(CardStrategyEngine.Role.UNKNOWN)
        }
    }
    check(pick != null)
    check(pick!!.card == "Musketeer" || pick.card == "Hog Rider")
    check(modes.recommendDraftPick(listOf("Archer", "Knight"), (1..8).map { "Chosen$it" }) { setOf(CardStrategyEngine.Role.SUPPORT) } == null)
    val parsed = ChaosDraftFileParser.extractKnownCards("Hog Rider, Musketeer, Unknown Card", listOf("Hog Rider", "Musketeer", "Knight"))
    check(parsed == listOf("Hog Rider", "Musketeer"))
    val intelligence = EnemyBattleIntelligence()
    (1..10).forEach { intelligence.recordConfirmed("Card$it", it * 3000L) }
    check(intelligence.confirmedDeck().size == 8)
    check(intelligence.currentHandExclusions().isNotEmpty())
    intelligence.setStandardDeckRules(false) // legacy call cannot disable the universal 8-card rule
    check(intelligence.confirmedDeck().size == 8)
    check(intelligence.currentHandExclusions().isNotEmpty())
    check(intelligence.summary().contains("/8 unique cards confirmed"))
    println("Stage 30 mode and deck-rule smoke checks passed")
}

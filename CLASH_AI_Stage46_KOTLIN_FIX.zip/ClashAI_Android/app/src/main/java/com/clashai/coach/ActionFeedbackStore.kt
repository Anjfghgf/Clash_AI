package com.clashai.coach

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** App-private persistence for Stage 45 action feedback. */
class ActionFeedbackStore(context: Context) {
    private val prefs = context.getSharedPreferences("clash_ai_action_feedback", Context.MODE_PRIVATE)
    private val engine = ActionFeedbackEngine()
    init { load() }

    @Synchronized fun recordRecommendation(mode: String, action: String, card: String?, lane: String) {
        engine.recordRecommendation(mode, action, card, lane); save()
    }
    @Synchronized fun recordOutcome(outcome: ActionFeedbackEngine.Outcome): Boolean {
        val accepted = engine.recordOutcome(outcome)
        if (accepted) save()
        return accepted
    }
    @Synchronized fun summary(mode: String) = engine.summary(mode)

    private fun save() {
        val a = JSONArray()
        engine.snapshot().forEach { (k, s, pending) ->
            a.put(JSONObject().put("mode", k.mode).put("action", k.action).put("card", k.card).put("lane", k.lane)
                .put("recommendations", s.recommendations).put("success", s.success).put("neutral", s.neutral)
                .put("unsuccessful", s.unsuccessful).put("pending", pending))
        }
        prefs.edit().putString("records", a.toString()).apply()
    }
    private fun load() {
        val a = runCatching { JSONArray(prefs.getString("records", "[]")) }.getOrNull() ?: return
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            engine.restore(ActionFeedbackEngine.Key(o.optString("mode", "UNKNOWN"), o.optString("action", "UNKNOWN"),
                o.optString("card", "NONE"), o.optString("lane", "UNKNOWN")),
                ActionFeedbackEngine.Stats(o.optInt("recommendations"), o.optInt("success"), o.optInt("neutral"), o.optInt("unsuccessful")),
                o.optBoolean("pending"))
        }
    }
}

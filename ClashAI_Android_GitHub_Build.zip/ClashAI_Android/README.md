# CLASH AI Coach

Android companion app for Clash Royale battle coaching.

## Current features
- Bundled Clash Royale card catalogue and card costs where known.
- Manual enemy-card log and player-hand selection.
- Approximate match timer and elixir estimates.
- Basic counter/attack coaching.
- User-approved Android MediaProjection screen capture with a persistent foreground notification.
- On-device OCR diagnostics.
- Experimental opponent-arena visual-change detector. It samples a small grayscale grid from the upper arena region and flags large changes as possible deployment/activity events.

## Important recognition limitation
The visual-change detector is **not yet a card identity classifier**. It can flag likely activity in the opponent-side arena, but it cannot reliably tell whether the unit is Knight, Hog Rider, etc. The current app asks the player to confirm the card in the manual tracker. Accurate card naming requires a trained on-device image-classification/object-detection model and representative labelled gameplay frames. Do not treat visual-change alerts as confirmed enemy plays.

## Screen capture and privacy
- Screen capture starts only after the player taps Start Screen Analysis and accepts Android's system permission prompt.
- Capture is processed on-device; frames are sampled for visual change and OCR diagnostics and are not uploaded by this app.
- A persistent notification indicates that screen analysis is active.
- Tap Stop Screen Analysis to end capture.

## Build
Open the `ClashAI_Android` folder in Android Studio or run `gradle --no-daemon assembleDebug` from this folder with Android SDK configured.

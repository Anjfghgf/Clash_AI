package com.clashai.coach

fun main() {
    val upper = listOf("Knight", "Archers")
    val lower = listOf("Giant", "Fireball")

    val unknown = ChaosDraftScreenMapping.fromStored("")
    check(!unknown.isCalibrated)
    check(unknown.map(upper, lower).ourCards.isEmpty())
    check(unknown.map(upper, lower).opponentCards.isEmpty())

    val upperIsOurs = ChaosDraftScreenMapping.fromStored("UPPER")
    val upperMapped = upperIsOurs.map(upper, lower)
    check(upperMapped.ourCards == upper)
    check(upperMapped.opponentCards == lower)

    val lowerIsOurs = ChaosDraftScreenMapping.fromStored("LOWER")
    val lowerMapped = lowerIsOurs.map(upper, lower)
    check(lowerMapped.ourCards == lower)
    check(lowerMapped.opponentCards == upper)

    val invalid = ChaosDraftScreenMapping.fromStored("SIDEWAYS")
    check(!invalid.isCalibrated)
    check(invalid.map(upper, lower).opponentCards.isEmpty())

    println("Stage 34 Chaos draft calibration smoke checks passed")
}

package com.clashai.coach

/** Tracks only manually confirmed enemy card plays. Unknown predictions never fill deck slots. */
class EnemyDeckTracker {
    data class Slot(val card: String, val firstSeenPlay: Int, val plays: Int)

    private val plays = mutableListOf<String>()
    private val confirmed = linkedMapOf<String, Int>()
    private val maxDeckSize = 8
    private var fixedEightCardDeck = true

    @Suppress("UNUSED_PARAMETER")
    fun setStandardDeckRules(enabled: Boolean) {
        // Every supported Clash Royale mode in this project uses an eight-card deck.
        // Keep the argument for compatibility with older callers, but never disable the cap.
        if (fixedEightCardDeck) return
        fixedEightCardDeck = true
        rebuild()
    }

    fun record(card: String): Boolean {
        plays.add(card)
        if (!confirmed.containsKey(card) && (!fixedEightCardDeck || confirmed.size < maxDeckSize)) {
            confirmed[card] = plays.lastIndex
            return true
        }
        return confirmed.containsKey(card)
    }

    fun undo(): Boolean {
        if (plays.isEmpty()) return false
        plays.removeAt(plays.lastIndex)
        rebuild()
        return true
    }

    fun clear() { plays.clear(); confirmed.clear() }

    private fun rebuild() {
        confirmed.clear()
        plays.forEachIndexed { index, card -> if (!fixedEightCardDeck || confirmed.size < maxDeckSize) confirmed.putIfAbsent(card, index) }
    }

    fun confirmedCards(): List<String> = confirmed.keys.toList()
    fun playCount(): Int = plays.size
    fun isFull(): Boolean = fixedEightCardDeck && confirmed.size == maxDeckSize
    fun overflowCards(): List<String> = if (fixedEightCardDeck) plays.distinct().drop(maxDeckSize) else emptyList()

    /** A card cycles back after four other cards have been played; repeated cards count as plays. */
    fun cycleStatus(): String {
        if (!fixedEightCardDeck) return "Card cycle: waiting for confirmed plays."
        if (plays.isEmpty()) return "Cycle: waiting for confirmed plays."
        val latestUse = confirmed.keys.mapNotNull { card ->
            val index = plays.indexOfLast { it == card }
            if (index < 0) null else card to (plays.lastIndex - index)
        }
        return "Four-card cycle (estimated):\n" + latestUse.joinToString("\n") { (card, since) ->
            val remaining = (4 - since).coerceAtLeast(0)
            if (remaining == 0) "$card: may be back in hand" else "$card: $remaining play(s) until return"
        }
    }

    fun deckSummary(): String {
        if (!fixedEightCardDeck) return "Confirmed opponent cards (${confirmed.size}/8):\n" + confirmed.keys.joinToString(" · ").ifBlank { "No confirmed cards yet" }
        val slots = (1..maxDeckSize).mapIndexed { index, _ ->
            val card = confirmed.keys.elementAtOrNull(index)
            "${index + 1}. ${card ?: "Unknown"}"
        }
        return "Confirmed enemy deck (${confirmed.size}/8):\n" + slots.joinToString("   •   ")
    }
}

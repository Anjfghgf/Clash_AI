# Stage 49 — Remote AI Coach foundation

- Added Android INTERNET permission and a remote client that posts compact match state to a configurable backend.
- The remote request is rate-limited to one per seven seconds and contains no screenshot/video and no OpenAI API key.
- The returned advice is appended to the floating coach overlay. Existing local decision logic remains active if the backend is not configured or unavailable.
- Added a Flask/OpenAI Responses API backend under `remote_ai_server/`.
- Configure `CLASH_AI_SERVER_URL` and optional `CLASH_AI_APP_TOKEN` as Gradle project properties; configure `OPENAI_API_KEY` only on the backend host.
- This is an integration foundation, not a claim that recognition models are trained or that live gameplay has been validated. The Stage 48 notes already document that a full Android build was not run.

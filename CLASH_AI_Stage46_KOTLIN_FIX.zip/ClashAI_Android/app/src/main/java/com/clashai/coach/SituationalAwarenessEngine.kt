package com.clashai.coach

import kotlin.math.abs
import kotlin.math.hypot

/** Stage 42: conservative group-level battlefield interpretation. This is not pathfinding. */
class SituationalAwarenessEngine(
    private val clusterRadius: Float = 0.22f,
    private val supportRadius: Float = 0.24f
) {
    enum class Pressure { UNKNOWN, LOW, MEDIUM, HIGH }

    data class Group(
        val side: BattlefieldStateModel.Side,
        val lane: BattlefieldStateModel.Lane,
        val troopCount: Int,
        val buildingCount: Int,
        val spellEffectCount: Int,
        val movingTowardBottom: Int,
        val movingTowardTop: Int,
        val averageConfidence: Float,
        val centerX: Float,
        val centerY: Float,
        val hasNearbyBuilding: Boolean
    )

    data class Assessment(
        val groups: List<Group>,
        val enemyPush: String,
        val friendlyFormation: String,
        val lanePressure: String,
        val pressure: Pressure,
        val interactionNotes: List<String>,
        val explanation: String
    ) {
        fun render(): String = buildString {
            append("SITUATIONAL AWARENESS: ${groups.size} group(s) identified\n")
            append("ENEMY PUSH: $enemyPush\nFRIENDLY FORMATION: $friendlyFormation\n")
            append("COMBINED LANE PRESSURE: $lanePressure · $pressure\n")
            if (interactionNotes.isNotEmpty()) append("UNIT INTERACTIONS: ${interactionNotes.joinToString("; ")}\n")
            append("WHY: $explanation\nGroupings are spatial estimates, not confirmed tactical roles.")
        }
    }

    @Synchronized
    fun evaluate(objects: List<BattlefieldUnderstandingEngine.TrackedObject>): Assessment {
        val usable = objects.filter {
            it.side != BattlefieldStateModel.Side.UNKNOWN &&
                it.lane != BattlefieldStateModel.Lane.UNKNOWN &&
                it.confidence >= 0.60f &&
                it.kind != BattlefieldUnderstandingEngine.ObjectKind.UNKNOWN
        }
        val groups = mutableListOf<Group>()
        val remaining = usable.toMutableList()
        while (remaining.isNotEmpty()) {
            val seed = remaining.removeAt(0)
            val members = mutableListOf(seed)
            var changed = true
            while (changed) {
                changed = false
                val cx = members.map { it.centerX }.average().toFloat()
                val cy = members.map { it.centerY }.average().toFloat()
                val candidate = remaining.firstOrNull { item ->
                    item.side == seed.side && item.lane == seed.lane &&
                        hypot(item.centerX - cx, item.centerY - cy) <= clusterRadius
                }
                if (candidate != null) {
                    members += candidate
                    remaining.remove(candidate)
                    changed = true
                }
            }
            val troops = members.filter { it.kind == BattlefieldUnderstandingEngine.ObjectKind.TROOP }
            val buildings = members.count { it.kind == BattlefieldUnderstandingEngine.ObjectKind.BUILDING }
            val effects = members.count { it.kind == BattlefieldUnderstandingEngine.ObjectKind.SPELL_EFFECT }
            val cx = members.map { it.centerX }.average().toFloat()
            val cy = members.map { it.centerY }.average().toFloat()
            val nearbyBuilding = usable.any { b ->
                b.side == seed.side && b.lane == seed.lane &&
                    b.kind == BattlefieldUnderstandingEngine.ObjectKind.BUILDING &&
                    hypot(b.centerX - cx, b.centerY - cy) <= supportRadius
            }
            groups += Group(
                seed.side, seed.lane, troops.size, buildings, effects,
                troops.count { it.movement == BattlefieldStateModel.Movement.TOWARD_BOTTOM },
                troops.count { it.movement == BattlefieldStateModel.Movement.TOWARD_TOP },
                members.map { it.confidence }.average().toFloat(), cx, cy, nearbyBuilding
            )
        }

        val enemyGroups = groups.filter { it.side == BattlefieldStateModel.Side.ENEMY && it.troopCount > 0 }
        val friendlyGroups = groups.filter { it.side == BattlefieldStateModel.Side.FRIENDLY && it.troopCount > 0 }
        val advancing = enemyGroups.filter { it.movingTowardBottom > 0 }
        val strongest = advancing.maxByOrNull { it.troopCount }
        val push = when {
            strongest == null -> "No grouped advancing enemy push confirmed."
            strongest.troopCount >= 3 -> "Possible ${strongest.lane.name.lowercase()}-lane group push (${strongest.troopCount} tracked troops); verify visually."
            strongest.troopCount >= 2 -> "Possible ${strongest.lane.name.lowercase()}-lane developing push (${strongest.troopCount} tracked troops)."
            else -> "One enemy troop is moving toward your side; a coordinated push is not established."
        }
        val friendlyText = when {
            friendlyGroups.isEmpty() -> "No friendly troop group confidently identified."
            friendlyGroups.any { it.troopCount >= 2 } -> "Friendly troop group(s) detected: ${friendlyGroups.filter { it.troopCount >= 2 }.joinToString { "${it.lane.name.lowercase()} (${it.troopCount})" }}."
            else -> "Friendly troop activity detected, but no multi-troop formation confirmed."
        }
        val lanePressure = advancing.groupBy { it.lane }.entries
            .sortedByDescending { entry -> entry.value.sumOf { it.troopCount } }
            .joinToString(" · ") { (lane, laneGroups) -> "${lane.name.lowercase()}: ${laneGroups.sumOf { it.troopCount }} troop(s)" }
            .ifBlank { "No lane has confirmed grouped advancing pressure." }
        val pressure = when {
            advancing.any { it.troopCount >= 3 } || advancing.sumOf { it.troopCount } >= 4 -> Pressure.HIGH
            advancing.any { it.troopCount >= 2 } -> Pressure.MEDIUM
            advancing.isNotEmpty() -> Pressure.LOW
            else -> if (enemyGroups.isEmpty()) Pressure.UNKNOWN else Pressure.LOW
        }
        val interactions = mutableListOf<String>()
        groups.filter { it.troopCount > 0 && it.hasNearbyBuilding }.forEach {
            interactions += "${it.side.name.lowercase()} ${it.lane.name.lowercase()} troops are near a detected building (possible defensive support)"
        }
        if (enemyGroups.any { e -> friendlyGroups.any { f -> f.lane == e.lane } }) {
            interactions += "Friendly and enemy troop groups appear in the same lane; compare their positions before committing"
        }
        if (groups.any { it.spellEffectCount > 0 }) {
            interactions += "Spell/effect detections are present; their owner and exact effect remain unconfirmed"
        }
        val explanation = when {
            usable.isEmpty() -> "No sufficiently confident, side-and-lane-assigned detector objects are available."
            advancing.isEmpty() -> "No enemy troop group has a repeated spatial cluster with a downward movement observation."
            else -> "Assessment uses ${advancing.sumOf { it.troopCount }} advancing enemy troop track(s) across ${advancing.size} group(s); confidence is limited by broad detector labels and approximate clustering."
        }
        return Assessment(groups, push, friendlyText, lanePressure, pressure, interactions.distinct(), explanation)
    }
}

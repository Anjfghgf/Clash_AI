# Stage 21 — Live Gameplay Floating Coach

## Goal
Make the existing screen-analysis service useful while the player switches from CLASH AI to Clash Royale. A compact, movable Android overlay can remain visible over the game and receive updates directly from the foreground screen-capture service.

## Added
- `FloatingCoachOverlay.kt`: movable `TYPE_APPLICATION_OVERLAY` panel with a dark readable background, bounded width, and main-thread-safe text updates.
- `SYSTEM_ALERT_WINDOW` manifest permission declaration. Android still requires the user to grant the special "Display over other apps" permission in system settings.
- Main screen controls to enable or hide the floating coach. The enable button opens Android's overlay-permission settings when needed and resumes enabling after the user returns.
- The screen-capture service handles show, hide, and update actions.
- The capture service itself updates the overlay from its frame-analysis thread on a throttled interval. This is important because the Activity receiver is unregistered when the user switches to Clash Royale; the overlay therefore does not depend on the Activity remaining visible.
- The overlay currently gives conservative observation-based status messages: scanning, possible persistent activity, or possible transient visual effects. It explicitly warns that visual tracks are not confirmed troop identities.

## How to try it on Android
1. Install the Stage 21 APK built from this project (APK build still needs to be run in Android Studio/Gradle).
2. Open CLASH AI and tap **ENABLE FLOATING COACH**.
3. Grant **Display over other apps** in Android settings and return to CLASH AI.
4. Tap **START SCREEN ANALYSIS** and approve Android's screen-capture prompt.
5. Switch to Clash Royale. The foreground capture notification should remain visible, and the floating panel should update when the capture service observes battlefield changes.
6. Drag the panel to move it. Return to CLASH AI and tap **HIDE FLOATING COACH** or **STOP SCREEN ANALYSIS** when finished.

## Important limitations
- Android requires explicit user permission for both screen capture and displaying over other apps. The app does not bypass either permission.
- This stage provides an on-screen coach panel, not automatic card placement or gameplay control. The user remains in control of every move.
- The panel currently reports conservative motion-pattern observations. It does not yet have a trained battlefield object detector, reliable troop identity, automatic lane/target recognition, or a trained strategic policy. It must not claim a specific troop from a motion track.
- Existing recognition still requires a separately trained compatible `card_classifier.tflite`; no trained model is bundled.
- Capture rate and overlay update frequency are throttled to reduce overhead. Device performance, Android version, game resolution, and battery use need real-device testing.
- Some Android devices or game modes may restrict overlays. The panel can be hidden at any time, and the screen-analysis service can be stopped from CLASH AI.

## Verification performed for this source package
- Manifest XML parsed successfully.
- Kotlin source integration and action names checked for consistency.
- Project archive integrity checked after packaging.
- Full Android Gradle/APK build and live gameplay test were not run in this environment.

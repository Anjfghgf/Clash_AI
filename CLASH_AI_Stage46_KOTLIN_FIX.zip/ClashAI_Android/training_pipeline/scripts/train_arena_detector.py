#!/usr/bin/env python3
"""Train a YOLO detector on a reviewed, session-separated dataset and export TFLite."""
import argparse, json
from pathlib import Path

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--data',required=True,help='dataset.yaml created by prepare_detection_dataset.py')
    ap.add_argument('--out',required=True)
    ap.add_argument('--model',default='yolo11n.pt',help='Use a model whose weights/licence permit your use')
    ap.add_argument('--epochs',type=int,default=80)
    ap.add_argument('--imgsz',type=int,default=640)
    ap.add_argument('--batch',type=int,default=8)
    ap.add_argument('--device',default='')
    args=ap.parse_args()
    data=Path(args.data).resolve(); out=Path(args.out).resolve(); out.mkdir(parents=True,exist_ok=True)
    if not data.is_file(): raise SystemExit(f'Dataset YAML not found: {data}')
    report=data.parent/'dataset_report.json'
    if not report.is_file(): raise SystemExit('dataset_report.json missing; prepare the dataset first')
    r=json.loads(report.read_text())
    if min(r['images_by_split'].get(k,0) for k in ('train','val','test')) < 1: raise SystemExit('Train/val/test splits must all contain images')
    from ultralytics import YOLO
    model=YOLO(args.model)
    result=model.train(data=str(data),epochs=args.epochs,imgsz=args.imgsz,batch=args.batch,project=str(out),name='arena_detector',device=args.device or None,patience=20,plots=True)
    best=Path(result.save_dir)/'weights'/'best.pt'
    if not best.is_file(): raise SystemExit('Training finished but best.pt was not found')
    trained=YOLO(str(best))
    metrics=trained.val(data=str(data),split='test',imgsz=args.imgsz)
    export=trained.export(format='tflite',imgsz=args.imgsz,half=False,int8=False)
    classes = r['classes']
    ordered_labels = [classes[str(i)] if str(i) in classes else classes[i] for i in range(len(classes))]
    (out/'arena_detector_labels.txt').write_text('\n'.join(ordered_labels)+'\n', encoding='utf-8')
    report_out={'best_weights':str(best),'tflite_export':str(export),'labels_file':str(out/'arena_detector_labels.txt'),'test_metrics':{'map50':float(metrics.box.map50),'map50_95':float(metrics.box.map),'precision':float(metrics.box.mp),'recall':float(metrics.box.mr)},'input_size':args.imgsz,'classes':r['classes'],'warning':'Check exported TFLite tensor shapes and coordinate convention against the Android adapter before bundling.'}
    (out/'arena_detector_report.json').write_text(json.dumps(report_out,indent=2))
    print(json.dumps(report_out,indent=2))
if __name__=='__main__': main()

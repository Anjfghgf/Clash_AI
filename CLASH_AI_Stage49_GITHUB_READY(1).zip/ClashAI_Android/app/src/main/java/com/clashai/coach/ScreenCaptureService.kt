package com.clashai.coach

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Bitmap
import java.io.File
import java.io.FileOutputStream
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import org.json.JSONArray
import org.json.JSONObject
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class ScreenCaptureService : Service() {
    companion object {
        const val ACTION_START = "com.clashai.coach.START"
        const val ACTION_STOP = "com.clashai.coach.STOP"
        const val ACTION_OCR = "com.clashai.coach.OCR"
        const val ACTION_SHOW_COACH = "com.clashai.coach.SHOW_COACH"
        const val ACTION_HIDE_COACH = "com.clashai.coach.HIDE_COACH"
        const val ACTION_UPDATE_COACH = "com.clashai.coach.UPDATE_COACH"
        const val ACTION_RELOAD_MODEL = "com.clashai.coach.RELOAD_MODEL"
        const val ACTION_RECORD_STRATEGY_OUTCOME = "com.clashai.coach.RECORD_STRATEGY_OUTCOME"
        const val ACTION_RECORD_LEARNING_OUTCOME = "com.clashai.coach.RECORD_LEARNING_OUTCOME"
        const val ACTION_RECORD_ACTION_FEEDBACK = "com.clashai.coach.RECORD_ACTION_FEEDBACK"
        const val EXTRA_ACTION_FEEDBACK = "action_feedback"
        const val EXTRA_LEARNING_OUTCOME = "learning_outcome"
        const val ACTION_UPDATE_STRATEGY_CONTEXT = "com.clashai.coach.UPDATE_STRATEGY_CONTEXT"
        const val ACTION_SET_GAME_MODE = "com.clashai.coach.SET_GAME_MODE"
        const val EXTRA_GAME_MODE = "game_mode"
        const val EXTRA_STRATEGY_ENEMY_CARD = "strategy_enemy_card"
        const val EXTRA_STRATEGY_ENEMY_DECK = "strategy_enemy_deck"
        const val EXTRA_STRATEGY_HAND = "strategy_hand"
        const val EXTRA_STRATEGY_ELIXIR = "strategy_elixir"
        const val EXTRA_STRATEGY_MODE = "strategy_mode"
        const val EXTRA_STRATEGY_MATCHUP = "strategy_matchup"
        const val EXTRA_STRATEGY_CARD = "strategy_card"
        const val EXTRA_STRATEGY_SUCCESS = "strategy_success"
        const val EXTRA_COACH_MESSAGE = "coach_message"
        const val ACTION_DEPLOYMENT_CANDIDATE = "com.clashai.coach.DEPLOYMENT_CANDIDATE"
        const val EXTRA_TEXT = "recognized_text"
        const val EXTRA_SNAPSHOT_PATH = "snapshot_path"
        const val EXTRA_MOTION_REGIONS = "motion_regions"
        const val EXTRA_MOTION_TRACKS = "motion_tracks"
        const val EXTRA_TRACK_CROPS = "track_crops"
        const val EXTRA_TRACK_RECOGNITIONS = "track_recognitions"
        const val EXTRA_BATTLEFIELD_ANALYSIS = "battlefield_analysis"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "clash_ai_capture"
        private const val NOTIFICATION_ID = 401
        const val EXTRA_HUD_SUMMARY = "hud_summary"
        const val EXTRA_ARENA_DETECTIONS = "arena_detections"
        const val EXTRA_BATTLEFIELD_SUMMARY = "battlefield_summary"
        const val EXTRA_ENEMY_INTELLIGENCE_SUMMARY = "enemy_intelligence_summary"
        const val EXTRA_SCREEN_PHASE = "screen_phase"
        const val EXTRA_SCREEN_PHASE_REASON = "screen_phase_reason"
        const val EXTRA_DRAFT_CARDS = "draft_detected_cards"
        const val EXTRA_DRAFT_UPPER_CARDS = "draft_upper_candidates"
        const val EXTRA_DRAFT_LOWER_CARDS = "draft_lower_candidates"
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var lastFrameAt = 0L
    private var lastOcrAt = 0L
    private val motionDetector = ArenaMotionDetector()
    private val objectTracker = ArenaObjectTracker()
    private val recognitionVerifier = TrackRecognitionVerifier()
    private val battlefieldClassifier = BattlefieldObjectClassifier()
    private val liveHudAnalyzer = LiveHudAnalyzer()
    private val gameScreenModeDetector = GameScreenModeDetector()
    private val chaosDraftAutoPilot = ChaosDraftAutoPilot()
    private var latestScreenPhase = GameScreenModeDetector.Phase.UNKNOWN
    private var latestDraftCandidates: List<String> = emptyList()
    private val liveDecisionEngine = BattleDecisionEngine()
    private lateinit var cardStrategyEngine: CardStrategyEngine
    private lateinit var decisionLearningStore: DecisionLearningStore
    private lateinit var actionFeedbackStore: ActionFeedbackStore
    private lateinit var tacticalCombinationEngine: TacticalCombinationEngine
    private val gameModeIntelligence = GameModeIntelligence()
    private var selectedGameMode = GameModeIntelligence.Mode.NORMAL
    private var latestArenaObjectLabels: List<String> = emptyList()
    private var latestConfirmedEnemyCard: String? = null
    private var latestConfirmedEnemyDeck: List<String> = emptyList()
    private var latestManualHand: List<String> = emptyList()
    private var latestManualElixir: Int? = null
    private var latestHandResult: HandCardAnalyzer.HandResult? = null
    private var latestPersistentTrackCount = 0
    private var latestMotionCandidateCount = 0
    private var latestTransientEffectCount = 0
    private var handCardAnalyzer: HandCardAnalyzer? = null
    private var latestHandSummary = "HAND: waiting for screen analysis"
    private var latestTacticalSummary = "TACTICAL ADVICE: waiting for confirmed hand and elixir readings"
    private var recognitionEngine: CardRecognitionEngine? = null
    private var arenaDetector: ArenaDetectorRuntime? = null
    private var enemyCardDetector: ArenaDetectorRuntime? = null
    private var latestEnemyCardModelSummary = "ENEMY CARD MODEL: not installed"
    private val battlefieldUnderstanding = BattlefieldUnderstandingEngine()
    private val realtimeGameplayIntelligence = RealtimeGameplayIntelligence()
    @Volatile private var recommendedBattlefieldRefreshMs = 1_900L
    private val tacticalDecisionPlanner = TacticalDecisionPlanner()
    private val matchPredictionEngine = MatchPredictionEngine()
    private val situationalAwarenessEngine = SituationalAwarenessEngine()
    private val battleStrategyEngine = BattleStrategyEngine()
    private val playerActionPlanEngine = PlayerActionPlanEngine()
    private var latestBattlefieldSnapshot: BattlefieldUnderstandingEngine.Snapshot? = null
    private val enemyIntelligencePipeline = EnemyIntelligencePipeline()
    private var latestEnemyIntelligenceSummary = "ENEMY INTELLIGENCE: waiting for confirmed card identities"
    private var latestEnemyElixirLow: Double? = null
    private var latestEnemyElixirHigh: Double? = null
    private var latestBattlefieldSummary = "BATTLEFIELD: waiting for full-frame observations"
    private var latestArenaDetectionSummary = "ARENA DETECTOR: model not installed"
    private var lastCandidateAt = 0L
    private var lastOverlayUpdateAt = 0L
    private var floatingCoach: FloatingCoachOverlay? = null
    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() { stopCapture() }
    }
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopCapture()
            ACTION_SHOW_COACH -> {
                if (Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(this)) {
                    if (floatingCoach == null) floatingCoach = FloatingCoachOverlay(this)
                    floatingCoach?.show()
                }
            }
            ACTION_HIDE_COACH -> floatingCoach?.hide()
            ACTION_UPDATE_COACH -> intent.getStringExtra(EXTRA_COACH_MESSAGE)?.let { floatingCoach?.update(it) }
            ACTION_RELOAD_MODEL -> reloadRecognitionModel()
            ACTION_SET_GAME_MODE -> {
                selectedGameMode = runCatching { GameModeIntelligence.Mode.valueOf(intent.getStringExtra(EXTRA_GAME_MODE).orEmpty()) }.getOrDefault(GameModeIntelligence.Mode.UNKNOWN)
                getSharedPreferences("clash_ai_strategy_context", Context.MODE_PRIVATE).edit().putString("game_mode", selectedGameMode.name).apply()
            }
            ACTION_UPDATE_STRATEGY_CONTEXT -> {
                latestConfirmedEnemyCard = intent.getStringExtra(EXTRA_STRATEGY_ENEMY_CARD)?.takeIf { it.isNotBlank() }
                latestConfirmedEnemyDeck = intent.getStringArrayListExtra(EXTRA_STRATEGY_ENEMY_DECK).orEmpty()
                latestManualHand = intent.getStringArrayListExtra(EXTRA_STRATEGY_HAND).orEmpty()
                latestManualElixir = if (intent.hasExtra(EXTRA_STRATEGY_ELIXIR)) intent.getIntExtra(EXTRA_STRATEGY_ELIXIR, 0).coerceIn(0, 10) else null
                if (projection == null) stopSelf()
            }
            ACTION_RECORD_ACTION_FEEDBACK -> {
                if (!::actionFeedbackStore.isInitialized) actionFeedbackStore = ActionFeedbackStore(this)
                val outcome = runCatching { ActionFeedbackEngine.Outcome.valueOf(intent.getStringExtra(EXTRA_ACTION_FEEDBACK).orEmpty()) }.getOrNull()
                val saved = outcome?.let { actionFeedbackStore.recordOutcome(it) } == true
                floatingCoach?.update(if (saved) actionFeedbackStore.summary(selectedGameMode.name) else "No pending action plan to evaluate. Wait for a new plan, then report its result.")
            }
            ACTION_RECORD_LEARNING_OUTCOME -> {
                if (!::decisionLearningStore.isInitialized) decisionLearningStore = DecisionLearningStore(this)
                val outcome = runCatching { DecisionLearningEngine.Outcome.valueOf(intent.getStringExtra(EXTRA_LEARNING_OUTCOME).orEmpty()) }.getOrNull()
                val saved = outcome?.let { decisionLearningStore.recordOutcome(it) } == true
                floatingCoach?.update(if (saved) decisionLearningStore.summary() else "No pending recommendation to evaluate. Outcomes are only recorded after your explicit feedback.")
            }
            ACTION_RECORD_STRATEGY_OUTCOME -> {
                if (!::cardStrategyEngine.isInitialized) cardStrategyEngine = CardStrategyEngine(this)
                val mode = intent.getStringExtra(EXTRA_STRATEGY_MODE).orEmpty()
                val matchup = intent.getStringExtra(EXTRA_STRATEGY_MATCHUP).orEmpty()
                val card = intent.getStringExtra(EXTRA_STRATEGY_CARD).orEmpty()
                if (mode in setOf("ATTACK", "DEFEND") && card.isNotBlank()) {
                    cardStrategyEngine.recordOutcome(mode, matchup, card, intent.getBooleanExtra(EXTRA_STRATEGY_SUCCESS, false))
                }
            }
            ACTION_START -> {
                startForeground(NOTIFICATION_ID, notification())
                val code = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                @Suppress("DEPRECATION")
                val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                    else intent.getParcelableExtra(EXTRA_RESULT_DATA)
                if (data != null) beginCapture(code, data)
            }
        }
        return START_NOT_STICKY
    }

    private fun beginCapture(resultCode: Int, data: Intent) {
        stopProjectionOnly()
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        CardDatabase.load(this)
        cardStrategyEngine = CardStrategyEngine(this)
        tacticalCombinationEngine = TacticalCombinationEngine(cardStrategyEngine)
        getSharedPreferences("clash_ai_strategy_context", Context.MODE_PRIVATE).let { prefs ->
            selectedGameMode = runCatching { GameModeIntelligence.Mode.valueOf(prefs.getString("game_mode", "NORMAL") ?: "NORMAL") }.getOrDefault(GameModeIntelligence.Mode.UNKNOWN)
            latestConfirmedEnemyCard = prefs.getString("enemy_card", null)?.takeIf { it.isNotBlank() }
            latestConfirmedEnemyDeck = prefs.getStringSet("enemy_deck", emptySet()).orEmpty().toList()
            latestManualHand = prefs.getStringSet("hand", emptySet()).orEmpty().toList()
            latestManualElixir = if (prefs.contains("own_elixir")) prefs.getInt("own_elixir", 5).coerceIn(0, 10) else null
        }
        latestScreenPhase = GameScreenModeDetector.Phase.UNKNOWN
        latestDraftCandidates = emptyList()
        battlefieldUnderstanding.reset()
        realtimeGameplayIntelligence.reset()
        matchPredictionEngine.reset()
        latestBattlefieldSnapshot = null
        enemyIntelligencePipeline.reset()
        latestEnemyIntelligenceSummary = "ENEMY INTELLIGENCE: waiting for confirmed card identities"
        latestEnemyCardModelSummary = "ENEMY CARD MODEL: not installed"
        latestEnemyElixirLow = null
        latestEnemyElixirHigh = null
        latestBattlefieldSummary = "BATTLEFIELD: waiting for full-frame observations"
        gameScreenModeDetector.reset()
        latestHandResult = null
        recognitionEngine?.close()
        recognitionEngine = CardRecognitionEngine(this)
        handCardAnalyzer = HandCardAnalyzer(this)
        arenaDetector?.close()
        arenaDetector = ArenaDetectorRuntime(this)
        enemyCardDetector?.close()
        enemyCardDetector = ArenaDetectorRuntime(this, "enemy_card_detector.tflite", "enemy_card_detector_labels.txt", 0.55f)
        latestArenaDetectionSummary = "ARENA DETECTOR: ${arenaDetector?.status?.message ?: "unavailable"}"
        latestEnemyCardModelSummary = "ENEMY CARD MODEL: ${enemyCardDetector?.status?.message ?: "unavailable"}"
        latestHandSummary = "HAND: waiting for first gameplay frame"
        projection = manager.getMediaProjection(resultCode, data)
        projection?.registerCallback(projectionCallback, Handler(mainLooper))
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        val density = metrics.densityDpi
        thread = HandlerThread("ClashAI-FrameReader").also { it.start() }
        val handler = Handler(thread!!.looper)
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ source ->
            val now = System.currentTimeMillis()
            val frame = source.acquireLatestImage() ?: return@setOnImageAvailableListener
            if (now - lastFrameAt < 650L) { frame.close(); return@setOnImageAvailableListener }
            lastFrameAt = now
            val regions = motionDetector.analyze(frame)
            val tracks = objectTracker.update(regions, now)
            val persistentTracks = tracks.filter { it.persistent }
            latestPersistentTrackCount = persistentTracks.size
            latestMotionCandidateCount = regions.size
            val battlefieldAnalysis = analyzeBattlefieldTracks(tracks)
            if (now - lastOverlayUpdateAt >= 1800L) {
                lastOverlayUpdateAt = now
                val transientCount = (0 until battlefieldAnalysis.length()).count { i ->
                    battlefieldAnalysis.optJSONObject(i)?.optString("pattern") == "TRANSIENT_EFFECT_SUSPECT"
                }
                latestTransientEffectCount = transientCount
                val overlayMessage = when {
                    persistentTracks.isEmpty() -> "Scanning the arena. No persistent visual object is confirmed yet."
                    transientCount > 0 && transientCount >= persistentTracks.size -> "Possible short-lived visual effects detected. Wait for clearer evidence before reacting."
                    else -> "Possible battlefield activity: ${persistentTracks.size} persistent visual track(s). Check the lane and troop identity before choosing a counter."
                }
                floatingCoach?.update("$overlayMessage\n$latestBattlefieldSummary\n$latestEnemyIntelligenceSummary\n$latestEnemyCardModelSummary\n$latestArenaDetectionSummary\n$latestHandSummary\n$latestTacticalSummary")
            }
            if (now - lastCandidateAt >= recommendedBattlefieldRefreshMs) {
                lastCandidateAt = now
                val snapshot = saveOpponentArenaSnapshot(frame, now)
                val trackCrops = savePersistentTrackCrops(frame, persistentTracks, now)
                val recognitions = classifyTrackCrops(trackCrops)
                val detectorFrame = if (latestScreenPhase == GameScreenModeDetector.Phase.BATTLE)
                    saveFullFrameForDetection(frame, now) else null
                val arenaDetections = if (latestScreenPhase == GameScreenModeDetector.Phase.BATTLE) {
                    detectorFrame?.let { detectBattlefieldFullFrame(it, now) } ?: JSONArray()
                } else {
                    latestBattlefieldSummary = if (latestScreenPhase == GameScreenModeDetector.Phase.CHAOS_SELECTION)
                        "BATTLEFIELD: paused during Chaos card selection."
                    else "BATTLEFIELD: waiting for battle-screen confirmation."
                    JSONArray()
                }
                recognitionVerifier.retainOnly(tracks.map { it.id }.toSet())
                val encoded = JSONArray().apply {
                    regions.forEach { region ->
                        put(JSONObject().put("left", region.left).put("top", region.top)
                            .put("right", region.right).put("bottom", region.bottom)
                            .put("changedCells", region.changedCells))
                    }
                }.toString()
                val encodedTracks = JSONArray().apply {
                    tracks.forEach { track ->
                        put(JSONObject().put("id", track.id).put("left", track.left)
                            .put("top", track.top).put("right", track.right).put("bottom", track.bottom)
                            .put("velocityX", track.velocityX).put("velocityY", track.velocityY)
                            .put("hits", track.hits).put("missedFrames", track.missedFrames)
                            .put("persistent", track.persistent))
                    }
                }.toString()
                sendBroadcast(Intent(ACTION_DEPLOYMENT_CANDIDATE).setPackage(packageName)
                    .putExtra(EXTRA_SNAPSHOT_PATH, snapshot?.absolutePath.orEmpty())
                    .putExtra(EXTRA_MOTION_REGIONS, encoded)
                    .putExtra(EXTRA_MOTION_TRACKS, encodedTracks)
                    .putExtra(EXTRA_TRACK_CROPS, trackCrops.toString())
                    .putExtra(EXTRA_TRACK_RECOGNITIONS, recognitions.toString())
                    .putExtra(EXTRA_ARENA_DETECTIONS, arenaDetections.toString())
                    .putExtra(EXTRA_BATTLEFIELD_SUMMARY, latestBattlefieldSummary)
                    .putExtra(EXTRA_ENEMY_INTELLIGENCE_SUMMARY, latestEnemyIntelligenceSummary)
                    .putExtra(EXTRA_BATTLEFIELD_ANALYSIS, battlefieldAnalysis.toString()))
            }
            if (now - lastOcrAt >= 2400L) {
                lastOcrAt = now
                val hand = if (latestScreenPhase == GameScreenModeDetector.Phase.CHAOS_SELECTION) null else runCatching { handCardAnalyzer?.analyze(frame, recognitionEngine, now) }.getOrNull()
                latestHandResult = hand
                latestHandSummary = hand?.summary ?: "HAND: automatic cropper unavailable"
                runOcr(frame, latestHandSummary)
            } else frame.close()
        }, handler)
        display = projection?.createVirtualDisplay(
            "ClashAI-Screen", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, handler
        )
    }




    private fun reloadRecognitionModel() {
        recognitionEngine?.close()
        CardDatabase.load(this)
        recognitionEngine = CardRecognitionEngine(this)
        handCardAnalyzer?.reset()
        latestHandResult = null
        latestPersistentTrackCount = 0
        latestMotionCandidateCount = 0
        latestTransientEffectCount = 0
        latestArenaObjectLabels = emptyList()
        latestHandSummary = "HAND: ${recognitionEngine?.status?.message ?: "model unavailable"}"
        floatingCoach?.update(latestHandSummary)
    }

    /** Produces motion-pattern hints; these are never treated as confirmed troops or cards. */
    private fun analyzeBattlefieldTracks(tracks: List<ArenaObjectTracker.Track>): JSONArray {
        val output = JSONArray()
        tracks.forEach { track ->
            val result = battlefieldClassifier.analyze(track)
            output.put(JSONObject()
                .put("trackId", result.trackId)
                .put("pattern", result.pattern.name)
                .put("stable", result.stable)
                .put("confidence", result.confidence)
                .put("hits", result.hits)
                .put("speed", result.speed)
                .put("area", result.area)
                .put("explanation", result.explanation))
        }
        battlefieldClassifier.retainOnly(tracks.map { it.id }.toSet())
        return output
    }

    /** Save a diagnostic crop of the opponent half when a large arena change is detected.
     * The crop is local-only and is not a card classification result.
     */
    private fun saveOpponentArenaSnapshot(frame: Image, now: Long): File? {
        val plane = frame.planes.firstOrNull() ?: return null
        val buffer = plane.buffer.duplicate()
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val left = (frame.width * 0.08f).toInt().coerceIn(0, frame.width - 1)
        val right = (frame.width * 0.92f).toInt().coerceIn(left + 1, frame.width)
        val top = (frame.height * 0.04f).toInt().coerceIn(0, frame.height - 1)
        val bottom = (frame.height * 0.49f).toInt().coerceIn(top + 1, frame.height)
        val bitmap = Bitmap.createBitmap(right - left, bottom - top, Bitmap.Config.ARGB_8888)
        val pixels = IntArray((right - left) * (bottom - top))
        var out = 0
        for (y in top until bottom) {
            for (x in left until right) {
                val offset = y * rowStride + x * pixelStride
                if (offset + 2 >= buffer.limit()) { bitmap.recycle(); return null }
                val r = buffer.get(offset).toInt() and 0xff
                val g = buffer.get(offset + 1).toInt() and 0xff
                val b = buffer.get(offset + 2).toInt() and 0xff
                pixels[out++] = (0xff shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        bitmap.setPixels(pixels, 0, right - left, 0, 0, right - left, bottom - top)
        val directory = File(cacheDir, "deployment_samples").apply { mkdirs() }
        val file = File(directory, "arena_$now.jpg")
        return try {
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 82, it) }
            file
        } catch (_: Exception) { null } finally { bitmap.recycle() }
    }


    /** Save individual crops around persistent motion tracks for human labelling.
     * Coordinates map to the opponent arena ROI. These are candidates, not troop identities.
     */
    private fun savePersistentTrackCrops(frame: Image, tracks: List<ArenaObjectTracker.Track>, now: Long): JSONArray {
        val result = JSONArray()
        if (tracks.isEmpty()) return result
        val plane = frame.planes.firstOrNull() ?: return result
        val buffer = plane.buffer.duplicate()
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val roiLeft = frame.width * 0.08f
        val roiTop = frame.height * 0.04f
        val roiWidth = frame.width * 0.84f
        val roiHeight = frame.height * 0.45f
        val directory = File(cacheDir, "track_crops").apply { mkdirs() }
        tracks.take(8).forEach { track ->
            // Add modest padding so the crop includes the visible unit and nearby animation.
            val padX = (track.right - track.left) * 0.22f
            val padY = (track.bottom - track.top) * 0.22f
            val l = ((track.left - padX).coerceIn(0f, 1f) * roiWidth + roiLeft).toInt().coerceIn(0, frame.width - 1)
            val t = ((track.top - padY).coerceIn(0f, 1f) * roiHeight + roiTop).toInt().coerceIn(0, frame.height - 1)
            val r = ((track.right + padX).coerceIn(0f, 1f) * roiWidth + roiLeft).toInt().coerceIn(l + 1, frame.width)
            val b = ((track.bottom + padY).coerceIn(0f, 1f) * roiHeight + roiTop).toInt().coerceIn(t + 1, frame.height)
            if (r - l < 12 || b - t < 12) return@forEach
            val bitmap = Bitmap.createBitmap(r - l, b - t, Bitmap.Config.ARGB_8888)
            val pixels = IntArray((r - l) * (b - t))
            var index = 0
            var valid = true
            for (y in t until b) {
                for (x in l until r) {
                    val offset = y * rowStride + x * pixelStride
                    if (offset + 2 >= buffer.limit()) { valid = false; break }
                    val red = buffer.get(offset).toInt() and 0xff
                    val green = buffer.get(offset + 1).toInt() and 0xff
                    val blue = buffer.get(offset + 2).toInt() and 0xff
                    pixels[index++] = (0xff shl 24) or (red shl 16) or (green shl 8) or blue
                }
                if (!valid) break
            }
            if (valid) {
                bitmap.setPixels(pixels, 0, r - l, 0, 0, r - l, b - t)
                val file = File(directory, "track_${track.id}_$now.jpg")
                try {
                    FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                    result.put(JSONObject().put("trackId", track.id).put("path", file.absolutePath)
                        .put("hits", track.hits).put("changedCells", track.changedCells)
                        .put("labelStatus", "unlabelled_candidate"))
                } catch (_: Exception) { /* Keep capture running if one crop cannot be saved. */ }
            }
            bitmap.recycle()
        }
        // Keep the cache bounded; older crops can be exported/labelled before they age out.
        directory.listFiles()?.sortedBy { it.lastModified() }?.let { files ->
            files.dropLast(120).forEach { it.delete() }
        }
        return result
    }


    /** Run the optional on-device model on each saved track crop and combine predictions over time. */
    private fun classifyTrackCrops(crops: JSONArray): JSONArray {
        val output = JSONArray()
        val engine = recognitionEngine
        for (index in 0 until crops.length()) {
            val crop = crops.optJSONObject(index) ?: continue
            val trackId = crop.optInt("trackId", -1)
            val path = crop.optString("path")
            if (trackId < 0 || path.isBlank()) continue
            val bitmap = if (engine?.status?.ready == true) android.graphics.BitmapFactory.decodeFile(path) else null
            val prediction = if (engine != null && bitmap != null) engine.classify(bitmap) else null
            bitmap?.recycle()
            val result = recognitionVerifier.observe(
                trackId,
                prediction?.takeIf { it.accepted }?.card?.name,
                prediction?.confidence ?: 0f
            )
            output.put(JSONObject()
                .put("trackId", trackId)
                .put("modelReady", engine?.status?.ready == true)
                .put("frameCard", prediction?.card?.name ?: JSONObject.NULL)
                .put("frameConfidence", prediction?.confidence ?: 0f)
                .put("stableCandidate", result.candidateCard ?: JSONObject.NULL)
                .put("stable", result.stable)
                .put("votes", result.votes)
                .put("observations", result.observations)
                .put("message", if (prediction == null) engine?.status?.message ?: "Model unavailable" else result.message))
        }
        return output
    }

    /** Full-frame input matches the full-frame detector training annotation format. */
    private fun saveFullFrameForDetection(frame: Image, now: Long): File? {
        val plane = frame.planes.firstOrNull() ?: return null
        val buffer = plane.buffer.duplicate()
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val bitmap = Bitmap.createBitmap(frame.width, frame.height, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(frame.width * frame.height)
        var out = 0
        for (y in 0 until frame.height) {
            for (x in 0 until frame.width) {
                val offset = y * rowStride + x * pixelStride
                if (offset + 2 >= buffer.limit()) { bitmap.recycle(); return null }
                val r = buffer.get(offset).toInt() and 0xff
                val g = buffer.get(offset + 1).toInt() and 0xff
                val b = buffer.get(offset + 2).toInt() and 0xff
                pixels[out++] = (0xff shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        bitmap.setPixels(pixels, 0, frame.width, 0, 0, frame.width, frame.height)
        val directory = File(cacheDir, "detector_frames").apply { mkdirs() }
        val file = File(directory, "frame_$now.jpg")
        return try {
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            directory.listFiles()?.sortedBy { it.lastModified() }?.dropLast(40)?.forEach { it.delete() }
            file
        } catch (_: Exception) { null } finally { bitmap.recycle() }
    }

    /** Runs the separate full-frame arena detector and updates the temporal battlefield model. */
    private fun detectBattlefieldFullFrame(snapshot: File, timestampMs: Long): JSONArray {
        val bitmap = android.graphics.BitmapFactory.decodeFile(snapshot.absolutePath)
            ?: return JSONArray()
        val result: ArenaDetectorRuntime.Result?
        val exactCardResult: ArenaDetectorRuntime.Result?
        try {
            result = arenaDetector?.detect(bitmap)
            exactCardResult = enemyCardDetector?.detect(bitmap)
        } catch (_: Exception) {
            latestArenaDetectionSummary = "ARENA DETECTOR: inference unavailable"
            latestBattlefieldSummary = "BATTLEFIELD: detector frame could not be analysed."
            return JSONArray()
        } finally { bitmap.recycle() }
        val broadResult = result ?: ArenaDetectorRuntime.Result(
            emptyList(), ArenaDetectorRuntime.Status(false, "broad detector unavailable")
        )
        val allDetections = broadResult.detections + exactCardResult?.detections.orEmpty()
        val anyDetectorReady = broadResult.status.ready || (exactCardResult?.status?.ready == true)
        latestEnemyCardModelSummary = if (exactCardResult?.status?.ready == true) {
            "ENEMY CARD MODEL: ${exactCardResult.detections.size} exact-card candidate(s)"
        } else {
            "ENEMY CARD MODEL: ${exactCardResult?.status?.message ?: "unavailable"}"
        }
        val understanding = battlefieldUnderstanding.update(allDetections, timestampMs, anyDetectorReady)
        latestBattlefieldSnapshot = understanding
        latestBattlefieldSummary = understanding.summary
        val enemyUpdate = enemyIntelligencePipeline.update(understanding, timestampMs)
        latestEnemyIntelligenceSummary = enemyUpdate.summary
        latestEnemyElixirLow = enemyUpdate.elixir.low.takeIf { enemyUpdate.elixir.known }
        latestEnemyElixirHigh = enemyUpdate.elixir.high.takeIf { enemyUpdate.elixir.known }
        if (enemyUpdate.deck.isNotEmpty()) latestConfirmedEnemyDeck = (latestConfirmedEnemyDeck + enemyUpdate.deck).distinct().take(8)
        enemyUpdate.latestCard?.let { latestConfirmedEnemyCard = it }
        val realtime = realtimeGameplayIntelligence.observe(
            understanding, timestampMs, latestConfirmedEnemyDeck, latestConfirmedEnemyCard
        )
        recommendedBattlefieldRefreshMs = realtime.recommendedRefreshMs
        latestBattlefieldSummary = understanding.summary + "\\n" + realtime.summary +
            "\\nAdaptive refresh: ${realtime.recommendedRefreshMs} ms; freshness=${realtime.freshness}."
        latestArenaObjectLabels = allDetections.filter { it.confidence >= 0.55 }.map { it.label }.distinct()
        latestArenaDetectionSummary = if (allDetections.isEmpty()) {
            "ARENA DETECTION: no trained detector produced candidates (${broadResult.status.message})"
        } else {
            "ARENA CANDIDATES: " + allDetections.take(6).joinToString(" · ") { "${it.label} ${(it.confidence * 100).toInt()}%" }
        }
        return JSONArray().apply {
            understanding.objects.forEach { obj ->
                val detection = allDetections.firstOrNull { d ->
                    d.label.equals(obj.label, ignoreCase = true) &&
                        kotlin.math.abs((d.left + d.right) / 2f - obj.centerX) < 0.0001f &&
                        kotlin.math.abs((d.top + d.bottom) / 2f - obj.centerY) < 0.0001f
                }
                put(JSONObject()
                    .put("trackId", obj.trackId)
                    .put("label", obj.label)
                    .put("kind", obj.kind.name)
                    .put("troopDomain", obj.troopDomain.name)
                    .put("confidence", obj.confidence)
                    .put("left", detection?.left ?: JSONObject.NULL)
                    .put("top", detection?.top ?: JSONObject.NULL)
                    .put("right", detection?.right ?: JSONObject.NULL)
                    .put("bottom", detection?.bottom ?: JSONObject.NULL)
                    .put("centerX", obj.centerX).put("centerY", obj.centerY)
                    .put("side", obj.side.name).put("lane", obj.lane.name)
                    .put("movement", obj.movement.name)
                    .put("towerProximity", obj.towerProximity)
                    .put("identityConfirmed", obj.identityConfirmed)
                    .put("identityStatus", if (obj.identityConfirmed) "STABLE_BROAD_CLASS_NOT_CARD_IDENTITY" else "TENTATIVE_BROAD_CLASS")
                    .put("teamStatus", if (obj.side == BattlefieldStateModel.Side.UNKNOWN) "UNKNOWN" else "POSITION_BASED_STANDARD_PORTRAIT_ESTIMATE"))
            }
        }
    }

    private fun runOcr(frame: Image, handSummary: String) {
        val image = try { InputImage.fromMediaImage(frame, 0) } catch (_: Exception) { frame.close(); return }
        val frameWidth = frame.width
        val frameHeight = frame.height
        recognizer.process(image)
            .addOnSuccessListener { result ->
                val regions = result.textBlocks.flatMap { block -> block.lines.mapNotNull { line ->
                    val box = line.boundingBox ?: return@mapNotNull null
                    LiveHudAnalyzer.TextRegion(line.text, box.left.toFloat(), box.top.toFloat(), box.right.toFloat(), box.bottom.toFloat())
                } }
                val reading = liveHudAnalyzer.observe(regions, frameWidth, frameHeight)
                val phaseReading = gameScreenModeDetector.observe(regions, frameWidth, frameHeight, CardCatalog.names)
                if (phaseReading.phase != GameScreenModeDetector.Phase.UNKNOWN) latestScreenPhase = phaseReading.phase
                if (latestScreenPhase == GameScreenModeDetector.Phase.CHAOS_SELECTION) {
                    selectedGameMode = GameModeIntelligence.Mode.CHAOS
                    if (phaseReading.phase == GameScreenModeDetector.Phase.CHAOS_SELECTION) {
                        latestDraftCandidates = phaseReading.detectedCards
                    }
                    latestHandResult = null // Never treat draft offers as the four-card battle hand.
                    getSharedPreferences("clash_ai_strategy_context", Context.MODE_PRIVATE).edit().putString("game_mode", selectedGameMode.name).apply()
                    val draftPrefs = getSharedPreferences("clash_ai_chaos_draft", Context.MODE_PRIVATE)
                    val mapping = ChaosDraftScreenMapping.fromStored(draftPrefs.getString("our_selection_half", "").orEmpty())
                    val existingOwn = draftPrefs.getString("selected_cards", "").orEmpty().lines().filter { it.isNotBlank() }
                    val existingOpponent = draftPrefs.getString("opponent_visible_picks", "").orEmpty().split(",", "\n").map { it.trim() }.filter { it.isNotBlank() }
                    if (!::cardStrategyEngine.isInitialized) cardStrategyEngine = CardStrategyEngine(this)
                    val autoDraft = chaosDraftAutoPilot.observe(
                        latestDraftCandidates,
                        phaseReading.upperSelectionCandidates,
                        phaseReading.lowerSelectionCandidates,
                        mapping,
                        existingOwn,
                        existingOpponent,
                        cardStrategyEngine
                    )
                    if (autoDraft.calibrated) {
                        draftPrefs.edit()
                            .putString("selected_cards", autoDraft.ownVisibleCards.joinToString("\n"))
                            .putString("opponent_visible_picks", autoDraft.opponentVisibleCards.joinToString(", "))
                            .putString("own_visible_picks", autoDraft.ownVisibleCards.joinToString("\n"))
                            .putString("auto_recommendation", autoDraft.recommendation?.card.orEmpty())
                            .apply()
                    }
                    val draftSummary = """GAME MODE: CHAOS
PHASE: CARD SELECTION
${phaseReading.reason}
Stable OCR card candidates: ${autoDraft.stableVisibleCards.joinToString(" · ").ifBlank { "waiting for repeated recognition" }}
Our visible picks: ${autoDraft.ownVisibleCards.joinToString(" · ").ifBlank { "not confirmed" }} (${autoDraft.ownVisibleCards.size}/8)
Opponent visible picks: ${autoDraft.opponentVisibleCards.joinToString(" · ").ifBlank { "not confirmed" }}
${autoDraft.recommendation?.let { "NEXT PICK: ${it.card} — ${it.reason} Alternatives: ${it.alternatives.joinToString(" · ")}" } ?: autoDraft.message}
The AI recommends automatically; you make the in-game selection. OCR candidates are not treated as confirmed if they are not repeated."""
                    sendBroadcast(Intent(ACTION_OCR).setPackage(packageName)
                        .putExtra(EXTRA_TEXT, result.text)
                        .putExtra(EXTRA_HUD_SUMMARY, draftSummary)
                        .putExtra(EXTRA_SCREEN_PHASE, latestScreenPhase.name)
                        .putExtra(EXTRA_SCREEN_PHASE_REASON, phaseReading.reason)
                        .putStringArrayListExtra(EXTRA_DRAFT_CARDS, ArrayList(latestDraftCandidates))
                        .putStringArrayListExtra(EXTRA_DRAFT_UPPER_CARDS, ArrayList(phaseReading.upperSelectionCandidates))
                        .putStringArrayListExtra(EXTRA_DRAFT_LOWER_CARDS, ArrayList(phaseReading.lowerSelectionCandidates)))
                    floatingCoach?.update(draftSummary)
                    return@addOnSuccessListener
                }
                val confirmedHand = latestHandResult?.slots.orEmpty()
                    .filter { it.stable && !it.cardName.isNullOrBlank() }
                    .mapNotNull { it.cardName }
                val completeHand = confirmedHand.distinct().takeIf { it.size == 4 } ?: latestManualHand.distinct().takeIf { it.size == 4 }.orEmpty()
                val confirmedOwnElixir = reading.elixir.takeIf { reading.confidence == "REPEATED_OCR" } ?: latestManualElixir
                val decision = liveDecisionEngine.evaluate(
                    BattleDecisionEngine.Context(
                        latestConfirmedEnemyCard = latestConfirmedEnemyCard,
                        confirmedEnemyDeck = latestConfirmedEnemyDeck,
                        availableHand = completeHand,
                        ownElixir = confirmedOwnElixir,
                        enemyElixirLow = latestEnemyElixirLow ?: 0.0,
                        enemyElixirHigh = latestEnemyElixirHigh ?: 10.0,
                        persistentTracks = latestPersistentTrackCount,
                        motionCandidates = latestMotionCandidateCount,
                        transientEffects = latestTransientEffectCount,
                        elapsedSeconds = 0L,
                        enemyElixirKnown = latestEnemyElixirLow != null && latestEnemyElixirHigh != null
                    )
                )
                if (!::cardStrategyEngine.isInitialized) cardStrategyEngine = CardStrategyEngine(this)
                val strategy = cardStrategyEngine.evaluate(CardStrategyEngine.Input(
                    hand = completeHand,
                    ownElixir = confirmedOwnElixir,
                    confirmedEnemyCard = latestConfirmedEnemyCard,
                    enemyDeck = latestConfirmedEnemyDeck,
                    battlefield = latestArenaObjectLabels.map { CardStrategyEngine.BattlefieldUnit(it, 0.55, false) }
                ))
                val handStatus = when {
                    confirmedHand.distinct().size == 4 -> "AUTO HAND: ${completeHand.joinToString(" · ")}"
                    completeHand.size == 4 -> "MANUAL HAND: ${completeHand.joinToString(" · ")}"
                    else -> "HAND: ${confirmedHand.size}/4 cards confidently recognised; card-specific advice withheld"
                }
                val elixirSource = if (reading.confidence == "REPEATED_OCR" && reading.elixir != null) "REPEATED OCR" else if (latestManualElixir != null) "MANUAL ESTIMATE" else "UNCONFIRMED"
                val modeProfile = gameModeIntelligence.profile(selectedGameMode)
                val combo = tacticalCombinationEngine.recommendAttack(completeHand, confirmedOwnElixir, latestConfirmedEnemyDeck, selectedGameMode)
                val comboText = combo?.let { "ATTACK COMBINATION: ${it.lead} + ${it.support} (${it.totalCost} elixir)\n${it.reason}\nCONFIDENCE: ${it.confidence}" }
                    ?: "ATTACK COMBINATION: waiting for a complete recognised hand and confirmed elixir, or no safe two-card combination fits."
                val modeText = "GAME MODE: ${modeProfile.title}\n${modeProfile.notes}"
                val tacticalPlan = tacticalDecisionPlanner.evaluate(TacticalDecisionPlanner.Input(
                    hand = completeHand,
                    ownElixir = confirmedOwnElixir,
                    latestConfirmedEnemyCard = latestConfirmedEnemyCard,
                    confirmedEnemyDeck = latestConfirmedEnemyDeck,
                    battlefield = latestBattlefieldSnapshot?.objects.orEmpty(),
                    attackCombo = combo,
                    mode = selectedGameMode
                ))
                if (!::decisionLearningStore.isInitialized) decisionLearningStore = DecisionLearningStore(this)
                decisionLearningStore.recordRecommendation(selectedGameMode.name, tacticalPlan.priority, tacticalPlan.recommendation)
                val adaptiveInsight = decisionLearningStore.adaptiveInsight(selectedGameMode.name, tacticalPlan.priority)
                val prediction = matchPredictionEngine.evaluate(
                    battlefield = latestBattlefieldSnapshot?.objects.orEmpty(),
                    hand = completeHand,
                    ownElixir = confirmedOwnElixir,
                    combo = combo,
                    tacticalPlan = tacticalPlan,
                    nowMs = System.currentTimeMillis()
                )
                val situation = situationalAwarenessEngine.evaluate(latestBattlefieldSnapshot?.objects.orEmpty())
                val battleStrategy = battleStrategyEngine.evaluate(
                    hand = completeHand,
                    ownElixir = confirmedOwnElixir,
                    combo = combo,
                    plan = tacticalPlan,
                    prediction = prediction,
                    situation = situation,
                    confirmedEnemyDeck = latestConfirmedEnemyDeck,
                    mode = selectedGameMode
                )
                val playerActionPlan = playerActionPlanEngine.create(
                    strategy = battleStrategy,
                    plan = tacticalPlan,
                    hand = completeHand,
                    ownElixir = confirmedOwnElixir,
                    combo = combo,
                    latestConfirmedEnemyCard = latestConfirmedEnemyCard
                )
                if (!::actionFeedbackStore.isInitialized) actionFeedbackStore = ActionFeedbackStore(this)
                actionFeedbackStore.recordRecommendation(selectedGameMode.name, playerActionPlan.action.name, playerActionPlan.card, playerActionPlan.lane)
                val actionFeedbackSummary = actionFeedbackStore.summary(selectedGameMode.name)
                val summary = "${actionFeedbackSummary}\n\n${decisionLearningStore.summary()}\n$adaptiveInsight\n\n${situation.render()}\n\n${prediction.render()}\n\n${battleStrategy.render()}\n\n${playerActionPlan.render()}\n\nELIXIR: ${confirmedOwnElixir?.toString() ?: "?"}/10 · $elixirSource\n${reading.detail}\n$handStatus\n$modeText\n\n$latestEnemyIntelligenceSummary\n$latestEnemyCardModelSummary\n\n${decision.render()}\n\n${tacticalPlan.render()}\n\nCARD STRATEGY\n${strategy.render()}\n\n$comboText"
                latestTacticalSummary = "${actionFeedbackSummary}\n\n${playerActionPlan.render()}\n\n${battleStrategy.render()}\n\n${tacticalPlan.render()}\n\n${situation.render()}\n\n${prediction.render()}"
                sendBroadcast(Intent(ACTION_OCR).setPackage(packageName)
                    .putExtra(EXTRA_TEXT, result.text)
                    .putExtra(EXTRA_HUD_SUMMARY, summary)
                    .putExtra(EXTRA_SCREEN_PHASE, latestScreenPhase.name)
                    .putExtra(EXTRA_SCREEN_PHASE_REASON, phaseReading.reason)
                    .putStringArrayListExtra(EXTRA_DRAFT_CARDS, ArrayList(latestDraftCandidates))
                    .putStringArrayListExtra(EXTRA_DRAFT_UPPER_CARDS, ArrayList(phaseReading.upperSelectionCandidates))
                    .putStringArrayListExtra(EXTRA_DRAFT_LOWER_CARDS, ArrayList(phaseReading.lowerSelectionCandidates)))
                floatingCoach?.update(summary)
                RemoteCoachClient.requestAdvice(
                    context = this@ScreenCaptureService,
                    gameMode = selectedGameMode.name,
                    ownElixir = confirmedOwnElixir,
                    elixirSource = elixirSource,
                    hand = completeHand,
                    enemyCard = latestConfirmedEnemyCard,
                    enemyDeck = latestConfirmedEnemyDeck,
                    battlefieldSummary = latestBattlefieldSummary,
                    localAdvice = playerActionPlan.render() + "\n" + battleStrategy.render()
                ) { remoteAdvice ->
                    floatingCoach?.update("$summary\n\nREMOTE AI ADVICE\n$remoteAdvice")
                }
            }
            .addOnCompleteListener { frame.close() }
    }

    private fun notification(): Notification {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "CLASH AI screen analysis", NotificationManager.IMPORTANCE_LOW)
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("CLASH AI is analysing your screen")
            .setContentText("Tap Stop in CLASH AI to end screen capture")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true).build()
    }

    private fun stopProjectionOnly() {
        display?.release(); display = null
        reader?.close(); reader = null
        thread?.quitSafely(); thread = null
        projection?.stop(); projection = null
        motionDetector.reset()
        objectTracker.reset()
        recognitionVerifier.reset()
        battlefieldClassifier.reset()
        liveHudAnalyzer.reset()
        handCardAnalyzer?.reset()
        latestHandResult = null
        latestPersistentTrackCount = 0
        latestMotionCandidateCount = 0
        latestTransientEffectCount = 0
        latestArenaObjectLabels = emptyList()
        latestEnemyIntelligenceSummary = "ENEMY INTELLIGENCE: waiting for confirmed card identities"
        latestEnemyCardModelSummary = "ENEMY CARD MODEL: not installed"
        latestEnemyElixirLow = null
        latestEnemyElixirHigh = null
        latestHandSummary = "HAND: waiting for screen analysis"
        latestTacticalSummary = "TACTICAL ADVICE: waiting for confirmed hand and elixir readings"
        lastFrameAt = 0L
        lastOcrAt = 0L
        lastOverlayUpdateAt = 0L
    }

    private fun stopCapture() {
        floatingCoach?.hide()
        stopProjectionOnly()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { floatingCoach?.hide(); floatingCoach = null; stopProjectionOnly(); recognizer.close(); recognitionEngine?.close(); recognitionEngine = null; handCardAnalyzer = null; arenaDetector?.close(); arenaDetector = null; enemyCardDetector?.close(); enemyCardDetector = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}

package com.clashai.coach

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Compact, movable coach panel with simple LIVE, DECK and COACH tabs. */
class FloatingCoachOverlay(private val context: Context) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: LinearLayout? = null
    private var body: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var latestMessage = ""
    private var selectedTab = Tab.ELIXIR
    private var collapsed = false
    private var tabsRow: LinearLayout? = null

    private enum class Tab { ELIXIR, ENEMY_DECK, ADVICE }

    fun show(initialText: String = "Waiting for battle screen…") {
        latestMessage = initialText
        if (root != null) { render(); return }

        val panel = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(9))
            background = roundedBackground(0xF2182233.toInt(), 0xFF5B8DEF.toInt())
            elevation = dp(12).toFloat()
        }

        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), dp(1), dp(2), dp(5))
            setOnTouchListener(DragTouchListener())
        }
        val title = TextView(context).apply {
            text = "CLASH AI"
            textSize = 14f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        val spacer = View(context)
        val toggle = Button(context).apply {
            text = "–"
            textSize = 16f
            minWidth = dp(38)
            minimumWidth = dp(38)
            minHeight = dp(34)
            minimumHeight = dp(34)
            setPadding(0, 0, 0, 0)
            setTextColor(Color.WHITE)
            background = roundedBackground(0xFF34445D.toInt(), 0xFF34445D.toInt())
            setOnClickListener {
                collapsed = !collapsed
                render()
            }
        }
        header.addView(title)
        header.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        header.addView(toggle)
        panel.addView(header)

        val tabBar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        tabsRow = tabBar
        Tab.values().forEach { tab ->
            val button = Button(context).apply {
                text = tab.name
                textSize = 10f
                minWidth = 0
                minimumWidth = 0
                minHeight = dp(36)
                minimumHeight = dp(36)
                setPadding(dp(3), 0, dp(3), 0)
                setTextColor(Color.WHITE)
                setOnClickListener {
                    selectedTab = tab
                    collapsed = false
                    render()
                }
            }
            tabBar.addView(button, LinearLayout.LayoutParams(0, dp(36), 1f).apply {
                marginEnd = dp(4)
            })
        }
        panel.addView(tabBar)

        val content = TextView(context).apply {
            textSize = 12f
            setTextColor(0xFFF2F5FA.toInt())
            setPadding(dp(5), dp(9), dp(5), dp(3))
            maxLines = 7
            setLineSpacing(dp(2).toFloat(), 1f)
        }
        body = content
        panel.addView(content)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val layout = WindowManager.LayoutParams(
            dp(270), WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(8)
            y = (context.resources.displayMetrics.heightPixels * 0.16f).toInt()
        }
        try {
            windowManager.addView(panel, layout)
            root = panel
            params = layout
            render()
        } catch (_: Exception) {
            root = null
            body = null
            params = null
        }
    }

    fun update(message: String) {
        mainHandler.post {
            latestMessage = message
            render()
        }
    }

    fun hide() {
        root?.let { runCatching { windowManager.removeView(it) } }
        root = null
        body = null
        tabsRow = null
        params = null
    }

    private fun render() {
        val content = body ?: return
        tabsRow?.visibility = if (collapsed) View.GONE else View.VISIBLE
        content.visibility = if (collapsed) View.GONE else View.VISIBLE
        val lines = latestMessage.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val selected = when (selectedTab) {
            Tab.ELIXIR -> lines.filter {
                startsWithAny(it, "ELIXIR:", "ENEMY ELIXIR:", "ELIXIR READING:", "ELIXIR:") ||
                    it.contains("elixir", ignoreCase = true) && !it.contains("combination", ignoreCase = true)
            }
            Tab.ENEMY_DECK -> lines.filter {
                startsWithAny(it, "ENEMY INTELLIGENCE:", "ENEMY CARD MODEL:", "ENEMY DECK:", "Enemy deck:", "CONFIRMED ENEMY:", "ENEMY CARD:")
            }
            Tab.ADVICE -> lines.filter {
                startsWithAny(it, "TACTICAL ADVICE:", "TACTICAL:", "Recommended:", "PLAYER ACTION:", "ATTACK COMBINATION:", "DEFENCE:", "DEFENSE:", "CARD STRATEGY", "ACTION:") ||
                    it.contains("recommend", ignoreCase = true) || it.contains("strategy", ignoreCase = true)
            }
        }
        val fallback = when (selectedTab) {
            Tab.ELIXIR -> "Elixir: waiting for a reliable reading."
            Tab.ENEMY_DECK -> "Enemy deck: no cards confirmed yet."
            Tab.ADVICE -> "Advice: waiting for confirmed cards and battle readings."
        }
        val heading = when (selectedTab) {
            Tab.ELIXIR -> "ELIXIR\n"
            Tab.ENEMY_DECK -> "ENEMY DECK\n"
            Tab.ADVICE -> "BATTLE ADVICE\n"
        }
        content.text = heading + (selected.ifEmpty { listOf(fallback) }).joinToString("\n").take(360)
        for (i in 0 until (tabsRow?.childCount ?: 0)) {
            val button = tabsRow?.getChildAt(i) as? Button ?: continue
            val active = button.text.toString() == selectedTab.name
            button.background = roundedBackground(
                if (active) 0xFF315D9B.toInt() else 0xFF29364A.toInt(),
                if (active) 0xFF76A7F7.toInt() else 0xFF29364A.toInt()
            )
        }
    }

    private fun startsWithAny(value: String, vararg prefixes: String): Boolean =
        prefixes.any { value.startsWith(it, ignoreCase = true) }

    private fun roundedBackground(color: Int, stroke: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(10).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun dp(value: Int): Int = (value * context.resources.displayMetrics.density).toInt()

    private inner class DragTouchListener : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val p = params ?: return false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = p.x; startY = p.y
                    touchX = event.rawX; touchY = event.rawY
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = startX + (touchX - event.rawX).toInt()
                    p.y = startY + (event.rawY - touchY).toInt()
                    root?.let { panel -> runCatching { windowManager.updateViewLayout(panel, p) } }
                    return true
                }
                MotionEvent.ACTION_UP -> return true
            }
            return false
        }
    }
}

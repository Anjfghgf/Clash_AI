package com.clashai.coach
fun main() {
    val coach = LiveBattleCoach()
    val first = coach.observe(2, 1, listOf("MOVING_OBJECT_CANDIDATE"), 0)
    check(first.headline == "MOVEMENT CANDIDATE DETECTED")
    check(first.confidence.contains("Tentative"))
    val second = coach.observe(3, 2, listOf("MOVING_OBJECT_CANDIDATE", "PERSISTENT_VISUAL_OBJECT"), 0)
    check(second.headline == "POSSIBLE MULTI-UNIT ACTIVITY")
    val third = coach.observe(1, 1, listOf("MOVING_OBJECT_CANDIDATE"), 1)
    check(third.headline == "REVIEW A REPEATED CARD CANDIDATE")
    check(third.confidence.contains("not a confirmed"))
    check(coach.summary().contains("3 observations"))
    coach.reset()
    check(coach.summary().contains("0 observations"))
    println("Stage 18 LiveBattleCoach smoke test: PASS")
}

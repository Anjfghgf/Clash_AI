# CLASH AI — Stage 36: Automatic Battlefield Understanding

## Implemented

- Added `BattlefieldUnderstandingEngine`, a temporal layer over full-frame arena detector boxes.
- Full-frame detection now runs on the live capture cadence (about 1.9 seconds) even when motion tracking finds no persistent track. This allows static buildings to be detected as well as moving candidates.
- Detection boxes are associated across frames to create stable track IDs and estimate movement.
- Broad classes are separated into troop, building, spell/effect, or unknown.
- Troop domain is AIR or GROUND only when the detector label explicitly says so. Generic `troop` remains UNKNOWN.
- The existing battlefield state model contributes side, lane, movement and conservative identity stability. Side is a standard portrait-layout position estimate; river-band objects remain UNKNOWN until repeated observations support a side assignment. Repeated evidence is also required before changing a track from one side to the other.
- Approximate tower-zone proximity is provided as a coarse spatial hint, not exact pathing or targeting.
- Live coach summary and deployment-candidate broadcast now include temporal battlefield state.
- Added pure Kotlin smoke tests for class separation, team/lane estimation, movement, unknown labels, river uncertainty, and missing-model behavior.

## Model and training status

No trained arena detector weights are included. The app runtime remains inactive for semantic detection until a compatible `arena_detector.tflite` is trained and placed in app assets with the exact matching labels file. The five suggested classes are `building`, `air_troop`, `ground_troop`, `spell_effect`, and `troop_unknown`; the training script generates the authoritative output order from the dataset. Use its generated labels file, not a manually reordered file.

The pipeline requires reviewed full-frame bounding boxes from user-owned or creator-authorised gameplay recordings. Keep train/validation/test splits grouped by match session. Do not treat public YouTube availability as permission to train.

## Important limits

- Broad troop detection is not exact card recognition.
- Air/ground classification depends on training labels and model output; it is not guessed from a generic troop box.
- Side is estimated from the usual portrait orientation and vertical arena position. A rotated or unusual screen layout can invalidate it; near-river objects remain unknown.
- Lane is based on normalized horizontal position, and tower proximity is approximate.
- No automatic game input is implemented. This stage observes and describes the arena; it does not play cards.
- Full Android APK build and real-device gameplay test were not available in this environment.

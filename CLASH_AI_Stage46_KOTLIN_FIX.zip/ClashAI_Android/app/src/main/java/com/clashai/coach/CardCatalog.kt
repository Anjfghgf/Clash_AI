package com.clashai.coach

/** Card reference data for the coaching prototype. Costs/counters are strategic hints, not guarantees. */
object CardCatalog {
    private val fallbackCosts = linkedMapOf(
        "Skeletons" to 1, "Ice Spirit" to 1, "Fire Spirit" to 1, "Electro Spirit" to 1,
        "Heal Spirit" to 1, "The Log" to 2, "Zap" to 2, "Giant Snowball" to 2,
        "Goblins" to 2, "Spear Goblins" to 2, "Bomber" to 2, "Bats" to 2,
        "Wall Breakers" to 2, "Rage" to 2, "Barbarian Barrel" to 2,
        "Knight" to 3, "Archers" to 3, "Minions" to 3, "Cannon" to 3,
        "Tombstone" to 3, "Goblin Gang" to 3, "Dart Goblin" to 3,
        "Mega Minion" to 3, "Princess" to 3, "Miner" to 3, "Bandit" to 3,
        "Royal Ghost" to 3, "Skeleton Army" to 3, "Guards" to 3,
        "Fireball" to 4, "Poison" to 4, "Musketeer" to 4, "Valkyrie" to 4,
        "Mini P.E.K.K.A" to 4, "Hog Rider" to 4, "Battle Ram" to 4,
        "Baby Dragon" to 4, "Goblin Drill" to 4, "Inferno Tower" to 5,
        "Wizard" to 5, "Witch" to 5, "Prince" to 5, "Bowler" to 5,
        "Cannon Cart" to 5, "Royal Hogs" to 5, "Giant" to 5, "Balloon" to 5,
        "Barbarian Hut" to 6, "Rocket" to 6, "Elite Barbarians" to 6,
        "Royal Giant" to 6, "X-Bow" to 6, "Golem" to 8, "Three Musketeers" to 9,
        "P.E.K.K.A" to 7, "Mega Knight" to 7, "Lava Hound" to 7,
        "Sparky" to 6, "Electro Giant" to 7, "Goblin Giant" to 6,
        "Phoenix" to 4, "Mother Witch" to 4, "Hunter" to 4,
        "Fisherman" to 3, "Earthquake" to 3, "Tornado" to 3,
        "Lightning" to 6, "Arrows" to 3, "Freeze" to 4,
        "Inferno Dragon" to 4, "Electro Wizard" to 4, "Executioner" to 5,
        "Electro Dragon" to 5, "Night Witch" to 4, "Dark Prince" to 4,
        "Lumberjack" to 4, "Royal Recruits" to 7, "Goblin Cage" to 4,
        "Goblin Hut" to 4, "Furnace" to 4, "Flying Machine" to 4,
        "Zappies" to 4, "Rascals" to 5, "Skeleton Barrel" to 3,
        "Ice Golem" to 2, "Ice Wizard" to 3, "Magic Archer" to 4,
        "Golden Knight" to 4, "Archer Queen" to 5, "Skeleton King" to 4,
        "Mighty Miner" to 4, "Monk" to 5
    )


    private val cardCosts = linkedMapOf<String, Int?>().apply {
        fallbackCosts.forEach { (name, cost) -> put(name, cost) }
    }
    val costs: Map<String, Int?> get() = cardCosts

    fun initialize(context: android.content.Context) {
        CardDatabase.load(context)
        CardDatabase.all().forEach { card -> cardCosts[card.name] = card.elixirCost }
    }

    val names: List<String>
        get() = if (CardDatabase.all().isNotEmpty()) CardDatabase.all().map { it.name }
        else cardCosts.keys.toList()

    // Practical common answers; the coach can show several options rather than claiming a perfect counter.
    private val counters = mapOf(
        "Hog Rider" to listOf("Cannon", "Tombstone", "Inferno Tower", "Mini P.E.K.K.A", "P.E.K.K.A"),
        "Balloon" to listOf("Musketeer", "Archers", "Hunter", "Mega Minion", "Inferno Tower"),
        "Golem" to listOf("P.E.K.K.A", "Mini P.E.K.K.A", "Inferno Tower", "Inferno Dragon", "Mini P.E.K.K.A"),
        "Mega Knight" to listOf("P.E.K.K.A", "Knight", "Valkyrie", "Inferno Tower", "Mini P.E.K.K.A"),
        "P.E.K.K.A" to listOf("Skeletons", "Bats", "Goblin Gang", "Inferno Tower", "Cannon"),
        "Lava Hound" to listOf("Musketeer", "Archers", "Hunter", "Mega Minion", "Executioner"),
        "Sparky" to listOf("Zap", "Electro Spirit", "Electro Wizard", "Rocket", "Lightning"),
        "Royal Giant" to listOf("Inferno Tower", "Mini P.E.K.K.A", "P.E.K.K.A", "Cannon", "Hunter"),
        "Giant" to listOf("Mini P.E.K.K.A", "P.E.K.K.A", "Inferno Tower", "Cannon", "Tombstone"),
        "Prince" to listOf("Skeletons", "Guards", "Goblin Gang", "Knight", "Valkyrie"),
        "Elite Barbarians" to listOf("Skeletons", "Guards", "Valkyrie", "P.E.K.K.A", "Mini P.E.K.K.A"),
        "Witch" to listOf("Valkyrie", "Poison", "Fireball", "Baby Dragon", "Bowler"),
        "Wizard" to listOf("Fireball", "Poison", "Knight", "Valkyrie", "Mini P.E.K.K.A"),
        "Minion Horde" to listOf("Arrows", "Fireball", "Wizard", "Baby Dragon", "Executioner"),
        "Skeleton Army" to listOf("The Log", "Zap", "Arrows", "Valkyrie", "Bomber"),
        "Goblin Barrel" to listOf("The Log", "Arrows", "Barbarian Barrel", "Zap", "Snowball"),
        "X-Bow" to listOf("Rocket", "Earthquake", "P.E.K.K.A", "Knight", "Mega Knight"),
        "Battle Ram" to listOf("Cannon", "Tombstone", "P.E.K.K.A", "Mini P.E.K.K.A", "Valkyrie")
    )

    fun findNames(text: String): List<String> {
        val normalized = text.lowercase().replace(Regex("[^a-z0-9. ]"), " ")
        return names.filter { name ->
            Regex("\\b${Regex.escape(name.lowercase())}\\b").containsMatchIn(normalized)
        }
    }

    fun countersFor(enemy: String): List<String> = counters[enemy].orEmpty().distinct()
}
